// CyberPi SNES - WiFi drag-and-drop ROM uploader + Super Nintendo emulator (Snes9x core, same family Retro-Go uses on the ESP32).
// Sound plays through the CyberPi speaker (built-in DAC, mono, 22 kHz). Display/expander setup is copied from the working CyberPiBrowser sketch.
//
// Start-up intro: "CyberPi ENTERTAINMENT" animation + chime at power-on (any button skips), and a 2 s version of its ending every
// time a game is opened. Settings (on/off, volume, timing) are at the top of cyberpi_intro.h. The sound itself is cyberpi_psx_sound.h.
//
// Files needed in this folder: cyberpi_snes.ino, Common.h, snesemu.h, cyberpi_intro.h, cyberpi_psx_sound.h, partitions.csv, src/snes9x/ (all of it)
//
// Arduino IDE settings: Board "ESP32 Wrover Module", PSRAM "Enabled" (REQUIRED: a SNES does not fit without it).
// Flash size: set Tools > Flash Size to "8MB (64Mb)". Partition scheme: leave the Tools > Partition Scheme menu alone. The partitions.csv here is used
// automatically (2.25 MB app + about 5.7 MB for ROMs and saves).
// NOTE: after the first upload with this layout the ROM storage is re-formatted, so re-upload your ROMs.
//
// First boot: join WiFi "CyberPi-SNES" with your phone, open http://192.168.4.1/wifi, save your home WiFi.
// After that the screen shows the IP. Open it in a browser and drag .smc / .sfc files onto the page. ROMs up to 2 MB fit.
// Select a game with UP/DOWN and press A (or the joystick) to play. Controls are listed at the top of snesemu.h.
// Hold MENU + joystick press for 1.5 s to save and exit. If an upload fails, the browser page AND the Serial Monitor (115200) say exactly why.
// This sketch includes Snes9x, which is GPL v2 and not for commercial use (see src/snes9x/LICENSE and LICENSE-GPLv2.txt).


#include <WiFi.h>
#include <WebServer.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <Wire.h>
#include <SPI.h>
#include "esp_bt.h"
#include "Common.h"

// The Snes9x core uses more stack than the Arduino default (8 KB). Older cores without this macro just keep the default.
#ifdef SET_LOOP_TASK_STACK_SIZE
SET_LOOP_TASK_STACK_SIZE(16 * 1024);
#endif

#define WIFI_SSID_DEFAULT ""     // optional: hardcode your WiFi here instead of using the /wifi page
#define WIFI_PASS_DEFAULT ""
#define AP_NAME "CyberPi-SNES"

// ======================================================================= buttons + I/O expander (AW9523B)
#define I2C_SDA 19
#define I2C_SCL 18
#define AW_ADDR 0x58
enum : uint16_t { B_UP = 1 << 0, B_DOWN = 1 << 1, B_LEFT = 1 << 2, B_RIGHT = 1 << 3,
                  B_CENTER = 1 << 4, B_A = 1 << 5, B_B = 1 << 6, B_MENU = 1 << 7 };

static bool awWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(AW_ADDR); Wire.write(reg); Wire.write(val);
  return Wire.endTransmission() == 0;
}
static bool awRead(uint8_t reg, uint8_t &val) {
  Wire.beginTransmission(AW_ADDR); Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)AW_ADDR, 1) != 1) return false;
  val = Wire.read(); return true;
}
static bool expanderInit() {
  uint8_t id = 0; bool ok = awRead(0x10, id);
  Serial.printf("I/O expander: %s (ID 0x%02X, expected 0x23)\n", ok ? "found" : "NOT FOUND", id);
  awWrite(0x7F, 0x00); delay(10);
  awWrite(0x12, 0xFF); awWrite(0x13, 0xF9); awWrite(0x11, 0x00);
  awWrite(0x04, 0xFF); awWrite(0x05, 0x4F); awWrite(0x03, 0x00);   // P1.4/P1.5/P1.7 = outputs (LCD DC, RESET, backlight)
  return ok;
}
static bool readButtons(uint16_t &out) {
  uint8_t p0, p1;
  if (!awRead(0x00, p0) || !awRead(0x01, p1)) return false;
  uint16_t b = 0;
  if (!(p0 & (1 << 1))) b |= B_UP;
  if (!(p0 & (1 << 4))) b |= B_DOWN;
  if (!(p0 & (1 << 0))) b |= B_LEFT;
  if (!(p0 & (1 << 2))) b |= B_RIGHT;
  if (!(p0 & (1 << 3))) b |= B_CENTER;
  if (!(p0 & (1 << 6))) b |= B_A;
  if (!(p0 & (1 << 5))) b |= B_B;
  if (!(p1 & (1 << 0))) b |= B_MENU;
  out = b; return true;
}

// ======================================================================= display (ST7735S 128x128)
// SPI lines are real ESP32 pins (MOSI 2, SCLK 4, CS 12); DC, RESET, BACKLIGHT are on the AW9523B (100 + pin).
struct HwCfg { int8_t mosi, sclk, cs, dc, rst, bl; uint8_t blHigh, xoff, yoff, madctl, invert; };
static const HwCfg hw = { 2, 4, 12, 112, 113, 115, 1, 3, 2, 0xA0, 0 };

static SPIClass *lcdSpi = nullptr;
static bool lcdUp = false;
static uint8_t expP1 = 0;
static inline void pw(int pin, int v) {
  if (pin < 0) return;
  if (pin >= 100) {
    int b = pin - 100 - 8; if (b < 0 || b > 7) return;
    uint8_t n = v ? (expP1 | (1 << b)) : (expP1 & ~(1 << b));
    if (n != expP1) { expP1 = n; awWrite(0x03, expP1); }
    return;
  }
  digitalWrite(pin, v);
}
static void lcdCmd(uint8_t c, const uint8_t *d = nullptr, int n = 0) {
  lcdSpi->beginTransaction(SPISettings(20000000, MSBFIRST, SPI_MODE0));
  pw(hw.cs, LOW); pw(hw.dc, LOW); lcdSpi->transfer(c);
  if (n) { pw(hw.dc, HIGH); lcdSpi->writeBytes(d, n); }
  pw(hw.cs, HIGH); lcdSpi->endTransaction();
}
static void lcdBegin() {
  pinMode(27, OUTPUT); digitalWrite(27, HIGH);   // CJK font ROM shares the SPI bus: keep it deselected
  pinMode(hw.cs, OUTPUT);
  pw(hw.cs, HIGH);
  lcdSpi = new SPIClass(HSPI);
  lcdSpi->begin(hw.sclk, -1, hw.mosi, -1);
  pw(hw.rst, HIGH); delay(10); pw(hw.rst, LOW); delay(20); pw(hw.rst, HIGH); delay(120);
  lcdCmd(0x01); delay(150);
  lcdCmd(0x11); delay(150);
  { const uint8_t d[] = {0x01, 0x2C, 0x2D}; lcdCmd(0xB1, d, 3); lcdCmd(0xB2, d, 3); }
  { const uint8_t d[] = {0x01, 0x2C, 0x2D, 0x01, 0x2C, 0x2D}; lcdCmd(0xB3, d, 6); }
  { const uint8_t d[] = {0x07}; lcdCmd(0xB4, d, 1); }
  { const uint8_t d[] = {0xA2, 0x02, 0x84}; lcdCmd(0xC0, d, 3); }
  { const uint8_t d[] = {0xC5}; lcdCmd(0xC1, d, 1); }
  { const uint8_t d[] = {0x0A, 0x00}; lcdCmd(0xC2, d, 2); }
  { const uint8_t d[] = {0x8A, 0x2A}; lcdCmd(0xC3, d, 2); }
  { const uint8_t d[] = {0x8A, 0xEE}; lcdCmd(0xC4, d, 2); }
  { const uint8_t d[] = {0x0E}; lcdCmd(0xC5, d, 1); }
  lcdCmd(hw.invert ? 0x21 : 0x20);
  { const uint8_t d[] = {hw.madctl}; lcdCmd(0x36, d, 1); }
  { const uint8_t d[] = {0x05}; lcdCmd(0x3A, d, 1); }
  { const uint8_t d[] = {0x02,0x1C,0x07,0x12,0x37,0x32,0x29,0x2D,0x29,0x25,0x2B,0x39,0x00,0x01,0x03,0x10}; lcdCmd(0xE0, d, 16); }
  { const uint8_t d[] = {0x03,0x1D,0x07,0x06,0x2E,0x2C,0x29,0x2D,0x2E,0x2E,0x37,0x3F,0x00,0x00,0x02,0x10}; lcdCmd(0xE1, d, 16); }
  lcdCmd(0x13); delay(10);
  lcdCmd(0x29); delay(100);
  pw(hw.bl, hw.blHigh ? HIGH : LOW);
  lcdUp = true;
}
static void lcdPush() {
  if (!lcdUp || !g_fb) return;
  uint8_t c[4] = {0, (uint8_t)hw.xoff, 0, (uint8_t)(hw.xoff + SCR_W - 1)};
  uint8_t r[4] = {0, (uint8_t)hw.yoff, 0, (uint8_t)(hw.yoff + SCR_H - 1)};
  lcdCmd(0x2A, c, 4); lcdCmd(0x2B, r, 4);
  lcdSpi->beginTransaction(SPISettings(20000000, MSBFIRST, SPI_MODE0));
  pw(hw.cs, LOW); pw(hw.dc, LOW); lcdSpi->transfer(0x2C); pw(hw.dc, HIGH);
  lcdSpi->writeBytes((const uint8_t *)g_fb, SCR_W * SCR_H * 2);
  pw(hw.cs, HIGH); lcdSpi->endTransaction();
}

// ======================================================================= UI
static uint16_t cBg, cTitle, cTxt, cDim, cSel, cOk, cErr;

static void splash(const char *a, const char *b = "") {
  gFill(0, 0, SCR_W, SCR_H, cBg);
  gText(4, 4, "CyberPi SNES", cTitle);
  gText(4, 30, a, cTxt);
  gText(4, 42, b, cDim, 20);
  lcdPush();
}

static std::vector<String> roms;
static std::vector<uint32_t> romSizes;
static int sel = 0;
static volatile bool romsDirty = true;
static bool wantAP = false;
static bool fsOK = false;                      // true once LittleFS mounted
static Preferences prefs;
static WebServer server(80);
static File uploadFile;

// One short line shown at the bottom of the ROM list for 10 s (details go to the browser + Serial Monitor).
static String statusMsg;
static bool statusBad = false;
static uint32_t statusAt = 0;
static void setStatus(const char *m, bool bad) { statusMsg = m; statusBad = bad; statusAt = millis(); romsDirty = true; }

static bool netOK() { return WiFi.status() == WL_CONNECTED; }
static String ipStr() { return netOK() ? WiFi.localIP().toString() : WiFi.softAPIP().toString(); }

static bool isSnes(const String &n) { String l = n; l.toLowerCase(); return l.endsWith(".smc") || l.endsWith(".sfc"); }
#define MAX_ROM_BYTES 2163200u                   // what the emulator's ROM buffer holds (2 MB + header + mapping padding)
static bool safeName(const String &n) { return n.length() && n.indexOf('/') < 0 && n.indexOf('\\') < 0 && n.indexOf("..") < 0; }

// Make any uploaded file name safe for the flash file system: letters, digits, '.', '-', '_' only, <= 30 chars + the original extension.
static String cleanName(String n) {
  int a = n.lastIndexOf('/'), b = n.lastIndexOf('\\');
  int s = a > b ? a : b;
  if (s >= 0) n = n.substring(s + 1);
  String ext = n.substring(n.length() - 4); ext.toLowerCase();   // caller already checked it ends in .smc or .sfc
  String base = n.substring(0, n.length() - 4);
  String out;
  for (size_t i = 0; i < base.length() && out.length() < 30; i++) {
    char c = base[i];
    char last = out.length() ? out[out.length() - 1] : 0;
    if (isalnum((unsigned char)c) || c == '-' || c == '_') out += c;
    else if (c == '.' && last != '.') out += c;
    else if (c != '.' && last != '_' && out.length()) out += '_';   // spaces, brackets, commas, etc.
  }
  while (out.endsWith("_") || out.endsWith(".")) out.remove(out.length() - 1);
  if (!out.length()) out = "game";
  return out + ext;
}

static String jsonEsc(const String &s) {
  String o;
  for (size_t i = 0; i < s.length(); i++) { char c = s[i]; if (c == '"' || c == '\\') o += '\\'; if ((unsigned char)c >= 32) o += c; }
  return o;
}

static void scanRoms() {
  roms.clear(); romSizes.clear();
  File dir = fsOK ? LittleFS.open("/roms") : File();
  if (dir) {
    for (File e = dir.openNextFile(); e; e = dir.openNextFile()) {
      String name = String(e.name());
      int s = name.lastIndexOf('/'); if (s >= 0) name = name.substring(s + 1);
      roms.push_back(name); romSizes.push_back((uint32_t)e.size());
    }
  }
  if (sel >= (int)roms.size()) sel = roms.size() ? roms.size() - 1 : 0;
  romsDirty = false;
}

static void drawUI() {
  gFill(0, 0, SCR_W, SCR_H, cBg);
  gText(2, 1, "SNES GAMES", cTitle);
  char buf[32];
  gText(2, 11, netOK() ? ("IP " + ipStr()).c_str() : ("AP " AP_NAME), netOK() ? cOk : cErr, 21);
  if (!netOK()) gText(2, 20, ("http://" + ipStr() + "/wifi").c_str(), cDim, 21);
  else if (fsOK) {
    snprintf(buf, sizeof(buf), "free %uK of %uK", (unsigned)((LittleFS.totalBytes() - LittleFS.usedBytes()) / 1024), (unsigned)(LittleFS.totalBytes() / 1024));
    gText(2, 20, buf, cDim, 21);
  } else gText(2, 20, "STORAGE NOT MOUNTED", cErr, 21);
  gFill(0, 30, SCR_W, 1, cDim);
  const int rows = 9, y0 = 33;
  if (roms.empty()) {
    gText(2, y0, "No ROMs yet.", cTxt);
    gText(2, y0 + 10, "Open the IP above", cDim);
    gText(2, y0 + 19, "in a browser and", cDim);
    gText(2, y0 + 28, "drop .smc/.sfc", cDim);
  } else {
    int top = sel - rows + 1; if (top < 0) top = 0;
    for (int i = 0; i < rows && top + i < (int)roms.size(); i++) {
      int idx = top + i, y = y0 + i * 10;
      bool s = idx == sel;
      if (s) gFill(0, y - 1, SCR_W, 10, cSel);
      gText(2, y, roms[idx].c_str(), s ? cBg : cTxt, 17);
      snprintf(buf, sizeof(buf), "%uK", (unsigned)(romSizes[idx] / 1024));
      gText(SCR_W - 2 - 6 * strlen(buf), y, buf, s ? cBg : cDim);
    }
  }
  if (statusMsg.length() && millis() - statusAt < 10000) {
    gText(2, SCR_H - 9, statusMsg.c_str(), statusBad ? cErr : cOk, 21);
  } else {
    snprintf(buf, sizeof(buf), "A=play  flash %uMB", (unsigned)(ESP.getFlashChipSize() / (1024 * 1024)));
    gText(2, SCR_H - 9, buf, cDim);
  }
  lcdPush();
}

#include "snesemu.h"
#include "cyberpi_intro.h"

static void launchGame(const String &name) {
  if (!isSnes(name)) { setStatus("Not a .smc/.sfc file", true); return; }   // e.g. an old .nes file: stay in the list
  server.stop();
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  delay(100);
  snesRun(name.c_str());                         // returns only on a load error (message already shown)
  ESP.restart();                                 // clean reset back to the ROM list (also restores WiFi)
}

// ======================================================================= web
const char PAGE[] PROGMEM = R"HTML(
<!doctype html><html><head><meta name=viewport content="width=device-width,initial-scale=1">
<title>CyberPi SNES</title>
<style>
body{font-family:sans-serif;background:#111;color:#eee;max-width:560px;margin:20px auto;padding:0 12px}
#drop{border:3px dashed #6c6;border-radius:12px;padding:40px;text-align:center;color:#6c6}
#drop.hot{background:#1d2b1d}
li{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #333}
button{background:#a33;color:#fff;border:0;border-radius:4px;padding:2px 8px}
progress{width:100%}
a{color:#8cf}
#msg{font-weight:bold;word-break:break-word}
</style></head><body>
<h2>CyberPi SNES</h2>
<div id=drop>Drop .smc / .sfc files here (or tap to choose)</div>
<input id=f type=file multiple hidden>
<progress id=p value=0 max=100 hidden></progress>
<p id=msg></p>
<p id=info></p>
<ul id=list></ul>
<p><a href=/wifi>WiFi settings</a> &middot; firmware SNES v1</p>
<script>
const $=id=>document.getElementById(id);
const drop=$('drop'),f=$('f'),p=$('p');
let free=0;
function say(t,bad){const m=$('msg');m.textContent=t;m.style.color=bad?'#f88':'#8f8'}
drop.onclick=()=>f.click();
drop.ondragover=e=>{e.preventDefault();drop.classList.add('hot')};
drop.ondragleave=()=>drop.classList.remove('hot');
drop.ondrop=e=>{e.preventDefault();drop.classList.remove('hot');up([...e.dataTransfer.files])};
f.onchange=()=>{const a=[...f.files];f.value='';up(a)};
function send(file){return new Promise(res=>{
  const x=new XMLHttpRequest(),d=new FormData();
  d.append('rom',file,file.name);
  p.hidden=false;p.value=0;
  x.upload.onprogress=e=>{if(e.lengthComputable)p.value=e.loaded/e.total*100};
  x.onload=()=>{p.hidden=true;
    if(x.status==200)say(file.name+': uploaded OK',0);
    else say(file.name+': upload FAILED ('+x.status+') - '+(x.responseText||'no message from the CyberPi'),1);
    res()};
  x.onerror=()=>{p.hidden=true;say(file.name+': connection to the CyberPi was lost during the upload. Make sure this device is on the same WiFi and try again.',1);res()};
  x.open('POST','/upload');x.send(d);
})}
async function up(files){
  for(const file of files){
    if(!/\.(smc|sfc)$/i.test(file.name)){say(file.name+': only .smc / .sfc files can be uploaded (unzip it first)',1);continue}
    if(file.size>2163200){say(file.name+': is '+Math.ceil(file.size/1024)+' KB. The biggest ROM the CyberPi can run is 2112 KB.',1);continue}
    if(file.size>free){say(file.name+': is '+Math.ceil(file.size/1024)+' KB but only '+(free/1024|0)+' KB is free on the CyberPi. Delete a ROM first.',1);continue}
    await send(file);
    await load();
  }
}
async function load(){
  try{
    const r=await (await fetch('/list')).json();
    free=r.free;
    $('info').textContent=r.fs?('Free space: '+(r.free/1024|0)+' KB of '+(r.total/1024|0)+' KB'):'';
    if(!r.fs)say('STORAGE NOT MOUNTED on the CyberPi - uploads cannot work. Make sure partitions.csv is in the sketch folder and re-flash.',1);
    const l=$('list');l.innerHTML='';
    r.roms.forEach(o=>{
      const li=document.createElement('li'),s=document.createElement('span');
      s.textContent=o.name+' ('+(o.size/1024|0)+' KB)';
      const b=document.createElement('button');b.textContent='delete';
      b.onclick=async()=>{await fetch('/delete?name='+encodeURIComponent(o.name));load()};
      li.appendChild(s);li.appendChild(b);l.appendChild(li);
    });
  }catch(e){say('Cannot read the ROM list from the CyberPi: '+e,1)}
}
load();
</script></body></html>
)HTML";

static void handleList() {
  uint32_t total = fsOK ? LittleFS.totalBytes() : 0, used = fsOK ? LittleFS.usedBytes() : 0;
  String out = String("{\"fs\":") + (fsOK ? "true" : "false") + ",\"total\":" + String((unsigned)total) +
               ",\"free\":" + String((unsigned)(total > used ? total - used : 0)) + ",\"roms\":[";
  for (size_t i = 0; i < roms.size(); i++) {
    if (i) out += ",";
    out += "{\"name\":\"" + jsonEsc(roms[i]) + "\",\"size\":" + String((unsigned)romSizes[i]) + "}";
  }
  out += "]}";
  server.send(200, "application/json", out);
}

static void handleDelete() {
  String n = server.arg("name");
  if (fsOK && safeName(n) && LittleFS.remove("/roms/" + n)) { romsDirty = true; scanRoms(); server.send(200, "text/plain", "ok"); }
  else server.send(404, "text/plain", "not found");
}

static bool uploadFailed = false;
static String uploadErr;
static String uploadPath;
static uint32_t uploadBytes = 0;

static void failUpload(const String &why) {
  if (uploadFailed) return;
  uploadFailed = true; uploadErr = why;
  Serial.println("UPLOAD FAILED: " + why);
  setStatus("Upload failed", true);
}

static void handleUploadData() {
  HTTPUpload &u = server.upload();
  if (u.status == UPLOAD_FILE_START) {
    uploadFailed = false; uploadErr = ""; uploadPath = ""; uploadBytes = 0;
    if (uploadFile) uploadFile.close();
    Serial.println("Upload start: '" + u.filename + "'");
    if (!fsOK) { failUpload("storage is not mounted (LittleFS failed to start). Make sure partitions.csv is in the sketch folder and re-flash."); return; }
    if (!isSnes(u.filename)) { failUpload("'" + u.filename + "' is not a .smc or .sfc file"); return; }
    String n = cleanName(u.filename);
    uploadPath = "/roms/" + n;
    uploadFile = LittleFS.open(uploadPath, "w");
    if (!uploadFile) { failUpload("cannot create " + uploadPath + " (storage full or not writable)"); return; }
    splash("Receiving ROM...", n.c_str());
  } else if (u.status == UPLOAD_FILE_WRITE) {
    if (uploadFailed || !uploadFile) return;
    if (uploadBytes == 0 && u.currentSize >= 4 && (memcmp(u.buf, "PK\x03\x04", 4) == 0 || memcmp(u.buf, "NES\x1A", 4) == 0)) {
      failUpload("this file is a .zip or a NES ROM, not a SNES ROM. Unzip it first.");
      return;
    }
    size_t w = uploadFile.write(u.buf, u.currentSize);
    if (w != u.currentSize) {
      uint32_t freeB = LittleFS.totalBytes() - LittleFS.usedBytes();
      failUpload("storage is full after " + String((unsigned)(uploadBytes / 1024)) + " KB (" + String((unsigned)(freeB / 1024)) + " KB free). Delete a ROM and try again.");
      return;
    }
    uploadBytes += w;
  } else if (u.status == UPLOAD_FILE_END) {
    if (uploadFile) uploadFile.close();
    if (!uploadFailed && uploadPath.length()) {
      File chk = LittleFS.open(uploadPath, "r");
      size_t got = chk ? chk.size() : 0;
      if (chk) chk.close();
      if (got > MAX_ROM_BYTES) failUpload("ROM is " + String((unsigned)(got / 1024)) + " KB; the biggest the CyberPi can run is 2112 KB");
      else if (got != u.totalSize) failUpload("saved " + String((unsigned)got) + " bytes but " + String((unsigned)u.totalSize) + " were sent");
      else { Serial.printf("Upload OK: %s (%u bytes)\n", uploadPath.c_str(), (unsigned)got); setStatus("Upload OK", false); }
    }
    if (uploadFailed && uploadPath.length()) LittleFS.remove(uploadPath);   // never keep a broken ROM
    romsDirty = true;
  } else if (u.status == UPLOAD_FILE_ABORTED) {
    if (uploadFile) uploadFile.close();
    if (uploadPath.length()) LittleFS.remove(uploadPath);
    failUpload("upload was interrupted (WiFi dropped or the page was closed)");
    romsDirty = true;
  }
}

static void handleWifi() {
  String b = "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><body style='font-family:sans-serif;max-width:480px;margin:20px auto;padding:0 12px'>"
             "<h3>WiFi settings</h3><form method=post action=/wifisave>"
             "Name<br><input name=s style='width:100%'><br>Password<br><input name=p type=password style='width:100%'><br><br>"
             "<button>Save & restart</button></form>";
  server.send(200, "text/html", b);
}
static void handleWifiSave() {
  prefs.putString("ssid", server.arg("s")); prefs.putString("pass", server.arg("p"));
  server.send(200, "text/html", "<body style='font-family:sans-serif'>Saved. Restarting - reconnect to your normal WiFi.");
  delay(800); ESP.restart();
}

// ======================================================================= main
void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\nCyberPi SNES v1");
  esp_bt_controller_mem_release(ESP_BT_MODE_BTDM);   // Bluetooth unused: give its memory back
  Wire.begin(I2C_SDA, I2C_SCL); Wire.setClock(400000);
  expanderInit();

  g_fb = (uint16_t *)malloc(SCR_W * SCR_H * 2);
  cBg = C565(0, 0, 0); cTitle = C565(255, 220, 0); cTxt = C565(255, 255, 255);
  cDim = C565(150, 150, 150); cSel = C565(120, 255, 120); cOk = C565(120, 255, 120); cErr = C565(255, 120, 120);
  lcdBegin();
  introBoot();                                        // start-up animation + sound (any button skips)
  splash("Starting...");

  fsOK = LittleFS.begin(true);
  if (!fsOK) {
    splash("Storage FAILED", "LittleFS mount error");
    Serial.println("LittleFS mount failed - no usable storage partition. Is partitions.csv in the sketch folder?");
    delay(2500);
  } else {
    LittleFS.mkdir("/roms");
    Serial.printf("Flash %u MB, FS %u / %u bytes used\n", (unsigned)(ESP.getFlashChipSize() / 1048576), (unsigned)LittleFS.usedBytes(), (unsigned)LittleFS.totalBytes());
  }

  prefs.begin("gbc", false);                          // namespace kept so saved WiFi still works
  String ssid = prefs.getString("ssid", WIFI_SSID_DEFAULT), pass = prefs.getString("pass", WIFI_PASS_DEFAULT);
  if (ssid.length()) {
    WiFi.mode(WIFI_STA); WiFi.setAutoReconnect(true); WiFi.begin(ssid.c_str(), pass.c_str());
    splash("Connecting WiFi", ssid.c_str());
    for (int i = 0; i < 40 && !netOK(); i++) delay(500);
  }
  if (!netOK()) { wantAP = true; WiFi.mode(WIFI_AP_STA); WiFi.softAP(AP_NAME); if (ssid.length()) WiFi.begin(ssid.c_str(), pass.c_str()); }

  server.on("/", HTTP_GET, []() { server.send_P(200, "text/html", PAGE); });
  server.on("/list", HTTP_GET, handleList);
  server.on("/delete", HTTP_GET, handleDelete);
  server.on("/wifi", HTTP_GET, handleWifi);
  server.on("/wifisave", HTTP_POST, handleWifiSave);
  server.on("/upload", HTTP_POST, []() {
    if (uploadFailed) server.send(500, "text/plain", uploadErr); else server.send(200, "text/plain", "ok");
  }, handleUploadData);
  server.begin();
  Serial.printf("Open http://%s\n", ipStr().c_str());
  scanRoms();
  drawUI();
}

void loop() {
  server.handleClient();
  static uint16_t prev = 0; static uint32_t lastDraw = 0; static bool wasNet = false;
  uint16_t b;
  bool redraw = false;
  if (readButtons(b)) {
    uint16_t pressed = b & ~prev; prev = b;
    if ((pressed & B_UP) && sel > 0) { sel--; redraw = true; }
    if ((pressed & B_DOWN) && sel + 1 < (int)roms.size()) { sel++; redraw = true; }
    if ((pressed & (B_A | B_CENTER)) && !roms.empty()) launchGame(roms[sel]);   // returns only if it is not a SNES file
  }
  if (romsDirty) { scanRoms(); redraw = true; }
  if (netOK() != wasNet) { wasNet = netOK(); redraw = true; }
  if (redraw || millis() - lastDraw > 5000) { drawUI(); lastDraw = millis(); }
  delay(10);
}
