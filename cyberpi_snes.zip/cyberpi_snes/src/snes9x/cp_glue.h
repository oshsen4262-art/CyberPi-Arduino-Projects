/* cp_glue.h - tiny C interface between the CyberPi sketch and the Snes9x core (so the sketch never includes Snes9x headers). */
#ifndef CP_GLUE_H
#define CP_GLUE_H
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif

/* SNES pad bits (same values as the core uses) */
#define CP_PAD_TR      (1u << 4)    /* R */
#define CP_PAD_TL      (1u << 5)    /* L */
#define CP_PAD_X       (1u << 6)
#define CP_PAD_A       (1u << 7)
#define CP_PAD_RIGHT   (1u << 8)
#define CP_PAD_LEFT    (1u << 9)
#define CP_PAD_DOWN    (1u << 10)
#define CP_PAD_UP      (1u << 11)
#define CP_PAD_START   (1u << 12)
#define CP_PAD_SELECT  (1u << 13)
#define CP_PAD_Y       (1u << 14)
#define CP_PAD_B       (1u << 15)

#define CP_SCREEN_W 256
#define CP_SCREEN_H 224

/* 0 = ok. Allocates everything. sample_rate = mixer rate (e.g. 22080). */
int  cp_snes_init(uint32_t sample_rate);
/* Buffer the ROM file is read into, and its capacity in bytes. Valid after cp_snes_init(). */
uint8_t *cp_snes_rom_buffer(uint32_t *capacity);
/* After the ROM file was read into that buffer: parse it and reset the machine. 0 = ok. */
int  cp_snes_load(uint32_t file_size);
void cp_snes_set_pad(uint32_t mask);
/* Run one emulated frame. render = 0 skips drawing (much faster). */
void cp_snes_frame(int render);
/* RGB565 (native little-endian) 256 x 224 picture of the last rendered frame. */
const uint16_t *cp_snes_screen(void);
/* Mix one frame of audio as mono int16 (L+R averaged). Returns the number of samples written (<= max). */
int  cp_snes_mix_mono(int16_t *out, int max);
int  cp_snes_samples_per_frame(void);
int  cp_snes_fps(void);                 /* 60 (NTSC) or 50 (PAL) */
const char *cp_snes_title(void);
/* Short text like "WI VP SP RP": work RAM, video RAM, sound RAM, ROM in Internal (fast) or PSRAM (slow). */
void cp_snes_mem_report(char *out, int n);
/* Draw in strips of this many lines (8 = fast on the ESP32, 0 = whole frame at once like the original). */
void cp_snes_set_strip(int lines);
/* Battery save RAM: size in bytes (0 = none), pointer, modified flag. */
uint32_t cp_snes_sram(uint8_t **ptr);
int  cp_snes_sram_modified(void);
void cp_snes_sram_clear_modified(void);

#ifdef __cplusplus
}
#endif
#endif
