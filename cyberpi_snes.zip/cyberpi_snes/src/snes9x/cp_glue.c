/* cp_glue.c - CyberPi glue for the Snes9x core (video buffers, input, audio mixing, memory placement). */
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "snes9x.h"
#include "soundux.h"
#include "memmap.h"
#include "apu.h"
#include "display.h"
#include "gfx.h"
#include "cpuexec.h"
#include "ppu.h"
#include "cp_glue.h"
#if defined(ESP_PLATFORM)
#include "esp_heap_caps.h"
#endif

/* ----------------------------------------------------------------- memory placement */
#define CP_INTERNAL_RESERVE (64 * 1024)    /* always leave this much internal RAM for the DAC, tasks, stacks, WiFi-less Arduino */

void *cp_malloc(size_t n)
{
#if defined(ESP_PLATFORM)
   void *p = NULL;
   if (n >= 4096) p = heap_caps_malloc(n, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
   if (!p) p = heap_caps_malloc(n, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
   if (!p) p = heap_caps_malloc(n, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
   return p;
#else
   return (malloc)(n);
#endif
}

void *cp_calloc(size_t n, size_t m)
{
   if (m && n > (size_t)-1 / m) return NULL;
   void *p = cp_malloc(n * m);
   if (p) memset(p, 0, n * m);
   return p;
}

/* Hot data (the 128 KB of work RAM) goes to fast internal RAM if there is room left, otherwise PSRAM. */
void *cp_fast_malloc(size_t n)
{
#if defined(ESP_PLATFORM)
   if (heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT) >= n + CP_INTERNAL_RESERVE) {
      void *p = heap_caps_malloc(n, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
      if (p) return p;
   }
#endif
   return cp_malloc(n);
}

/* ----------------------------------------------------------------- callbacks the core wants */
static volatile uint32_t cpPad = 0;
static int cpSamplesPerFrame = 368;
static uint32_t cpRate = 22080;
static uint8_t *cpRomBuf = NULL;

bool S9xInitDisplay(void)
{
   GFX.Pitch = SNES_WIDTH * 2;
   GFX.ZPitch = SNES_WIDTH;
   GFX.Screen = (uint8_t *)cp_malloc(GFX.Pitch * SNES_HEIGHT_EXTENDED);
   GFX.SubScreen = (uint8_t *)cp_malloc(GFX.Pitch * SNES_HEIGHT_EXTENDED);
   GFX.ZBuffer = (uint8_t *)cp_malloc(GFX.ZPitch * SNES_HEIGHT_EXTENDED);
   GFX.SubZBuffer = (uint8_t *)cp_malloc(GFX.ZPitch * SNES_HEIGHT_EXTENDED);
   if (GFX.Screen) memset(GFX.Screen, 0, GFX.Pitch * SNES_HEIGHT_EXTENDED);
   return GFX.Screen && GFX.SubScreen && GFX.ZBuffer && GFX.SubZBuffer;
}
void S9xDeinitDisplay(void) {}
uint32_t S9xReadJoypad(int32_t port) { return port == 0 ? cpPad : 0; }
bool S9xReadMousePosition(int32_t which1, int32_t *x, int32_t *y, uint32_t *buttons) { (void)which1; (void)x; (void)y; (void)buttons; return false; }
bool S9xReadSuperScopePosition(int32_t *x, int32_t *y, uint32_t *buttons) { (void)x; (void)y; (void)buttons; return false; }
bool JustifierOffscreen(void) { return true; }
void JustifierButtons(uint32_t *justifiers) { (void)justifiers; }

/* ----------------------------------------------------------------- public API */
int cp_snes_init(uint32_t sample_rate)
{
   cpRate = sample_rate;
   Settings.CyclesPercentage = 100;
   Settings.H_Max = SNES_CYCLES_PER_SCANLINE;
   Settings.FrameTimePAL = 20000;
   Settings.FrameTimeNTSC = 16667;
   Settings.ControllerOption = SNES_JOYPAD;
   Settings.HBlankStart = (256 * Settings.H_Max) / SNES_HCOUNTER_MAX;
   Settings.SoundPlaybackRate = sample_rate;
   Settings.SoundInputRate = sample_rate;
   Settings.DisableSoundEcho = false;
   Settings.InterpolatedSound = false;      /* cheaper; turn on in cp_glue.c if there is CPU time to spare */

   if (!S9xInitDisplay()) return 1;
   if (!S9xInitMemory()) return 2;
   if (!S9xInitAPU()) return 3;
   if (!S9xInitSound(0, 0)) return 4;
   if (!S9xInitGFX()) return 5;
   cpRomBuf = Memory.ROM;
   return 0;
}

uint8_t *cp_snes_rom_buffer(uint32_t *capacity)
{
   if (capacity) *capacity = (uint32_t)Memory.ROM_AllocSize;
   return cpRomBuf;
}

int cp_snes_load(uint32_t file_size)
{
   Memory.ROM_AllocSize = file_size;        /* LoadROM(NULL) treats the buffer as the whole ROM file */
   if (!LoadROM(NULL)) return 1;
   S9xSetPlaybackRate(cpRate);
   cpSamplesPerFrame = (int)(cpRate / (Memory.ROMFramesPerSecond > 0 ? Memory.ROMFramesPerSecond : 60));
   return 0;
}

void cp_snes_set_pad(uint32_t mask) { cpPad = mask; }

void cp_snes_frame(int render)
{
   IPPU.RenderThisFrame = render ? true : false;
   S9xMainLoop();
}

const uint16_t *cp_snes_screen(void) { return (const uint16_t *)GFX.Screen; }

int cp_snes_samples_per_frame(void) { return cpSamplesPerFrame; }
int cp_snes_fps(void) { return Memory.ROMFramesPerSecond > 0 ? Memory.ROMFramesPerSecond : 60; }

int cp_snes_mix_mono(int16_t *out, int max)
{
   static int16_t st[1024];
   int n = cpSamplesPerFrame;
   if (n > 512) n = 512;
   if (n > max) n = max;
   S9xMixSamples(st, n * 2);                /* count = int16 values: L,R,L,R... */
   for (int i = 0; i < n; i++) out[i] = (int16_t)(((int)st[2 * i] + (int)st[2 * i + 1]) >> 1);
   return n;
}

const char *cp_snes_title(void) { return Memory.ROMName; }

uint32_t cp_snes_sram(uint8_t **ptr)
{
   uint32_t sz = Memory.SRAMSize ? ((1u << (Memory.SRAMSize + 3)) * 128u) : 0;
   if (sz > SRAM_SIZE) sz = SRAM_SIZE;
   if (ptr) *ptr = Memory.SRAM;
   return sz;
}
int  cp_snes_sram_modified(void) { return CPU.SRAMModified ? 1 : 0; }
void cp_snes_sram_clear_modified(void) { CPU.SRAMModified = false; }

/* Where the hot blocks ended up: I = fast internal RAM, P = slow PSRAM. For the on-screen speed display. */
static char cpWhere(const void *p) { return ((uintptr_t)p >= 0x3FF80000u && (uintptr_t)p < 0x40000000u) ? 'I' : 'P'; }
void cp_snes_mem_report(char *out, int n)
{
   snprintf(out, n, "W%c V%c S%c R%c", cpWhere(Memory.RAM), cpWhere(Memory.VRAM), cpWhere(IAPU.RAM), cpWhere(Memory.ROM));
}

extern int cp_strip_lines;
void cp_snes_set_strip(int lines) { cp_strip_lines = lines; }
