// cyberpi_intro.h - "CyberPi Entertainment" start-up animation + the real start-up sound (cyberpi_psx_sound.h).
// Included from cyberpi_gbc.ino AFTER snesemu.h. Not a standalone file.
//
// What plays and when:
//   * Power-on:        the intro from the start of the sound (INTRO_BOOT_END_MS long, fades out at the end). A silver gem spins up
//                      out of the dark, the big hit lands at INTRO_STRIKE_S with a flash, and "CyberPi ENTERTAINMENT" shines.
//                      Press any button to skip it.
//   * Opening a game: only the ending: the big hit + flash + logo, INTRO_LAUNCH_LEN_MS long (2 s), then the game starts.
//
// Tweak here:
#define INTRO_AT_BOOT          1        // 1 = play the intro when the CyberPi powers on, 0 = never
#define INTRO_AT_LAUNCH        1        // 1 = play the short ending every time a game is opened, 0 = never
#define INTRO_VOL_PCT          85       // loudness of the sound, percent (100 = as recorded; lower it if the speaker buzzes)
#define INTRO_STRIKE_S         3.0f     // when the big hit lands in the sound (seconds from its start): drives the flash/logo
#define INTRO_BOOT_END_MS      8000     // power-on intro length (the stored sound is 8 s; do not go above that)
#define INTRO_BOOT_FADE_MS     1000     // fade to black / silence at the end of the power-on intro
#define INTRO_LAUNCH_START_MS  2900     // game launch starts here in the sound (just before the big hit)...
#define INTRO_LAUNCH_LEN_MS    2000     // ...and lasts this long, then the game comes up
#define INTRO_LAUNCH_FADE_MS   400
#define INTRO_NAME_1           "CyberPi"
#define INTRO_NAME_2           "ENTERTAINMENT"
#pragma once
#include <math.h>
#include "cyberpi_psx_sound.h"

static float introEndS = 8.0f, introFadeS = 1.0f, introStartS = 0.0f;   // set by introPlay()

// ======================================================================= picture (pure drawing, no hardware)
static inline float introClamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

static void introLine(int x0, int y0, int x1, int y1, uint16_t c) {
  int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
  for (int n = 0; n < 300; n++) {
    gPx(x0, y0, c);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}

static void introTri(float x0, float y0, float x1, float y1, float x2, float y2, uint16_t c) {
  int minx = (int)floorf(fminf(x0, fminf(x1, x2))), maxx = (int)ceilf(fmaxf(x0, fmaxf(x1, x2)));
  int miny = (int)floorf(fminf(y0, fminf(y1, y2))), maxy = (int)ceilf(fmaxf(y0, fmaxf(y1, y2)));
  if (minx < 0) minx = 0;
  if (miny < 0) miny = 0;
  if (maxx > SCR_W - 1) maxx = SCR_W - 1;
  if (maxy > SCR_H - 1) maxy = SCR_H - 1;
  float d = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2);
  if (fabsf(d) < 1e-3f) return;
  float id = 1.0f / d;
  for (int y = miny; y <= maxy; y++) {
    for (int x = minx; x <= maxx; x++) {
      float px = x + 0.5f, py = y + 0.5f;
      float a = ((y1 - y2) * (px - x2) + (x2 - x1) * (py - y2)) * id;
      float b = ((y2 - y0) * (px - x2) + (x0 - x2) * (py - y2)) * id;
      float g = 1.0f - a - b;
      if (a >= -0.02f && b >= -0.02f && g >= -0.02f) g_fb[y * SCR_W + x] = c;
    }
  }
}

static uint16_t introGray(float v) {                              // v 0..255 -> slightly cool silver
  v = introClamp(v, 0, 255);
  return C565((uint8_t)(v * 0.86f), (uint8_t)(v * 0.92f), (uint8_t)v);
}

static void introText(int cx, int y, const char *s, int scale, uint8_t v) {   // centered, scaled 5x8 font
  int n = (int)strlen(s), w = n * CHAR_W * scale - scale;
  int x = cx - w / 2;
  uint16_t c = C565(v, v, v);
  for (int i = 0; i < n; i++, x += CHAR_W * scale) {
    char ch = s[i]; if (ch < 32 || ch > 126) ch = '?';
    const uint8_t *g = FONT5X8 + (ch - 32) * 5;
    for (int col = 0; col < 5; col++)
      for (int r = 0; r < 8; r++)
        if (g[col] & (1 << r)) gFill(x + col * scale, y + r * scale, scale, scale, c);
  }
}

// One picture of the intro. tl = seconds on the sound's timeline.
static void introRender(float tl) {
  const float S = INTRO_STRIKE_S;
  float fadeIn = introClamp((tl - introStartS) / 0.12f, 0, 1);
  float fadeOut = introClamp((introEndS - tl) / introFadeS, 0, 1);
  float g = fadeIn * fadeOut;                                         // master brightness
  float grow = introClamp((tl - 0.2f) / (S - 0.5f), 0, 1); grow = grow * grow * (3 - 2 * grow);   // smoothstep up to the hit
  float flash = tl > S ? expf(-(tl - S) / 0.35f) : 0.0f;
  gFill(0, 0, SCR_W, SCR_H, C565(0, 0, 0));

  const float cx = 64, cy = 45;
  float R = 6 + 25 * grow;

  // soft glow behind the gem
  float glow = (0.12f * grow + 0.45f * flash) * g;
  if (glow > 0.01f) {
    const int gr = 46;
    for (int y = (int)cy - gr; y <= (int)cy + gr; y++) for (int x = (int)cx - gr; x <= (int)cx + gr; x++) {
      float dx = x - cx, dy = y - cy, d2 = dx * dx + dy * dy;
      if (d2 >= gr * gr) continue;
      float k = 1.0f - sqrtf(d2) / gr; k *= k;
      gPx(x, y, introGray(255.0f * k * glow));
    }
  }

  // the gem: an octahedron spinning around its vertical axis, tilted toward the viewer
  float ang = tl < S ? 2.0f * tl : 2.0f * S + 0.7f * (tl - S);
  float ca = cosf(ang), sa = sinf(ang), tilt = 0.42f, ct = cosf(tilt), st = sinf(tilt);
  const float H = 1.35f;                                              // taller than wide
  float vx[6] = {1, -1, 0, 0, 0, 0}, vy[6] = {0, 0, H, -H, 0, 0}, vz[6] = {0, 0, 0, 0, 1, -1};
  float px[6], py[6];
  for (int i = 0; i < 6; i++) {
    float x1 = vx[i] * ca + vz[i] * sa, z1 = -vx[i] * sa + vz[i] * ca;
    float y2 = vy[i] * ct - z1 * st;
    px[i] = cx + x1 * R; py[i] = cy - y2 * R;
  }
  const float lx = -0.40f, ly = 0.70f, lz = 0.60f;                    // light direction (already ~unit)
  for (int f = 0; f < 8; f++) {
    float sx = (f & 1) ? -1 : 1, sy = (f & 2) ? -1 : 1, sz = (f & 4) ? -1 : 1;
    int a = (f & 1) ? 1 : 0, b = (f & 2) ? 3 : 2, c = (f & 4) ? 5 : 4;
    float nx = sx, ny = sy / H, nz = sz;                              // outward normal of this face
    float nl = sqrtf(nx * nx + ny * ny + nz * nz); nx /= nl; ny /= nl; nz /= nl;
    float n1x = nx * ca + nz * sa, n1z = -nx * sa + nz * ca;
    float n2y = ny * ct - n1z * st, n2z = ny * st + n1z * ct;
    if (n2z <= 0.0f) continue;                                        // facing away
    float dot = n1x * lx + n2y * ly + n2z * lz;
    float br = 0.30f + 0.70f * fmaxf(dot, 0.0f) + 0.35f * flash;
    float v = 255.0f * br * g * (0.45f + 0.55f * grow);
    introTri(px[a], py[a], px[b], py[b], px[c], py[c], introGray(v));
    uint16_t e = introGray(v * 1.25f + 20 * g);
    introLine((int)px[a], (int)py[a], (int)px[b], (int)py[b], e);
    introLine((int)px[b], (int)py[b], (int)px[c], (int)py[c], e);
    introLine((int)px[c], (int)py[c], (int)px[a], (int)py[a], e);
  }

  // sparkle at the hit
  if (tl > S && tl < S + 0.9f) {
    float k = sinf(3.14159f * (tl - S) / 0.9f);
    int L = (int)(20 * k), sx0 = (int)(cx - R * 0.35f), sy0 = (int)(cy - R * 0.75f);
    uint16_t c = introGray(255.0f * g);
    introLine(sx0 - L, sy0, sx0 + L, sy0, c); introLine(sx0, sy0 - L, sx0, sy0 + L, c);
    introLine(sx0 - L / 3, sy0 - L / 3, sx0 + L / 3, sy0 + L / 3, c); introLine(sx0 - L / 3, sy0 + L / 3, sx0 + L / 3, sy0 - L / 3, c);
  }

  // name: appears just before the hit and is fully lit as it lands
  float a1 = introClamp((tl - (S - 1.0f)) / 0.8f, 0, 1) * g, a2 = introClamp((tl - (S - 0.5f)) / 0.7f, 0, 1) * g;
  if (a1 > 0.01f) introText(64, 82, INTRO_NAME_1, 2, (uint8_t)(255 * a1));
  if (a2 > 0.01f) introText(64, 104, INTRO_NAME_2, 1, (uint8_t)(210 * a2));
}

// ======================================================================= sound (stored 22 kHz sample -> 44.16 kHz DAC bytes)
// Fill dac[0..n) for timeline position tl0 (seconds) at the DAC rate `rate` (= 2 x INTRO_SND_RATE): 2x linear interpolation,
// volume, a short fade-in when starting mid-sound and a fade-out at the end. 128 = silence.
static void introSndBlock(uint8_t *dac, int n, float tl0, int rate) {
  uint32_t src0 = (uint32_t)(introStartS * INTRO_SND_RATE + 0.5f);
  uint32_t k0 = (uint32_t)((tl0 - introStartS) * rate + 0.5f);        // output sample index since the start of this playback
  float t1 = tl0 + (float)n / rate;
  float f0 = introClamp((introEndS - tl0) / introFadeS, 0, 1) * introClamp((tl0 - introStartS) / 0.03f, 0, 1);
  float f1 = introClamp((introEndS - t1) / introFadeS, 0, 1) * introClamp((t1 - introStartS) / 0.03f, 0, 1);
  float vol = INTRO_VOL_PCT / 100.0f;
  for (int i = 0; i < n; i++) {
    uint32_t k = k0 + i, si = src0 + (k >> 1);
    int a = si < INTRO_SND_LEN ? introSnd[si] : 128;
    int b = si + 1 < INTRO_SND_LEN ? introSnd[si + 1] : 128;
    float s = (k & 1) ? 0.5f * (a + b) : (float)a;
    float f = (f0 + (f1 - f0) * i / n) * vol;
    int v = 128 + (int)((s - 128.0f) * f);
    dac[i] = (uint8_t)(v < 0 ? 0 : (v > 255 ? 255 : v));
  }
}

// ======================================================================= playback on the device
#ifndef INTRO_HOST_TEST
// Blocking write of DAC bytes (waits for room in the DMA queue; that is what paces the animation).
static void introAudioPush(const uint8_t *dac, int count) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  size_t sent = 0;
  while (sent < (size_t)count) {
    size_t done = 0;
    if (dac_continuous_write(snesDac, (uint8_t *)dac + sent, count - sent, &done, 200) != ESP_OK && done == 0) return;
    sent += done;
  }
#else
  static uint16_t out[SNES_SND_MAX * 2];
  for (int i = 0; i < count; i++) { uint16_t w = (uint16_t)dac[i] << 8; out[2 * i] = w; out[2 * i + 1] = w; }
  size_t done = 0;
  i2s_write(I2S_NUM_0, out, count * 4, &done, 200 / portTICK_PERIOD_MS);
#endif
}

// Close the speaker again (power-on intro only: WiFi starts right afterwards). Amp off first so nothing thumps.
static void introAudioShutdown() {
  if (!snesAudioOk) return;
  delay(80);
  pw(PIN_AMP_EN, LOW);
  delay(5);
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  dac_continuous_disable(snesDac); dac_continuous_del_channels(snesDac); snesDac = nullptr;
#else
  i2s_driver_uninstall(I2S_NUM_0);
#endif
  snesAudioOk = false;
}

// Play the sound + picture from startMs to endMs on the sound's timeline. The sound is the clock: the picture follows it.
// Uses I2C/SPI directly, so call it only while the video task does NOT exist yet.
static void introPlay(uint32_t startMs, uint32_t endMs, uint32_t fadeMs, bool allowSkip) {
  const int BLK = SNES_SAMPLE_RATE / 60;                              // 736 samples = 1/60 s
  introStartS = startMs / 1000.0f; introEndS = endMs / 1000.0f; introFadeS = fadeMs / 1000.0f;
  float dur = introEndS - introStartS;
  uint32_t total = (uint32_t)(dur * SNES_SAMPLE_RATE);
  if (!snesAudioOk) snesAudioInit();                                   // amp on + DAC running
  bool snd = snesAudioOk;
  static uint8_t dac[SNES_SND_MAX];
  uint32_t done = 0;
  if (snd) { memset(dac, 128, BLK); introAudioPush(dac, BLK); }      // one block of silence first: no click at the start
  uint32_t t0 = millis();
  for (;;) {
    float el = (millis() - t0) / 1000.0f - 0.06f;                    // the picture trails the sound's queue slightly
    if (el < 0) el = 0;
    if (snd) {
      while (done < total && done * 1000.0f / SNES_SAMPLE_RATE < el * 1000.0f + 170.0f) {   // keep ~170 ms of sound queued
        introSndBlock(dac, BLK, introStartS + (float)done / SNES_SAMPLE_RATE, SNES_SAMPLE_RATE);
        introAudioPush(dac, BLK);
        done += BLK;
      }
    }
    if (el >= dur) break;
    introRender(introStartS + el);
    lcdPush();
    if (allowSkip && el > 0.4f) { uint16_t b; if (readButtons(b) && b) break; }
  }
  if (snd) { memset(dac, 128, BLK); introAudioPush(dac, BLK); }      // leave the speaker line quiet
  gFill(0, 0, SCR_W, SCR_H, C565(0, 0, 0));
  lcdPush();
}

static void introBoot() {
#if INTRO_AT_BOOT
  introPlay(0, INTRO_BOOT_END_MS, INTRO_BOOT_FADE_MS, true);
  introAudioShutdown();                                              // release the speaker again before WiFi starts
#endif
}
// Called by snesRun() right before the game starts (speaker already open, video task not started yet).
static void introLaunch() {
#if INTRO_AT_LAUNCH
  introPlay(INTRO_LAUNCH_START_MS, INTRO_LAUNCH_START_MS + INTRO_LAUNCH_LEN_MS, INTRO_LAUNCH_FADE_MS, false);
#endif
}
#endif   // INTRO_HOST_TEST
