// snesemu.h - Super Nintendo emulator glue for the CyberPi (Snes9x core in src/snes9x/, see cp_glue.c).
// Included from cyberpi_snes.ino AFTER the display/button/splash code. Not a standalone file.
//
// Controls while playing (the CyberPi has fewer buttons than a SNES pad, so MENU works as a "shift" key):
//   joystick = D-pad          A = A          B = B          joystick PRESS = START
//   hold MENU + A = X         MENU + B = Y   MENU + LEFT = L   MENU + RIGHT = R   MENU + joystick PRESS = SELECT
//   MENU + UP / MENU + DOWN = volume up / down (shown on screen, remembered)
//   hold MENU alone for 1 second = SETTINGS menu (volume, frame skip, FPS display, exit to the file list)
//   hold MENU + joystick PRESS for 1.5 s = save and exit to the ROM list
//
// Sound: Snes9x mixes mono at SNES_GAME_RATE and it plays through the ESP32 DAC (GPIO25) -> speaker amp.
// Threads: the emulator runs on the Arduino loop task (core 1). A second task (core 0) owns ALL I2C and SPI traffic
// while a game runs (screen push + button polling), so the two never collide.
// Speed: the original ESP32 is at the very edge for a SNES. The loop skips drawing frames when it falls behind
// (SNES_MAX_SKIP), so the picture may update 15-30 times a second on busy games while the game logic keeps real-time speed.
#pragma once
#include "esp_timer.h"
#include "esp_heap_caps.h"
#if __has_include("esp_arduino_version.h")
  #include "esp_arduino_version.h"
#endif
#ifndef ESP_ARDUINO_VERSION_MAJOR
  #define ESP_ARDUINO_VERSION_MAJOR 1      // very old core without the version header: use the I2S path
#endif
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  #include "driver/dac_continuous.h"      // Arduino-ESP32 3.x (IDF 5): the old I2S built-in-DAC mode was removed
#else
  #include "driver/i2s.h"                 // Arduino-ESP32 2.x (IDF 4): I2S port 0 in built-in-DAC mode (what Makeblock's library uses)
#endif
#include "src/snes9x/cp_glue.h"

// ---------------------------------------------------------------- settings you may want to change
#define SNES_SAMPLE_RATE  44160          // DAC rate used by the start-up intro (it needs exactly this). Do not change.
#define SNES_GAME_RATE    22080          // mixer + DAC rate while a game runs. 22080 = 368 samples/frame. Lower (16020) = faster, duller sound
#define SNES_SND_MAX      768            // largest block the DAC queue takes (one intro frame = 736)
#define SNES_VOL_DEFAULT  6              // starting volume, 0..12 (8 = full scale, above 8 = boosted and may crackle). Change it in the game with MENU + UP / DOWN
#define SNES_SWAP_RB      1              // 1 = swap red and blue if the colour test screen shows them the wrong way round
#define SNES_MAX_SKIP     5              // frame skip "Auto": when behind, draw at most 1 frame in (SNES_MAX_SKIP + 1)
#define SNES_AUDIO_ON     1              // 0 = no sound at all (saves CPU time, handy to test speed)
#define PIN_AMP_EN        111            // AW9523B P1.3 (100 + 8 + 3): speaker amplifier enable

static volatile uint16_t snesBtn = 0;
static volatile bool snesBusy = false;          // true while the video task is still sending the last frame
static volatile bool snesQuit = false;          // set by the video task when the exit combo was held
static TaskHandle_t snesVidTask = nullptr;

// ---- area-average scaler: 256x224 RGB565 -> 128x128 (2 source columns x 1.75 source rows per output pixel) ----
// Why average instead of picking pixels: SNES games scroll in 1-pixel steps, and picking every 2nd pixel makes thin lines
// and text flicker. Rows: 224 / 128 = 7/4, so each output row covers up to 3 source rows with quarter-row weights (sum 7).
static uint8_t snesRowIdx[SCR_H][3];
static uint8_t snesRowWt[SCR_H][3];
static void snesBuildScale() {
  for (int dy = 0; dy < SCR_H; dy++) {
    int a = 7 * dy, b = a + 7, r = a >> 2, k = 0;
    while (a < b && k < 3) {
      int nx = min(b, (r + 1) * 4);
      snesRowIdx[dy][k] = (uint8_t)r;
      snesRowWt[dy][k] = (uint8_t)(nx - a);
      k++; a = nx; r++;
    }
    for (; k < 3; k++) { snesRowIdx[dy][k] = snesRowIdx[dy][k - 1]; snesRowWt[dy][k] = 0; }
  }
}

// RGB565 -> three spread fields (B at bit 0, R at bit 11, G at bit 21) so several pixels can be added and weighted at once.
// With total weight 14: B,R <= 434 (9 bits), G <= 882 (10 bits); the fields never overflow into each other.
static inline uint32_t snesSpread(uint16_t v) { uint32_t x = v; return (x | (x << 16)) & 0x07E0F81Fu; }

__attribute__((optimize("O3"))) static void snesPresent(const uint16_t *scr) {
  for (int dy = 0; dy < SCR_H; dy++) {
    const uint16_t *s0 = scr + snesRowIdx[dy][0] * CP_SCREEN_W;
    const uint16_t *s1 = scr + snesRowIdx[dy][1] * CP_SCREEN_W;
    const uint16_t *s2 = scr + snesRowIdx[dy][2] * CP_SCREEN_W;
    const uint32_t w0 = snesRowWt[dy][0], w1 = snesRowWt[dy][1], w2 = snesRowWt[dy][2];
    uint16_t *row = g_fb + dy * SCR_W;
    for (int dx = 0; dx < SCR_W; dx++) {
      const int sx = dx * 2;
      const uint32_t p0 = *(const uint32_t *)(s0 + sx), p1 = *(const uint32_t *)(s1 + sx), p2 = *(const uint32_t *)(s2 + sx);   // 2 pixels per read (the PSRAM is slow)
      uint32_t acc = (snesSpread((uint16_t)p0) + snesSpread((uint16_t)(p0 >> 16))) * w0
                   + (snesSpread((uint16_t)p1) + snesSpread((uint16_t)(p1 >> 16))) * w1
                   + (snesSpread((uint16_t)p2) + snesSpread((uint16_t)(p2 >> 16))) * w2;
      uint32_t b = ((acc & 0x7FF) * 4681 + 32768) >> 16;            // 4681/65536 ~= 1/14, rounded
      uint32_t r = (((acc >> 11) & 0x3FF) * 4681 + 32768) >> 16;
      uint32_t g = ((acc >> 21) * 4681 + 32768) >> 16;
#if SNES_SWAP_RB
      uint16_t v = (uint16_t)((b << 11) | (g << 5) | r);
#else
      uint16_t v = (uint16_t)((r << 11) | (g << 5) | b);
#endif
      row[dx] = (uint16_t)((v >> 8) | (v << 8));                   // byte-swapped for the LCD
    }
  }
}

// ---- audio: signed 16-bit mono -> unsigned 8-bit DAC code (128 = silence) ----
// The ESP32 DAC is only 8 bits wide. DC blocker (stops pops), then first-order noise shaping + dither so quiet parts do not crunch.
static volatile int snesVol = SNES_VOL_DEFAULT;          // 0..12; 8 = full scale
static const uint8_t snesSkipSteps[] = {0, 1, 2, 3, 4, 6, 8};   // frame skip choices: 0 = Auto, otherwise N frames not drawn between drawn ones
#define SNES_SKIP_STEPS ((int)sizeof(snesSkipSteps))
static volatile int snesSkipIdx = 0;                     // index into snesSkipSteps
static volatile bool snesShowFps = false;                // on-screen speed display
static volatile bool snesFastDraw = true;                // draw the picture in 8-line strips (much less PSRAM traffic); Off = original whole-frame order
static inline uint8_t snesDacByte(int16_t s) {
  static int dcX = 0, dcY = 0, err = 0;
  static uint32_t rng = 2463534242u;
  dcY = (int)s - dcX + dcY - (dcY >> 9);                  // DC blocker
  dcX = s;
  if (snesVol == 0) { err = 0; return 128; }               // volume 0: exactly silent (the dither would otherwise hiss)
  int v = (dcY * (snesVol * 32)) >> 8;                    // volume: level 8 = x1.0
  rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;    // dither + first-order noise shaping (same as the NES sketch)
  int t = v + err + (int)(rng & 0xFF) - 128;
  int q = (t + 128) >> 8;
  q = q < -128 ? -128 : (q > 127 ? 127 : q);
  err = (t - (q << 8)) - ((int)(rng & 0xFF) - 128);
  if (err > 256) err = 256; else if (err < -256) err = -256;
  return (uint8_t)(q + 128);
}

static bool snesAudioOk = false;
#if ESP_ARDUINO_VERSION_MAJOR >= 3
static dac_continuous_handle_t snesDac = nullptr;
#endif

static void snesAudioStop() {
  if (!snesAudioOk) return;
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  dac_continuous_disable(snesDac); dac_continuous_del_channels(snesDac); snesDac = nullptr;
#else
  i2s_driver_uninstall(I2S_NUM_0);
#endif
  snesAudioOk = false;
}

// (Re)open the DAC at the given rate. Talks to the I/O expander for the amplifier, so call it BEFORE the video task starts.
static void snesAudioStart(int rate, int dmaLen = SNES_SND_MAX) {
  snesAudioStop();
  awWrite(0x05, 0x47);                   // expanderInit left P1.3 as an input (0x4F); make it an output (0x47)
  pw(PIN_AMP_EN, HIGH);                  // amplifier on
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  dac_continuous_config_t c = {};
  c.chan_mask = DAC_CHANNEL_MASK_CH0;    // channel 0 = GPIO25 (the speaker); never enable GPIO26, that is the LCD's MISO line
  c.desc_num = 4;
  c.buf_size = dmaLen;                   // bytes per DMA buffer (4 of them): smaller = less delay between picture and sound
  c.freq_hz = rate;
  c.offset = 0;
  c.clk_src = DAC_DIGI_CLK_SRC_DEFAULT;
  c.chan_mode = DAC_CHANNEL_MODE_SIMUL;
  if (dac_continuous_new_channels(&c, &snesDac) != ESP_OK || dac_continuous_enable(snesDac) != ESP_OK) {
    Serial.println("Audio: DAC init FAILED"); return;
  }
#else
  i2s_config_t c = {};
  c.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_DAC_BUILT_IN);
  c.sample_rate = rate;
  c.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  c.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;        // stereo frames; only the right DAC (GPIO25) is enabled below
  c.communication_format = (i2s_comm_format_t)I2S_COMM_FORMAT_STAND_MSB;
  c.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  c.dma_buf_count = 4;
  c.dma_buf_len = dmaLen > 1024 ? 1024 : dmaLen;        // frames per DMA buffer
  c.use_apll = false;
  c.tx_desc_auto_clear = true;                          // underrun = silence instead of repeating the last buffer
  if (i2s_driver_install(I2S_NUM_0, &c, 0, NULL) != ESP_OK) { Serial.println("Audio: I2S install FAILED"); return; }
  i2s_set_pin(I2S_NUM_0, NULL);                         // NULL = the built-in DAC pins
  i2s_set_dac_mode(I2S_DAC_CHANNEL_RIGHT_EN);           // GPIO25 only
#endif
  snesAudioOk = true;
  Serial.printf("Audio: DAC on GPIO25 ready at %d Hz\n", rate);
}
static void snesAudioInit() { snesAudioStart(SNES_SAMPLE_RATE); }   // used by the intro (cyberpi_intro.h)

// Hand one block of DAC codes to the hardware WITHOUT waiting: a late frame must never stall the emulation.
static void snesAudioPush(const uint8_t *dac, int count) {
  size_t done = 0;
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  dac_continuous_write(snesDac, (uint8_t *)dac, count, &done, 0);
#else
  static uint16_t out[256 * 2];
  while ((int)done < count) {                                  // small chunks: keeps the static buffer tiny
    int n = count - (int)done; if (n > 256) n = 256;
    for (int i = 0; i < n; i++) { uint16_t w = (uint16_t)dac[done + i] << 8; out[2 * i] = w; out[2 * i + 1] = w; }
    size_t w = 0;
    i2s_write(I2S_NUM_0, out, n * 4, &w, 0);
    w /= 4;
    done += w;
    if ((int)w < n) break;                                     // queue full
  }
#endif
  if (done < (size_t)count) {
    static uint32_t drops = 0, lastMsg = 0;
    drops++;
    if (millis() - lastMsg > 10000) { lastMsg = millis(); Serial.printf("Audio: %u blocks dropped (queue full)\n", (unsigned)drops); }
  }
}

// ---- audio feeder (core 0) ----
// The DAC must NEVER run dry: when the hardware queue is empty it outputs 0 (full negative swing) = a loud pop or buzz, whatever the
// volume. So the emulator drops its sound into a ring buffer, and this small task keeps the DAC fed all the time: real samples when
// there are some, exact silence (128) when the emulator is late. Writing blocks, so the task runs at exactly the DAC's pace.
#define SNES_RING 4096                                  // power of two
static uint8_t snesRing[SNES_RING];
static volatile uint32_t snesRingW = 0, snesRingR = 0;
static volatile bool snesAudRun = false;
static volatile bool snesAudDead = true;

static void snesRingPut(const uint8_t *d, int n) {
  uint32_t w = snesRingW, r = snesRingR;
  uint32_t used = w - r;
  if (used > 1600 && n > 16) { d += 8; n -= 8; }         // the emulator runs a hair faster than the DAC: trim a few samples, never let delay build up
  uint32_t freeN = SNES_RING - used;
  if ((uint32_t)n > freeN) n = (int)freeN;
  for (int i = 0; i < n; i++) snesRing[(w + i) & (SNES_RING - 1)] = d[i];
  __sync_synchronize();
  snesRingW = w + n;
}

static void snesAudioWriteBlocking(const uint8_t *d, int n) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  int sent = 0;
  while (sent < n) {
    size_t done = 0;
    dac_continuous_write(snesDac, (uint8_t *)d + sent, n - sent, &done, 100);
    if (!done) break;
    sent += (int)done;
  }
#else
  static uint16_t out[128 * 2];
  for (int i = 0; i < n; i++) { uint16_t w = (uint16_t)d[i] << 8; out[2 * i] = w; out[2 * i + 1] = w; }
  size_t w = 0;
  i2s_write(I2S_NUM_0, out, n * 4, &w, portMAX_DELAY);
#endif
}

static void snesAudioFeeder(void *) {
  static uint8_t chunk[128];
  while (snesAudRun) {
    uint32_t r = snesRingR, avail = snesRingW - r;
    int n = 128;
    if (avail >= 128) { for (int i = 0; i < 128; i++) chunk[i] = snesRing[(r + i) & (SNES_RING - 1)]; r += 128; }
    else if (avail > 0) { n = (int)avail; for (int i = 0; i < n; i++) chunk[i] = snesRing[(r + i) & (SNES_RING - 1)]; r += avail; }
    else memset(chunk, 128, 128);                         // nothing yet: exact silence
    __sync_synchronize();
    snesRingR = r;
    snesAudioWriteBlocking(chunk, n);
  }
  snesAudDead = true;
  vTaskDelete(nullptr);
}

static void snesAudioFeederStart() {
  snesRingW = snesRingR = 0;
  snesAudRun = true; snesAudDead = false;
  xTaskCreatePinnedToCore(snesAudioFeeder, "snesaud", 3072, nullptr, 3, nullptr, 0);
}
static void snesAudioFeederStop() {
  snesAudRun = false;
  for (int i = 0; i < 100 && !snesAudDead; i++) delay(2);
}

// ---- video task (core 0): owns I2C + SPI while a game runs ----
static void snesVideoTask(void *) {
  uint32_t comboStart = 0;
  for (;;) {
    uint32_t n = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(6));
    uint16_t b;
    if (readButtons(b)) {
      snesBtn = b;
      if ((b & B_CENTER) && (b & B_MENU)) {
        if (!comboStart) comboStart = millis();
        else if (millis() - comboStart > 1500) snesQuit = true;          // the game loop saves, then restarts
        if (comboStart && millis() - comboStart > 5000) ESP.restart();   // the game loop is stuck: leave anyway
      } else comboStart = 0;
    }
    if (n) { lcdPush(); snesBusy = false; }
  }
}

static uint32_t snesPad(uint16_t b) {
  uint32_t m = 0;
  if (b & B_MENU) {                                   // MENU held = shift layer (UP / DOWN then change the volume instead of moving)
    if (b & B_LEFT) m |= CP_PAD_TL;
    if (b & B_RIGHT) m |= CP_PAD_TR;
    if (b & B_A) m |= CP_PAD_X;
    if (b & B_B) m |= CP_PAD_Y;
    if (b & B_CENTER) m |= CP_PAD_SELECT;
  } else {
    if (b & B_UP) m |= CP_PAD_UP;
    if (b & B_DOWN) m |= CP_PAD_DOWN;
    if (b & B_LEFT) m |= CP_PAD_LEFT;
    if (b & B_RIGHT) m |= CP_PAD_RIGHT;
    if (b & B_A) m |= CP_PAD_A;
    if (b & B_B) m |= CP_PAD_B;
    if (b & B_CENTER) m |= CP_PAD_START;
  }
  return m;
}

static void introLaunch();                                 // defined in cyberpi_intro.h (included after this file)

// ---- battery saves (/saves/<rom>.srm) ----
static String snesSavePath(const char *romName) {
  String n = romName;
  int d = n.lastIndexOf('.'); if (d > 0) n = n.substring(0, d);
  return "/saves/" + n + ".srm";
}
static void snesSramLoad(const String &path) {
  uint8_t *p = nullptr; uint32_t sz = cp_snes_sram(&p);
  if (!sz || !p) return;
  File f = LittleFS.open(path, "r");
  if (!f) return;
  size_t n = f.read(p, min((size_t)sz, (size_t)f.size()));
  f.close();
  Serial.printf("Save: loaded %u bytes from %s\n", (unsigned)n, path.c_str());
}
static void snesSramSave(const String &path) {
  uint8_t *p = nullptr; uint32_t sz = cp_snes_sram(&p);
  if (!sz || !p) return;
  File f = LittleFS.open(path, "w");
  if (!f) { Serial.println("Save: cannot write " + path); return; }
  f.write(p, sz);
  f.close();
  cp_snes_sram_clear_modified();
}

// ---- colour test screen, shown before the game starts ----
// Top half: bars drawn straight to the LCD (what the panel really shows). Bottom half: the same bars sent through the SNES
// picture path (RGB565 -> scaler -> LCD). If the two halves look the same, the emulator's colours are right.
// If red and blue are swapped in the bottom half only, set SNES_SWAP_RB to 1. If both halves look wrong, it is the screen itself.
static void snesColorTest() {
  uint16_t *src = (uint16_t *)heap_caps_malloc(CP_SCREEN_W * CP_SCREEN_H * 2, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!src) return;
  static const uint8_t bars[8][3] = {{255,0,0},{0,255,0},{0,0,255},{255,255,0},{0,255,255},{255,0,255},{255,255,255},{0,0,0}};
  for (int y = 0; y < CP_SCREEN_H; y++)
    for (int x = 0; x < CP_SCREEN_W; x++) {
      uint16_t v = 0;
      if (y >= 84 && y < 168) { const uint8_t *c = bars[x / 32]; v = (uint16_t)(((c[0] & 0xF8) << 8) | ((c[1] & 0xFC) << 3) | (c[2] >> 3)); }   // native RGB565, like the core
      else if (y >= 168) { int g = x; v = (uint16_t)(((g & 0xF8) << 8) | ((g & 0xFC) << 3) | (g >> 3)); }                                          // grey ramp
      src[y * CP_SCREEN_W + x] = v;
    }
  snesPresent(src);                                  // whole screen through the real SNES path: bars at y 48-95, grey ramp below
  heap_caps_free(src);
  gFill(0, 0, SCR_W, 48, C565(0, 0, 0));
  gText(2, 1, "COLOUR TEST", C565(255, 255, 255));
  for (int i = 0; i < 8; i++) gFill(i * 16, 10, 16, 28, C565(bars[i][0], bars[i][1], bars[i][2]));   // straight to the panel
  gText(2, 39, "panel  ^   v SNES", C565(200, 200, 200));
  lcdPush();
  uint16_t b = 0;
  uint32_t t0 = millis();
  while (readButtons(b) && b) { if (millis() - t0 > 1500) break; delay(10); }   // wait until the launch press is released
  t0 = millis();
  while (millis() - t0 < 4000) { if (readButtons(b) && b) break; delay(20); }
}

// ---- settings menu (hold MENU alone for 1 s while playing) ----
// The emulation is paused while it is open. Up/Down = move, Left/Right = change, A or joystick press = choose, B or MENU = close.
#define SNES_MENU_ITEMS 6
static void snesMenuDraw(int sel) {
  const uint16_t cPanel = C565(20, 24, 56), cSel = C565(60, 80, 170), cTxt = C565(235, 235, 235), cDim = C565(150, 160, 190), cTitle = C565(255, 210, 90);
  gFill(4, 6, SCR_W - 8, 116, cPanel);
  gFill(4, 6, SCR_W - 8, 1, cDim); gFill(4, 121, SCR_W - 8, 1, cDim);
  gText(10, 10, "SETTINGS", cTitle);
  static const char *names[SNES_MENU_ITEMS] = {"Resume", "Volume", "Frame skip", "Fast draw", "Show FPS", "Exit to files"};
  char val[SNES_MENU_ITEMS][14] = {"", "", "", "", "", ""};
  snprintf(val[1], sizeof val[1], "%d / 12", (int)snesVol);
  if (snesSkipSteps[snesSkipIdx] == 0) snprintf(val[2], sizeof val[2], "Auto");
  else snprintf(val[2], sizeof val[2], "Skip %d", (int)snesSkipSteps[snesSkipIdx]);
  snprintf(val[3], sizeof val[3], "%s", snesFastDraw ? "On" : "Off");
  snprintf(val[4], sizeof val[4], "%s", snesShowFps ? "On" : "Off");
  for (int i = 0; i < SNES_MENU_ITEMS; i++) {
    int y = 22 + i * 14;
    if (i == sel) gFill(7, y - 3, SCR_W - 14, 13, cSel);
    gText(11, y, names[i], cTxt);
    if (val[i][0]) {
      int w = (int)strlen(val[i]) * 6;
      gText(SCR_W - 11 - w, y, val[i], i == sel ? cTxt : cDim);
    }
  }
  gText(10, 108, "A=pick  B=back", cDim);
}

// Returns true when the player chose "Exit to files".
static bool snesMenuRun() {
  uint32_t t0 = millis();
  while (snesBtn && millis() - t0 < 3000) delay(10);              // wait for the MENU press to be released
  uint16_t pb = 0;
  int sel = 0;
  bool exitGame = false, done = false;
  while (!done && !snesQuit) {
    while (snesBusy) delay(1);                                    // the video task is still sending the last picture
    snesMenuDraw(sel);
    snesBusy = true;
    xTaskNotifyGive(snesVidTask);
    uint16_t pr = 0;
    while (!pr && !snesQuit) { delay(15); uint16_t b = snesBtn; pr = b & ~pb; pb = b; }
    if (pr & B_UP) sel = (sel + SNES_MENU_ITEMS - 1) % SNES_MENU_ITEMS;
    if (pr & B_DOWN) sel = (sel + 1) % SNES_MENU_ITEMS;
    int dir = (pr & B_RIGHT) ? 1 : ((pr & B_LEFT) ? -1 : 0);
    bool pick = pr & (B_A | B_CENTER);
    if (sel == 1 && dir) { int v = snesVol + dir; snesVol = v < 0 ? 0 : (v > 12 ? 12 : v); }
    if (sel == 2 && dir) { int i = snesSkipIdx + dir; snesSkipIdx = i < 0 ? 0 : (i >= SNES_SKIP_STEPS ? SNES_SKIP_STEPS - 1 : i); }
    if (sel == 3 && (dir || pick)) { snesFastDraw = !snesFastDraw; cp_snes_set_strip(snesFastDraw ? 8 : 0); }
    if (sel == 4 && (dir || pick)) snesShowFps = !snesShowFps;
    if (sel == 0 && pick) done = true;
    if (sel == 5 && pick) { exitGame = true; done = true; }
    if (pr & (B_B | B_MENU)) done = true;
  }
  prefs.putUChar("snesvol", (uint8_t)snesVol);
  prefs.putUChar("snesskip", (uint8_t)snesSkipIdx);
  prefs.putUChar("snesfps", snesShowFps ? 1 : 0);
  prefs.putUChar("snesfast", snesFastDraw ? 1 : 0);
  while (snesBusy) delay(1);
  uint32_t t1 = millis();
  while (snesBtn && millis() - t1 < 3000) delay(10);              // let go of the buttons before the game gets them back
  return exitGame;
}

// Returns only on a load error. On success it runs until the user exits (then the board restarts).
static int snesRun(const char *romName) {
  splash("Loading ROM...", romName);
  if (!psramFound()) { splash("PSRAM not found", "Tools > PSRAM: Enabled"); delay(3500); return -1; }
  File f = LittleFS.open(String("/roms/") + romName, "r");
  if (!f) { splash("Cannot open ROM", romName); delay(2500); return -1; }
  uint32_t sz = f.size();
  if (sz < 32 * 1024) { splash("File too small", romName); delay(2500); return -1; }

  // Everything the radio held is released first: the emulator wants as much internal RAM as it can get.
  setCpuFrequencyMhz(240);
  WiFi.disconnect(true); WiFi.softAPdisconnect(true); WiFi.mode(WIFI_OFF);   // exiting the game restarts the board, which brings WiFi back
  Serial.printf("SNES: chip rev %d, %u MHz, PSRAM %u KB\n", (int)ESP.getChipRevision(), (unsigned)getCpuFrequencyMhz(), (unsigned)(ESP.getPsramSize() / 1024));
  Serial.printf("SNES: internal heap free %u, largest block %u, PSRAM free %u\n", (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL), (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));

  int r = cp_snes_init(SNES_GAME_RATE);
  if (r) {
    Serial.printf("SNES: init failed (%d)\n", r);
    splash("Out of memory", "emulator init");
    delay(3000); return -1;
  }
  uint32_t cap = 0;
  uint8_t *rom = cp_snes_rom_buffer(&cap);
  if (sz > cap) {
    char m[32]; snprintf(m, sizeof(m), "max %u KB", (unsigned)(cap / 1024));
    splash("ROM too big", m); delay(3000); return -1;
  }
  uint32_t got = 0;
  while (got < sz) {
    int n = f.read(rom + got, min((uint32_t)4096, sz - got));
    if (n <= 0) break;
    got += n;
  }
  f.close();
  if (got != sz) { splash("Read error", romName); delay(2500); return -1; }
  if (cp_snes_load(sz)) { splash("Not a SNES ROM", romName); delay(2500); return -1; }
  Serial.printf("SNES: %s '%s', %u KB, %d fps, internal heap free now %u\n", romName, cp_snes_title(), (unsigned)(sz / 1024),
                cp_snes_fps(), (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL));

  snesVol = prefs.getUChar("snesvol", SNES_VOL_DEFAULT); if (snesVol > 12) snesVol = SNES_VOL_DEFAULT;
  snesSkipIdx = prefs.getUChar("snesskip", 0); if (snesSkipIdx >= SNES_SKIP_STEPS) snesSkipIdx = 0;
  snesShowFps = prefs.getUChar("snesfps", 0) != 0;
  snesFastDraw = prefs.getUChar("snesfast", 1) != 0;
  cp_snes_set_strip(snesFastDraw ? 8 : 0);
  LittleFS.mkdir("/saves");
  String savePath = snesSavePath(romName);
  snesSramLoad(savePath);

  snesBuildScale();
  gFill(0, 0, SCR_W, SCR_H, C565(0, 0, 0));
  lcdPush();

  snesColorTest();                               // 4 s colour check screen (any button skips)

  snesAudioInit();                               // uses I2C (amp enable), so it must run before the video task exists
  introLaunch();                                 // 2 s: the chime strike + "CyberPi ENTERTAINMENT" logo, then the game starts
  snesAudioStart(SNES_GAME_RATE, 384);           // intro runs at 44160 Hz; the game's mixer and DAC run at SNES_GAME_RATE
  snesAudioFeederStart();                        // keeps the DAC fed (silence when the emulator is late)

  // From here on only the video task touches I2C/SPI.
  xTaskCreatePinnedToCore(snesVideoTask, "snesvid", 4096, nullptr, 2, &snesVidTask, 0);
  delay(20);

  const int fps = cp_snes_fps();
  const int64_t period = fps == 50 ? 20000 : 16639;            // microseconds per emulated frame
  int64_t next = esp_timer_get_time();
  int skipRun = 0;
  uint32_t statAt = millis(), statEmu = 0, statDrawn = 0, saveAt = 0, frameNo = 0, statWin = 0, menuHold = 0;
  uint64_t usDrawnFrame = 0, usSkipFrame = 0, usMix = 0, usScale = 0, nSkip = 0;   // where the time goes (1 s windows)
  char fpsL1[16] = "", fpsL2[16] = "", fpsL3[16] = "", memStr[16] = "", ramStr[16] = "";
  cp_snes_mem_report(memStr, sizeof memStr);
  snprintf(ramStr, sizeof ramStr, "free %uK max %uK", (unsigned)(heap_caps_get_free_size(MALLOC_CAP_INTERNAL) / 1024), (unsigned)(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL) / 1024));   // internal RAM left after loading
  Serial.printf("SNES: memory placement %s  (I = fast internal RAM, P = slow PSRAM; W=work RAM V=video RAM S=sound RAM R=ROM)\n", memStr);
  static int16_t pcm[512];
  static uint8_t dac[SNES_SND_MAX];
  uint16_t prevBtn = 0;
  uint32_t volShowUntil = 0, volSaveAt = 0;
  bool volDirty = false;

  while (!snesQuit) {
    uint16_t bt = snesBtn;
    cp_snes_set_pad(snesPad(bt));
    if (bt & B_MENU) {                                         // MENU + UP / DOWN: volume
      uint16_t pr = bt & ~prevBtn;
      int nv = snesVol;
      if (pr & B_UP) nv++;
      if (pr & B_DOWN) nv--;
      if (nv < 0) nv = 0; else if (nv > 12) nv = 12;
      if (pr & (B_UP | B_DOWN)) { snesVol = nv; volShowUntil = millis() + 1500; volDirty = true; volSaveAt = millis() + 2000; }
    }
    if (bt == B_MENU) {                                        // MENU held alone for 1 s: settings menu
      if (!menuHold) menuHold = millis() | 1;
      else if (millis() - menuHold > 1000) {
        menuHold = 0;
        if (snesMenuRun()) snesQuit = true;
        next = esp_timer_get_time(); skipRun = 0; prevBtn = snesBtn;
        continue;
      }
    } else menuHold = 0;
    prevBtn = bt;
    if (volDirty && millis() > volSaveAt) { volDirty = false; prefs.putUChar("snesvol", (uint8_t)snesVol); }

    int64_t now = esp_timer_get_time();
    bool behind = now > next;
    const int skipN = snesSkipSteps[snesSkipIdx];
    bool render;
    if (skipN == 0) render = !(behind && skipRun < SNES_MAX_SKIP);   // Auto: behind schedule = skip drawing this frame (up to SNES_MAX_SKIP in a row)
    else render = (frameNo % (skipN + 1)) == 0;                      // fixed: draw 1 frame in (N + 1)
    frameNo++;
    if (render && snesBusy) render = false;                    // the LCD is still taking the last picture
    skipRun = render ? 0 : skipRun + 1;

    int64_t tF0 = esp_timer_get_time();
    cp_snes_frame(render ? 1 : 0);
    if (render) usDrawnFrame += esp_timer_get_time() - tF0; else { usSkipFrame += esp_timer_get_time() - tF0; nSkip++; }
    statEmu++;

#if SNES_AUDIO_ON
    if (snesAudioOk) {
      int64_t tM = esp_timer_get_time();
      int n = cp_snes_mix_mono(pcm, 512);                      // one frame of mixer output (the core needs this call every frame)
      usMix += esp_timer_get_time() - tM;
      if (n > SNES_SND_MAX) n = SNES_SND_MAX;
      for (int i = 0; i < n; i++) dac[i] = snesDacByte(pcm[i]);
      snesRingPut(dac, n);
    }
#else
    (void)pcm; (void)dac;
#endif

    if (render) {
      int64_t tS = esp_timer_get_time();
      snesPresent(cp_snes_screen());
      usScale += esp_timer_get_time() - tS;
      if (millis() < volShowUntil) {                           // volume bar for 1.5 s after a change
        char vt[16]; snprintf(vt, sizeof vt, "VOL %d", (int)snesVol);
        gFill(0, SCR_H - 11, SCR_W, 11, C565(0, 0, 0));
        gText(2, SCR_H - 9, vt, C565(255, 255, 255));
        gFill(40, SCR_H - 8, 6 * (int)snesVol, 5, snesVol > 8 ? C565(255, 160, 0) : C565(120, 255, 120));
      }
      if (snesShowFps) {                                       // speed display: E = emulated frames/s (60 = full speed), D = drawn frames/s
        gFill(0, 0, 96, 45, C565(0, 0, 0));
        gText(1, 1, fpsL1, C565(255, 255, 0));
        gText(1, 10, fpsL2, C565(255, 255, 255));
        gText(1, 19, fpsL3, C565(255, 255, 255));
        gText(1, 28, memStr, C565(140, 200, 255));
        gText(1, 37, ramStr, C565(140, 200, 255));
      }
      snesBusy = true;
      xTaskNotifyGive(snesVidTask);
      statDrawn++;
    }

    // Battery save: write at most every 3 s while the game keeps changing it.
    if (cp_snes_sram_modified() && millis() - saveAt > 3000) { snesSramSave(savePath); saveAt = millis(); }

    // Pacing: one emulated frame per `period`. If we are far behind, give up catching up instead of racing forever.
    next += period;
    now = esp_timer_get_time();
    if (now - next > 6 * period) next = now;
    else if (next > now) {
      int64_t wait = next - now;
      if (wait > 2000) vTaskDelay(pdMS_TO_TICKS((wait - 1000) / 1000));
      while (esp_timer_get_time() < next) { }
    }

    if (millis() - statAt >= 1000) {
      const double dr = statDrawn ? usDrawnFrame / 1000.0 / statDrawn : 0.0, sk = nSkip ? usSkipFrame / 1000.0 / nSkip : 0.0;
      const double mx = statEmu ? usMix / 1000.0 / statEmu : 0.0, sc = statDrawn ? usScale / 1000.0 / statDrawn : 0.0;
      snprintf(fpsL1, sizeof fpsL1, "E%u D%u", (unsigned)statEmu, (unsigned)statDrawn);
      snprintf(fpsL2, sizeof fpsL2, "dr%.0f sk%.0f ms", dr, sk);
      snprintf(fpsL3, sizeof fpsL3, "mx%.0f sc%.0f ms", mx, sc);
      if (++statWin >= 5) {
        statWin = 0;
        Serial.printf("SNES: %u emulated / %u drawn frames per second, volume %d\n", (unsigned)statEmu, (unsigned)statDrawn, (int)snesVol);
        Serial.printf("SNES: avg ms per frame: drawn %.1f, skipped %.1f, sound mix %.1f, scale %.1f\n", dr, sk, mx, sc);
      }
      usDrawnFrame = usSkipFrame = usMix = usScale = nSkip = 0;
      statAt = millis(); statEmu = statDrawn = 0;
    }
  }

  if (cp_snes_sram_modified()) snesSramSave(savePath);
  snesAudioFeederStop();
  snesAudioStop();
  delay(50);
  ESP.restart();
  return 0;
}
