# Doom on the CyberPi (one sketch: game + WAD uploader)

Open the folder **CyberPiDoom** (extract the zip first, do not open from inside it) in the Arduino IDE.

## Arduino IDE settings
- Board: **ESP32 Dev Module**
- Board package: **esp32 by Espressif, version 2.0.17** (Tools > Board > Boards Manager). Versions 3.x do NOT work.
- **PSRAM: Enabled**
- **Flash Size: 8MB** (16MB only if your CyberPi really has 16 MB: rename `partitions_16MB_optional.csv` to `partitions.csv`)
- Upload Speed: 115200 if you get "Unable to verify flash chip connection"
- Leave the partition scheme alone: `partitions.csv` in this folder is used automatically.
- Do NOT turn on "Erase All Flash Before Sketch Upload" (it would erase your WAD).

## Steps
1. Flash the sketch.
2. With no WAD stored, the CyberPi shows the uploader screen. (To open it again later: hold **A** while powering on,
   or pick **WAD + WiFi setup** in the start-up menu.)
3. Join WiFi **CyberPi-WAD** (password **doomdoom1**), open **http://192.168.4.1**, choose your WAD
   (doom1.wad, doom.wad, doom2.wad, freedoom1.wad or freedoom2.wad), press Upload.
4. On the same page type your **home WiFi name and password** and press **Save WiFi** (only needed for online play).
5. When the screen says SAVED, restart the CyberPi.

## Start-up menu
Every power-on shows a menu. Do nothing and it starts your last choice after 3 seconds.
Joystick up/down = choose, **A** = go.
- **Play on CyberPi** - Doom on the CyberPi screen and buttons (as before).
- **Play online (PC/PS)** - same, plus the CyberPi joins your WiFi and shows an IP address on its screen.
  Type that IP into a browser on your PC (Chrome or Edge), press **A** on the CyberPi, and you see the game on the PC
  and can play with keyboard + mouse or a PlayStation/Xbox controller. The CyberPi's own screen and buttons keep working too.
  If it cannot join your WiFi it makes its own hotspot **CyberPi-Doom** (password **doomdoom1**): join that from the PC
  and open the IP shown on the screen (usually http://192.168.4.1).
- **WAD + WiFi setup** - the uploader page.

## Online play: default controls (all remappable)
Click the game once to capture the mouse (Esc lets go). Click **Controls & settings** (top bar) for sliders and the mapping list.

| Action | Keyboard / mouse | PlayStation controller |
|---|---|---|
| Look left/right | move the mouse | right stick |
| Walk / strafe | W A S D (or arrows) | left stick (D-pad also walks/turns) |
| Fire | left click (or Ctrl) | R2 or Square |
| Use / open door | right click, E, Space; or **hold left click** for 0.4 s | Cross |
| Run | Shift | L2 |
| Next / previous weapon | mouse wheel, X / Z | R1 / L1 |
| Pick weapon | 1 - 7 | - |
| Doom menu | ` (backtick) or the **Doom menu** button | Options |
| Menu select | Enter | Triangle or Cross |
| Map | Tab | Share |

Settings are saved in the browser. The "hold fire = open doors" option and its delay are in the settings panel.
In the mapping list: **+ Add** then press the key / click / scroll / press the controller button you want;
click a blue chip to remove it.

If the CyberPi runs low on RAM the video pauses by itself (the game keeps running). The Serial Monitor (115200)
prints a "Mem:" line every 3 s in online mode.

Online play starts with the CyberPi **silent** and its **screen idle** (it says "Playing on the PC"). Both can be
turned on in the page settings (Sound and CyberPi screen). Sound on the PC itself is not available.
Video quality: Full, Lite, or **Ultra low** (80x50, the default now - the lightest on WiFi).

Tips: if the picture stutters, choose **Lite** or **Ultra low** quality in the settings. A PC on wired network + a good WiFi signal
at the CyberPi helps the most. Only one browser can watch at a time.

If the PC does not show the controller, press any button on it while the page is open.

## Controls
| Input | Action |
|---|---|
| Joystick up/down | walk |
| Joystick left/right | turn |
| Joystick press + left/right | strafe (press alone = Enter in menus) |
| A | fire |
| B | use / open doors |
| B held + joystick left/right | change weapon |
| Menu | Esc (Doom menu) |

## Colours
First boot shows red/green/blue bars. Press joystick left/right until they match the labels, then A.
Hold **B** at power-on to redo it. (Mode 4/4 is the default and should be right.)

## Sound
Sound effects play on the built-in speaker (no music). Code: `src/doom/i_cpsound.c`.
Set `CP_SOUND_ENABLED` to 0 at the top of that file to turn it off. Serial Monitor (115200) shows
`Sound: on ...` at start-up and you hear a short beep.

## Saving
Menu > Save Game > pick a slot > type a name with B + joystick left/right (digits) > joystick press.
Saves go to /savegame on the CyberPi's flash.
