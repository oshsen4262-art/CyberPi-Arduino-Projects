/*
 * CyberPi Doom
 * ------------
 * Runs the real Doom engine (doomgeneric) on the CyberPi's ESP32.
 *
 *  Board settings (Arduino IDE, Tools menu):
 *    Board: ESP32 Dev Module     Arduino-ESP32 core: 2.0.x (2.0.17 recommended; 3.x will not work)
 *    PSRAM: Enabled              Flash Size: 8MB (or 16MB if your CyberPi has it)
 *    The partitions.csv next to this file is used automatically (it gives the WAD its own big storage area).
 *
 *  First time: flash this sketch. With no WAD stored it opens the WiFi uploader automatically;
 *  send your WAD, then restart. The WAD stays in the CyberPi's flash.
 *
 *  Start-up menu: every time you power on you get a short menu (it starts your last choice after 3 s):
 *    Play on CyberPi ........ Doom on the CyberPi's own screen and buttons, like before
 *    Play online (PC/PS) .... same, but the CyberPi also joins your WiFi (or makes its own hotspot) and
 *                             you open its IP address in a PC browser to see the game and play it with
 *                             keyboard + mouse or a PlayStation / Xbox controller (every control can be remapped)
 *    WAD + WiFi setup ....... the WAD uploader below, which now also stores your home WiFi name + password
 *
 *  WAD upload mode (built in): the sketch opens a WiFi uploader instead of Doom when
 *    - no WAD file is stored yet, or
 *    - you pick "WAD + WiFi setup" in the start-up menu, or
 *    - you hold A while powering on.
 *  Join WiFi "CyberPi-WAD" (password doomdoom1), open http://192.168.4.1 in a browser, pick your
 *  WAD (doom1.wad, doom.wad, doom2.wad, freedoom1.wad or freedoom2.wad) and press Upload.
 *  On the same page, type your home WiFi name + password and press Save WiFi (needed for "Play online").
 *  When the screen says SAVED, restart the CyberPi (it will start Doom).
 *
 *  Colour calibration: on first boot a screen with red/green/blue bars appears.
 *  Press joystick left/right until the bars match their labels, then press A.
 *  The choice is saved. Hold B while powering on to calibrate again.
 *  (The correct mode for the CyberPi panel is normally 4/4, which is the default.)
 *
 *  Controls
 *    Joystick up/down ........ walk forward / back
 *    Joystick left/right ..... turn
 *    Joystick press + left/right ... strafe (also: Enter in menus)
 *    A ....................... fire
 *    B ....................... use / open doors / (menus: back)
 *    B held + joystick left/right ... change weapon
 *    Menu .................... Esc (Doom menu)
 *
 *  Sound: sound effects play through the built-in speaker (src/doom/i_cpsound.c). No music.
 *  To turn sound off, set CP_SOUND_ENABLED to 0 at the top of i_cpsound.c.
 */

#include <Arduino.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <WiFi.h>
#include <WebServer.h>
#include <esp_heap_caps.h>
extern "C" {
#include "src/cyberpi/i2c/i2c.h"
#include "src/cyberpi/io/aw9523b.h"
#include "src/cyberpi/lcd/lcd.h"
}
#include "src/doom/doomgeneric.h"
#include "src/doom/doomkeys.h"
#include "src/font5x7.h"
#include "src/webplay/webplay.h"

// ---------------- settings ----------------
#define VIEW_W        128
#define VIEW_H        128     // Fills the whole 128x128 screen (stretched). Set to 96 for the original 4:3 picture with bars.
#define MAX_WAD_FILES 5
#define AP_SSID       "CyberPi-WAD"     // hotspot used by the WAD uploader
#define AP_PASS       "doomdoom1"       // at least 8 characters (also used for the online-play hotspot)
#define PLAY_AP_SSID  "CyberPi-Doom"    // hotspot used by online play when your home WiFi is not available
#define DEFAULT_COLOR_MODE 3  // bit0 = swap red/blue, bit1 = swap bytes. 3 = both (what lcd.c needs)

// Colour order flags: set by the calibration screen and saved in flash.
static bool swapRB    = true;   // swap red/blue
static bool swapBytes = true;   // swap the two bytes of each RGB565 pixel (lcd_draw sends raw little-endian memory)

// CyberPi buttons (AW9523B expander pins)
#define JOY_UP     AW_P0_1
#define JOY_DOWN   AW_P0_4
#define JOY_RIGHT  AW_P0_2
#define JOY_LEFT   AW_P0_0
#define JOY_CENTER AW_P0_3
#define BTN_A      AW_P0_6
#define BTN_B      AW_P0_5
#define BTN_MENU   AW_P1_0

// Declared by hand to avoid pulling Doom's C headers into C++ (layout matches i_video.h).
struct DoomColor { uint32_t b : 8; uint32_t g : 8; uint32_t r : 8; uint32_t a : 8; };
extern "C" { extern DoomColor colors[256]; extern unsigned int palette_changed; }

static uint16_t *fb = nullptr;                 // 128x128 RGB565 frame sent to the display (internal RAM, allocated in setup)
static uint16_t  pal565[256];
static uint8_t   palRGB[768];                   // true RGB palette, sent to the browser in online play
static uint16_t  colOfs[VIEW_W];               // source column for each screen column
static uint16_t  rowOfs[VIEW_H];               // source row for each screen row
static char      wadPath[64];

// ---------------- colour conversion ----------------
static inline uint16_t toRgb565(uint8_t r, uint8_t g, uint8_t b) {
  if (swapRB) { uint8_t t = r; r = b; b = t; }
  uint16_t v = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
  if (swapBytes) v = (v >> 8) | (v << 8);
  return v;
}

// ---------------- tiny text helpers (for error / status screens) ----------------
static void putPx(int x, int y, uint16_t c) { if (x >= 0 && x < 128 && y >= 0 && y < 128) fb[y * 128 + x] = c; }
static void drawText(int x, int y, const char *s, uint16_t color) {
  for (; *s; s++, x += 6) {
    int ch = (unsigned char)*s; if (ch < 32 || ch > 126) ch = '?';
    const uint8_t *g = FONT5X7[ch - 32];
    for (int c = 0; c < 5; c++) for (int r = 0; r < 7; r++) if ((g[c] >> r) & 1) putPx(x + c, y + r, color);
  }
}
// Word-wrapped message, 21 characters per line.
static void showMessage(const char *title, const char *msg, uint16_t color) {
  if (!fb) return;
  memset(fb, 0, 128 * 128 * 2);
  drawText(2, 2, title, 0xFFFF);
  int y = 16, col = 0; char line[24];
  const char *p = msg;
  while (*p && y < 120) {
    int n = 0; while (p[n] && p[n] != ' ' && p[n] != '\n') n++;
    if (col && col + 1 + n > 21) { line[col] = 0; drawText(2, y, line, color); y += 9; col = 0; }
    while (n > 21) { memcpy(line, p, 21); line[21] = 0; drawText(2, y, line, color); y += 9; p += 21; n -= 21; }
    if (col) line[col++] = ' ';
    memcpy(line + col, p, n); col += n; p += n;
    if (*p == '\n') { line[col] = 0; drawText(2, y, line, color); y += 9; col = 0; }
    if (*p) p++;
  }
  if (col) { line[col] = 0; drawText(2, y, line, color); }
  lcd_draw(fb, 128, 128);
}

// Called by the engine on any fatal error (and by our own allocator). Never returns.
extern "C" void CP_Fatal(const char *msg) {
  Serial.printf("\nFATAL: %s\n", msg);
  showMessage("Doom stopped:", msg, 0xF800 /* red-ish */);
  for (;;) delay(1000);
}

// ---------------- colour calibration ----------------
static void applyColorMode(uint8_t m) { swapRB = (m & 1) != 0; swapBytes = (m & 2) != 0; }

static void drawCalibration(uint8_t m) {
  applyColorMode(m);
  memset(fb, 0, 128 * 128 * 2);
  const uint16_t white = toRgb565(255, 255, 255);   // white is identical in every mode
  struct Bar { int y; uint8_t r, g, b; const char *label; };
  const Bar bars[3] = { { 6, 255, 0, 0, "RED" }, { 40, 0, 255, 0, "GREEN" }, { 74, 0, 0, 255, "BLUE" } };
  for (int i = 0; i < 3; i++) {
    uint16_t c = toRgb565(bars[i].r, bars[i].g, bars[i].b);
    for (int y = bars[i].y; y < bars[i].y + 28; y++) for (int x = 0; x < 128; x++) fb[y * 128 + x] = c;
    drawText(4, bars[i].y + 10, bars[i].label, white);
  }
  char buf[24]; snprintf(buf, sizeof(buf), "Mode %d/4", m + 1);
  drawText(2, 106, "L/R change   A = OK", white);
  drawText(2, 117, buf, white);
  lcd_draw(fb, 128, 128);
}

static void colorSetup(bool force) {
  Preferences pr;
  pr.begin("cpdoom", false);
  if (!force && pr.isKey("cm2")) { applyColorMode(pr.getUChar("cm2", DEFAULT_COLOR_MODE)); pr.end(); return; }

  uint8_t m = pr.getUChar("cm2", DEFAULT_COLOR_MODE);   // start from the last/default mode
  drawCalibration(m);
  bool pL = true, pR = true, pA = true;          // start "held" so a leftover press doesn't skip the screen
  for (;;) {
    uint16_t g = aw_get_gpio();
    if ((g & 0x007F) != 0) {                     // ignore failed I2C reads
      bool L = ((g >> JOY_LEFT) & 1) == 0, R = ((g >> JOY_RIGHT) & 1) == 0, A = ((g >> BTN_A) & 1) == 0;
      if (L && !pL) { m = (m + 3) % 4; drawCalibration(m); }
      if (R && !pR) { m = (m + 1) % 4; drawCalibration(m); }
      if (A && !pA) break;
      pL = L; pR = R; pA = A;
    }
    delay(30);
  }
  applyColorMode(m);
  pr.putUChar("cm2", m);
  pr.end();
}

// ---------------- buttons -> Doom keys ----------------
struct KeyEv { uint8_t pressed; uint8_t key; };
static KeyEv q[48]; static int qh = 0, qt = 0;
static void qpush(int pressed, uint8_t key) { int n = (qt + 1) % 48; if (n == qh) return; q[qt] = { (uint8_t)pressed, key }; qt = n; }

// The ORDER of this list is also the bit order of the key mask sent by the browser page (src/webplay/page.h). Do not reorder.
enum { K_UP, K_DOWN, K_TL, K_TR, K_SL, K_SR, K_FIRE, K_USE, K_ENTER, K_ESC,
       K_RUN, K_MAP, K_YES, K_NO, K_W1, K_W2, K_W3, K_W4, K_W5, K_W6, K_W7, K_COUNT };
static const uint8_t keyCode[K_COUNT] = { KEY_UPARROW, KEY_DOWNARROW, KEY_LEFTARROW, KEY_RIGHTARROW,
                                          KEY_STRAFE_L, KEY_STRAFE_R, KEY_FIRE, KEY_USE, KEY_ENTER, KEY_ESCAPE,
                                          KEY_RSHIFT, KEY_TAB, 'y', 'n', '1', '2', '3', '4', '5', '6', '7' };
static bool held[K_COUNT];
static bool padWant[K_COUNT];                   // last good reading of the CyberPi's own buttons
static bool prevL = false, prevR = false;
static int  weapon = 2;                         // last weapon key sent ('1'..'7')
static bool webOn = false;                      // true in online-play mode

static void stepWeapon(int dir) {               // dir < 0 = previous weapon, > 0 = next weapon
  weapon = dir < 0 ? (weapon <= 1 ? 7 : weapon - 1) : (weapon >= 7 ? 1 : weapon + 1);
  qpush(1, '0' + weapon); qpush(0, '0' + weapon);
}

static void readPad() {
  uint16_t g = aw_get_gpio();
  if ((g & 0x007F) == 0) return;                // every control "pressed" at once = failed I2C read, keep the last reading
  auto down = [&](int pin) { return ((g >> pin) & 1) == 0; };
  bool L = down(JOY_LEFT), R = down(JOY_RIGHT), C = down(JOY_CENTER), B = down(BTN_B);

  memset(padWant, 0, sizeof(padWant));
  padWant[K_UP] = down(JOY_UP); padWant[K_DOWN] = down(JOY_DOWN);
  padWant[K_FIRE] = down(BTN_A); padWant[K_USE] = B; padWant[K_ENTER] = C; padWant[K_ESC] = down(BTN_MENU);
  if (B) {                                      // weapon select: B + left/right (one step per press)
    if (L && !prevL) stepWeapon(-1);
    if (R && !prevR) stepWeapon(+1);
  } else if (C) { padWant[K_SL] = L; padWant[K_SR] = R; }
  else          { padWant[K_TL] = L; padWant[K_TR] = R; }
  prevL = L; prevR = R;
}

// Combines the CyberPi's buttons with the browser's controls (online play) and turns changes into Doom key events.
static void pollInput() {
  readPad();
  uint32_t web = 0;
  if (webOn) {
    web = webplay_keys();
    int nx = 0, pv = 0;
    webplay_take_weapon_steps(&nx, &pv);
    for (int i = 0; i < nx && i < 7; i++) stepWeapon(+1);
    for (int i = 0; i < pv && i < 7; i++) stepWeapon(-1);
  }
  for (int i = 0; i < K_COUNT; i++) {
    bool want = padWant[i] || ((web >> i) & 1);
    if (want != held[i]) {
      held[i] = want;
      qpush(want, keyCode[i]);
      if (want && i >= K_W1) weapon = i - K_W1 + 1;   // keep "next/previous weapon" in step with number keys
    }
  }
}

extern "C" int DG_GetKey(int *pressed, unsigned char *key) {
  static bool polled = false;
  if (qh == qt && !polled) { pollInput(); polled = true; }
  if (qh == qt) { polled = false; return 0; }
  *pressed = q[qh].pressed; *key = q[qh].key; qh = (qh + 1) % 48;
  return 1;
}

// ---------------- display ----------------
extern "C" void DG_Init() {
  for (int x = 0; x < VIEW_W; x++) colOfs[x] = (x * 5 + 2) / 2;                    // 320 -> 128 (x2.5)
  for (int y = 0; y < VIEW_H; y++) { int s = (y * 200 + 100) / VIEW_H; rowOfs[y] = s > 199 ? 199 : s; }   // 200 -> VIEW_H
  palette_changed = 1;
}

extern "C" void DG_DrawFrame() {
  if (palette_changed) {
    for (int i = 0; i < 256; i++) {
      pal565[i] = toRgb565(colors[i].r, colors[i].g, colors[i].b);
      palRGB[i * 3] = colors[i].r; palRGB[i * 3 + 1] = colors[i].g; palRGB[i * 3 + 2] = colors[i].b;
    }
    palette_changed = 0;
  }
  const uint8_t *src = (const uint8_t *)DG_ScreenBuffer;
  if (webplay_streaming()) webplay_offer_frame(src, palRGB);   // online play: hand the frame to the browser
  static bool lcdParked = false;
  if (webplay_skip_lcd()) {                       // playing on the PC: leave the CyberPi screen alone (saves work too)
    if (!lcdParked) {
      lcdParked = true;
      showMessage("Playing on the PC", "The game is on the PC browser. The CyberPi screen can be turned on in the page settings.", toRgb565(0, 220, 255));
    }
    vTaskDelay(1);
    return;
  }
  if (lcdParked) { lcdParked = false; memset(fb, 0, 128 * 128 * 2); }
  const int yTop = (128 - VIEW_H) / 2;
  for (int y = 0; y < VIEW_H; y++) {
    const uint8_t *row = src + rowOfs[y] * DOOMGENERIC_RESX;
    uint16_t *dst = fb + (yTop + y) * 128;
    for (int x = 0; x < VIEW_W; x++) dst[x] = pal565[row[colOfs[x]]];
  }
  lcd_draw(fb, 128, 128);
  vTaskDelay(1);                                  // let the idle task / watchdog breathe
}

extern "C" void DG_SleepMs(uint32_t ms) { delay(ms); }
extern "C" uint32_t DG_GetTicksMs() { return millis(); }
extern "C" void DG_SetWindowTitle(const char *title) { (void)title; }


// ---------------- WAD upload mode (WiFi) ----------------
static WebServer server(80);
static File   upFile;
static String upName;
static bool   upOk = false;
static String upMsg;

// status: 0 = waiting, 1 = receiving, 2 = saved, 3 = error
static void showUploadScreen(int status, const char *line1, const char *line2) {
  if (!fb) return;
  const uint16_t white = toRgb565(255, 255, 255), yellow = toRgb565(255, 220, 0), green = toRgb565(0, 255, 0),
                 red = toRgb565(255, 60, 60), cyan = toRgb565(0, 220, 255);
  char buf[32];
  memset(fb, 0, 128 * 128 * 2);
  drawText(2, 2, "WAD UPLOADER", yellow);
  drawText(2, 16, "1. Join WiFi:", white);
  drawText(2, 26, AP_SSID, cyan);
  snprintf(buf, sizeof(buf), "pass: %s", AP_PASS);
  drawText(2, 36, buf, white);
  drawText(2, 50, "2. Open browser:", white);
  drawText(2, 60, "http://192.168.4.1", cyan);
  uint16_t sc = status == 2 ? green : status == 3 ? red : status == 1 ? yellow : white;
  drawText(2, 78, status == 0 ? "Waiting for upload" : status == 1 ? "Receiving..." : status == 2 ? "SAVED! Restart me" : "ERROR", sc);
  if (line1) drawText(2, 88, line1, sc);
  if (line2) drawText(2, 98, line2, white);
  snprintf(buf, sizeof(buf), "Flash: %u/%u KB", (unsigned)(LittleFS.usedBytes() / 1024), (unsigned)(LittleFS.totalBytes() / 1024));
  drawText(2, 116, buf, white);
  lcd_draw(fb, 128, 128);
}

static const char PAGE_HEAD[] PROGMEM = R"HTML(<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CyberPi WAD Uploader</title>
<style>
body{font-family:sans-serif;max-width:560px;margin:20px auto;padding:0 12px}
button,input{font-size:16px;margin:6px 0}
progress{width:100%;height:18px}
li{margin:6px 0}
</style></head><body>
<h2>CyberPi WAD Uploader</h2>
<input type="file" id="f" accept=".wad"><br>
<button onclick="up()">Upload</button>
<progress id="p" value="0" max="100"></progress>
<div id="m"></div>
<script>
function up(){
  var f=document.getElementById('f').files[0];
  if(!f){document.getElementById('m').textContent='Choose a .wad file first.';return;}
  var x=new XMLHttpRequest();
  x.open('POST','/upload');
  x.upload.onprogress=function(e){if(e.lengthComputable)document.getElementById('p').value=e.loaded*100/e.total;};
  x.onload=function(){document.getElementById('m').textContent=x.responseText;setTimeout(function(){location.reload();},2500);};
  x.onerror=function(){document.getElementById('m').textContent='Upload failed (connection lost).';};
  var d=new FormData();d.append('wad',f,f.name);
  document.getElementById('m').textContent='Uploading... keep this page open.';
  x.send(d);
}
</script>
)HTML";

static String cleanName(String n) {
  int s = max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
  if (s >= 0) n = n.substring(s + 1);
  n.toLowerCase();
  String o;
  for (unsigned i = 0; i < n.length(); i++) {
    char c = n[i];
    if (isalnum((unsigned char)c) || c == '.' || c == '_' || c == '-') o += c;
  }
  return o;
}

static String wifiSsid, wifiPass;               // home WiFi used by online play (stored in flash, set from the uploader page)
static void loadWifi() {
  Preferences pr;
  pr.begin("cpdoom", false);
  wifiSsid = pr.getString("ssid", "");
  wifiPass = pr.getString("pass", "");
  pr.end();
}
static String htmlEsc(String t) {
  t.replace("&", "&amp;"); t.replace("<", "&lt;"); t.replace(">", "&gt;"); t.replace("\"", "&quot;");
  return t;
}

static void onWifiSave() {
  loadWifi();
  String s = server.arg("ssid"), p = server.arg("pass");
  s.trim();
  if (p.length() == 0 && s == wifiSsid) p = wifiPass;          // empty password box = keep the saved one
  if (s.length() < 1 || s.length() > 32 || p.length() > 63 || (p.length() > 0 && p.length() < 8)) {
    server.send(400, "text/plain", "Network name must be 1-32 characters. The password must be 8-63 characters (or empty for an open network). Go back and try again.");
    return;
  }
  Preferences pr;
  pr.begin("cpdoom", false);
  pr.putString("ssid", s);
  pr.putString("pass", p);
  pr.end();
  Serial.printf("WiFi saved: %s\n", s.c_str());
  server.sendHeader("Location", "/?saved=1");
  server.send(303);
}

static void onRoot() {
  String h = FPSTR(PAGE_HEAD);
  h += "<h3>Files in flash</h3><ul>";
  File root = LittleFS.open("/");
  File f = root.openNextFile();
  int count = 0;
  while (f) {
    if (!f.isDirectory()) {
      String nm = f.name();
      if (nm.startsWith("/")) nm = nm.substring(1);
      h += "<li>" + nm + " - " + String((unsigned)(f.size() / 1024)) + " KB ";
      h += "<a href=\"/delete?f=" + nm + "\" onclick=\"return confirm('Delete " + nm + "?')\">delete</a></li>";
      count++;
    }
    f = root.openNextFile();
  }
  if (!count) h += "<li>(no files yet)</li>";
  h += "</ul><p>Storage: " + String((unsigned)(LittleFS.usedBytes() / 1024)) + " KB used of " +
       String((unsigned)(LittleFS.totalBytes() / 1024)) + " KB</p>";
  loadWifi();
  h += "<h3>WiFi for online play</h3>";
  if (server.hasArg("saved")) h += "<p><b>WiFi saved.</b> Restart the CyberPi and choose \"Play online\".</p>";
  h += "<form method=\"post\" action=\"/wifi\">Network name (SSID):<br><input name=\"ssid\" maxlength=\"32\" value=\"";
  h += htmlEsc(wifiSsid);
  h += "\"><br>Password:<br><input name=\"pass\" type=\"password\" maxlength=\"63\"><br>";
  h += "<button type=\"submit\">Save WiFi</button></form>";
  h += "<p>Saved network: ";
  h += wifiSsid.length() ? htmlEsc(wifiSsid) : String("(none yet)");
  h += wifiSsid.length() ? " (password empty = keep the saved one)" : "";
  h += "</p></body></html>";
  server.send(200, "text/html", h);
}

static void onDelete() {
  String nm = cleanName(server.arg("f"));
  if (nm.length() && LittleFS.exists("/" + nm)) LittleFS.remove("/" + nm);
  showUploadScreen(0, nullptr, nullptr);
  server.sendHeader("Location", "/");
  server.send(303);
}

static void onUploadDone() {
  server.send(upOk ? 200 : 500, "text/plain", upMsg.length() ? upMsg : String("Upload failed."));
}

static void onUploadData() {
  static uint32_t lastDraw = 0;
  HTTPUpload &u = server.upload();
  if (u.status == UPLOAD_FILE_START) {
    upOk = false; upMsg = "";
    upName = cleanName(u.filename);
    if (!upName.endsWith(".wad")) {
      upMsg = "File name must end in .wad"; upName = "";
      showUploadScreen(3, "Name must end .wad", nullptr);
      return;
    }
    String path = "/" + upName;
    if (LittleFS.exists(path)) LittleFS.remove(path);
    upFile = LittleFS.open(path, "w");
    if (!upFile) { upMsg = "Could not create the file in flash."; showUploadScreen(3, "Cannot create file", nullptr); return; }
    upOk = true;
    Serial.printf("Receiving %s\n", upName.c_str());
    showUploadScreen(1, upName.c_str(), "0 KB");
    lastDraw = millis();
  } else if (u.status == UPLOAD_FILE_WRITE) {
    if (upOk && upFile) {
      if (upFile.write(u.buf, u.currentSize) != u.currentSize) {
        upOk = false; upMsg = "Write failed - the flash storage is probably full.";
        upFile.close();
        showUploadScreen(3, "Flash full?", upName.c_str());
      } else if (millis() - lastDraw > 400) {      // refresh the screen a few times a second
        char b[24]; snprintf(b, sizeof(b), "%u KB", (unsigned)(u.totalSize / 1024));
        showUploadScreen(1, upName.c_str(), b);
        lastDraw = millis();
      }
    }
  } else if (u.status == UPLOAD_FILE_END) {
    if (upFile) upFile.close();
    if (upOk) {
      upMsg = "Saved " + upName + " (" + String((unsigned)u.totalSize) + " bytes). Restart the CyberPi to play.";
      Serial.println(upMsg);
      char b[24]; snprintf(b, sizeof(b), "%u KB", (unsigned)(u.totalSize / 1024));
      showUploadScreen(2, upName.c_str(), b);
    } else if (upName.length()) {
      LittleFS.remove("/" + upName);          // don't leave a partial file behind
    }
  } else if (u.status == UPLOAD_FILE_ABORTED) {
    if (upFile) upFile.close();
    upOk = false; upMsg = "Upload aborted.";
    if (upName.length()) LittleFS.remove("/" + upName);
    showUploadScreen(3, "Upload aborted", nullptr);
  }
}

// Never returns. Hosts the upload page until the CyberPi is restarted.
static void uploadMode() {
  if (!LittleFS.begin(true)) {                 // true = format the storage if it has never been set up
    CP_Fatal("Storage failed. Check partitions.csv is next to the sketch.");
  }
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_SSID, AP_PASS);
  server.on("/", HTTP_GET, onRoot);
  server.on("/delete", HTTP_GET, onDelete);
  server.on("/wifi", HTTP_POST, onWifiSave);
  server.on("/upload", HTTP_POST, onUploadDone, onUploadData);
  server.begin();
  Serial.printf("Upload mode: join WiFi \"%s\" (password %s), then open http://%s\n", AP_SSID, AP_PASS, WiFi.softAPIP().toString().c_str());
  showUploadScreen(0, nullptr, nullptr);
  for (;;) { server.handleClient(); delay(1); }
}

// ---------------- start-up menu ----------------
#define MODE_LOCAL  0
#define MODE_ONLINE 1
#define MODE_SETUP  2

static void fillRect(int x, int y, int w, int h, uint16_t c) {
  for (int yy = y; yy < y + h; yy++) for (int xx = x; xx < x + w; xx++) putPx(xx, yy, c);
}

static void drawBootMenu(int sel, int secs) {
  static const char *items[3] = { "Play on CyberPi", "Play online (PC/PS)", "WAD + WiFi setup" };
  const uint16_t white = toRgb565(255, 255, 255), yellow = toRgb565(255, 220, 0), cyan = toRgb565(0, 220, 255),
                 grey = toRgb565(150, 150, 150), hi = toRgb565(0, 70, 140);
  memset(fb, 0, 128 * 128 * 2);
  drawText(2, 2, "CYBERPI DOOM", yellow);
  for (int i = 0; i < 3; i++) {
    int y = 22 + i * 16;
    if (i == sel) fillRect(0, y - 3, 128, 14, hi);
    drawText(6, y, items[i], i == sel ? white : grey);
  }
  drawText(2, 80, "Up/Down: choose", white);
  drawText(2, 90, "A: start", white);
  if (secs >= 0) { char b[24]; snprintf(b, sizeof(b), "Starting in %d...", secs); drawText(2, 112, b, cyan); }
  lcd_draw(fb, 128, 128);
}

// Shows the menu. With no button press it starts the last "play" choice after 3 seconds.
static int bootMenu() {
  Preferences pr;
  pr.begin("cpdoom", false);
  int sel = pr.getUChar("mode", MODE_LOCAL);
  if (sel != MODE_ONLINE) sel = MODE_LOCAL;
  bool autoGo = true, pU = true, pD = true, pA = true;   // start "held" so a leftover press does not skip the menu
  uint32_t t0 = millis();
  int shown = -2;
  for (;;) {
    uint16_t g = aw_get_gpio();
    if ((g & 0x007F) != 0) {                             // ignore failed I2C reads
      bool U = ((g >> JOY_UP) & 1) == 0, D = ((g >> JOY_DOWN) & 1) == 0, A = ((g >> BTN_A) & 1) == 0;
      if (U && !pU) { sel = (sel + 2) % 3; autoGo = false; shown = -2; }
      if (D && !pD) { sel = (sel + 1) % 3; autoGo = false; shown = -2; }
      if (A && !pA) break;
      pU = U; pD = D; pA = A;
    }
    int secs = -1;
    if (autoGo) { secs = 3 - (int)((millis() - t0) / 1000); if (secs <= 0) break; }
    int key = sel * 10 + (secs + 1);
    if (key != shown) { shown = key; drawBootMenu(sel, secs); }
    delay(30);
  }
  if (sel != MODE_SETUP) pr.putUChar("mode", (uint8_t)sel);
  pr.end();
  return sel;
}

// ---------------- online play ----------------
static void onWifiEvent(arduino_event_id_t ev) {
  switch (ev) {
    case ARDUINO_EVENT_WIFI_AP_STACONNECTED:    Serial.println("WiFi: a device joined the CyberPi hotspot"); break;
    case ARDUINO_EVENT_WIFI_AP_STADISCONNECTED: Serial.println("WiFi: a device LEFT the CyberPi hotspot"); break;
    case ARDUINO_EVENT_WIFI_AP_STOP:            Serial.println("WiFi: the CyberPi hotspot STOPPED"); break;
    case ARDUINO_EVENT_WIFI_STA_DISCONNECTED:   Serial.println("WiFi: the CyberPi lost your home WiFi"); break;
    case ARDUINO_EVENT_WIFI_STA_GOT_IP:         Serial.println("WiFi: the CyberPi is connected to your home WiFi"); break;
    default: break;
  }
}

// Joins your WiFi (or opens its own hotspot if that fails), starts the web servers and shows the address
// to type into the PC browser. Returns true when online play is running.
static bool startOnline() {
  const uint16_t white = toRgb565(255, 255, 255), yellow = toRgb565(255, 220, 0), red = toRgb565(255, 60, 60), cyan = toRgb565(0, 220, 255);
  loadWifi();
  WiFi.onEvent(onWifiEvent);
  bool home = false;
  if (wifiSsid.length()) {
    memset(fb, 0, 128 * 128 * 2);
    drawText(2, 2, "ONLINE PLAY", yellow);
    drawText(2, 20, "Joining WiFi:", white);
    drawText(2, 30, wifiSsid.substring(0, 21).c_str(), cyan);
    lcd_draw(fb, 128, 128);
    WiFi.mode(WIFI_STA);
    WiFi.setSleep(false);                         // lower delay
    WiFi.begin(wifiSsid.c_str(), wifiPass.c_str());
    uint32_t t0 = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) delay(250);
    home = (WiFi.status() == WL_CONNECTED);
    if (!home) { Serial.println("Online play: could not join the saved WiFi"); WiFi.disconnect(true); delay(200); }
  }
  if (!home) {
    WiFi.mode(WIFI_AP);
    WiFi.softAP(PLAY_AP_SSID, AP_PASS, 1, 0, 2);   // channel 1, visible, at most 2 devices
    delay(300);
  }
  WiFi.setTxPower(WIFI_POWER_11dBm);              // gentler on the USB power supply; plenty for a room
  String ip = home ? WiFi.localIP().toString() : WiFi.softAPIP().toString();

  if (!webplay_start()) {
    showMessage("Online play failed", "Could not start the web server (not enough memory?). Playing on the CyberPi only.", red);
    delay(4000);
    WiFi.mode(WIFI_OFF);
    return false;
  }

  memset(fb, 0, 128 * 128 * 2);
  drawText(2, 2, "ONLINE PLAY", yellow);
  if (home) {
    String l = "WiFi: " + wifiSsid;
    drawText(2, 16, l.substring(0, 21).c_str(), white);
    drawText(2, 34, "On your PC browser", white);
    drawText(2, 44, "open this address:", white);
    drawText(2, 58, ("IP: " + ip).c_str(), cyan);
  } else {
    drawText(2, 16, wifiSsid.length() ? "Can't join your WiFi" : "No WiFi saved yet", red);
    drawText(2, 28, "Own hotspot instead:", white);
    drawText(2, 38, PLAY_AP_SSID, cyan);
    drawText(2, 48, "pass: " AP_PASS, white);
    drawText(2, 62, "Join it on the PC,", white);
    drawText(2, 72, "then open:", white);
    drawText(2, 82, ("IP: " + ip).c_str(), cyan);
  }
  drawText(2, 116, "A = start Doom", yellow);
  lcd_draw(fb, 128, 128);
  Serial.printf("Online play ready. Open http://%s/ in a PC browser. Free internal RAM %u KB\n",
                ip.c_str(), (unsigned)(esp_get_free_heap_size() / 1024));

  bool pA = true;                                  // wait for A (after it was released from the menu)
  for (;;) {
    uint16_t g = aw_get_gpio();
    if ((g & 0x007F) != 0) {
      bool A = ((g >> BTN_A) & 1) == 0;
      if (A && !pA) break;
      pA = A;
    }
    delay(30);
  }
  webOn = true;
  return true;
}

// ---------------- start-up ----------------
static TaskHandle_t doomHandle = nullptr;

static void doomTask(void *) {
  static char a0[] = "doom", a1[] = "-iwad";      // no "-nosound": sound effects are on
  static char *argv[] = { a0, a1, wadPath };
  Serial.printf("Starting Doom with %s (free PSRAM %u KB, free heap %u KB)\n", wadPath,
                (unsigned)(heap_caps_get_free_size(MALLOC_CAP_SPIRAM) / 1024), (unsigned)(esp_get_free_heap_size() / 1024));
  doomgeneric_Create(3, argv);
  for (;;) doomgeneric_Tick();
}

void setup() {
  Serial.begin(115200);
  delay(200);
  i2c_init();
  aw_init();
  int pads[] = { JOY_UP, JOY_DOWN, JOY_RIGHT, JOY_LEFT, JOY_CENTER, BTN_A, BTN_B, BTN_MENU };
  for (int i = 0; i < 8; i++) aw_pinMode((aw_gpio_num_t)pads[i], AW_GPIO_MODE_INPUT);
  lcd_init();
  lcd_on();
  fb = (uint16_t *)heap_caps_malloc(128 * 128 * 2, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if (!fb) { Serial.println("FATAL: no RAM for display buffer"); for (;;) delay(1000); }
  memset(fb, 0, 128 * 128 * 2);

  // Colour calibration: runs on first boot, or whenever B is held at power-on.
  {
    uint16_t g = aw_get_gpio();
    bool bHeld = ((g & 0x007F) != 0) && (((g >> BTN_B) & 1) == 0);
    bool aHeld = ((g & 0x007F) != 0) && (((g >> BTN_A) & 1) == 0);
    colorSetup(bHeld);
    memset(fb, 0, 128 * 128 * 2);
    if (aHeld) uploadMode();                    // A held at power-on = WAD upload mode
  }

  int mode = bootMenu();                        // Play on CyberPi / Play online / WAD + WiFi setup
  if (mode == MODE_SETUP) uploadMode();

  if (!psramFound() || heap_caps_get_free_size(MALLOC_CAP_SPIRAM) < 3 * 1024 * 1024)
    CP_Fatal("PSRAM missing or too small. Arduino IDE: Tools > PSRAM > Enabled");

  if (!LittleFS.begin(false))
    uploadMode();                               // storage never set up: open the uploader (it formats it)

  // Doom writes savegames to /littlefs/savegame/ - the folder has to exist first.
  if (!LittleFS.exists("/savegame") && !LittleFS.mkdir("/savegame"))
    Serial.println("WARNING: could not create /savegame folder");
  Serial.printf("Flash storage: %u KB used of %u KB\n",
                (unsigned)(LittleFS.usedBytes() / 1024), (unsigned)(LittleFS.totalBytes() / 1024));

  static const char *names[MAX_WAD_FILES] = { "doom.wad", "doom2.wad", "doom1.wad", "freedoom1.wad", "freedoom2.wad" };
  wadPath[0] = 0;
  for (int i = 0; i < MAX_WAD_FILES; i++) {
    String p = String("/") + names[i];
    if (LittleFS.exists(p)) { snprintf(wadPath, sizeof(wadPath), "/littlefs%s", p.c_str()); break; }
  }
  if (!wadPath[0]) {
    LittleFS.end();
    uploadMode();                               // no WAD stored yet: open the uploader
  }

  if (mode == MODE_ONLINE) startOnline();       // joins WiFi + starts the web servers (falls back to offline if that fails)

  // Doom needs a deep stack; give it its own task on the second core.
  xTaskCreatePinnedToCore(doomTask, "doom", 48 * 1024, nullptr, 1, &doomHandle, 1);
}

void loop() {
  if (!webOn) { delay(1000); return; }
  // Online play: print the memory situation every 3 s (helps to see if the CyberPi is running out of RAM).
  Serial.printf("Mem: internal RAM %u KB free (largest block %u KB, lowest ever %u KB) | Doom stack unused %u KB | video frames skipped for low RAM: %u | devices on hotspot: %u | web: page loads %u, control msgs %u, frames offered %u / sent %u\n",
                (unsigned)(heap_caps_get_free_size(MALLOC_CAP_INTERNAL) / 1024),
                (unsigned)(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL) / 1024),
                (unsigned)(heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL) / 1024),
                doomHandle ? (unsigned)(uxTaskGetStackHighWaterMark(doomHandle) / 1024) : 0u,
                webplay_low_mem_skips(), (unsigned)WiFi.softAPgetStationNum(),
                webplay_stat(0), webplay_stat(1), webplay_stat(2), webplay_stat(3));
  delay(3000);
}
