#pragma once
/* CyberPi build settings for the Doom engine (included first by doomgeneric.h). */
#define CMAP256 1               /* engine renders 8-bit palette frames; we convert to RGB565 ourselves */
#define DOOMGENERIC_RESX 320
#define DOOMGENERIC_RESY 200
#define CP_ZONE_MB 2            /* Doom's memory pool in PSRAM (MB). Raise to 3 if you have spare PSRAM. */
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
void *CP_Alloc(size_t n);       /* zeroed PSRAM allocation; stops with an on-screen error if it fails */
void  CP_AllocAll(void);        /* allocates the renderer's big tables in PSRAM */
void  CP_Fatal(const char *msg);/* shows msg on the CyberPi screen and halts */
#ifdef __cplusplus
}
#endif
