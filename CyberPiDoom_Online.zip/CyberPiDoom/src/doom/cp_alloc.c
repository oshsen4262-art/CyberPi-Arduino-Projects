/* PSRAM allocation for the Doom engine on the CyberPi. */
#include <stdio.h>
#include <string.h>
#include "esp_heap_caps.h"
#include "cp_config.h"

void R_AllocPlaneBuffers(void);
void R_AllocBspBuffers(void);
void R_AllocThingBuffers(void);
void R_AllocMainBuffers(void);
void D_AllocLoopBuffers(void);
void CP_InitInfoTables(void);

void *CP_Alloc(size_t n)
{
    void *p = heap_caps_calloc(1, n, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (p == NULL) {
        char msg[96];
        snprintf(msg, sizeof(msg), "Out of PSRAM (%u bytes). Tools > PSRAM must be Enabled", (unsigned)n);
        CP_Fatal(msg);
    }
    return p;
}

void CP_AllocAll(void)
{
    R_AllocPlaneBuffers();
    R_AllocBspBuffers();
    R_AllocThingBuffers();
    R_AllocMainBuffers();
    D_AllocLoopBuffers();
    CP_InitInfoTables();
}
