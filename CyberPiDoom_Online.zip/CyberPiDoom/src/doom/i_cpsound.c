//
// i_cpsound.c - Doom sound effects for the CyberPi (ESP32 built-in DAC -> speaker amp)
//
// Replaces i_sdlsound.c and i_sdlmusic.c. Sound effects only; music is silent.
// Mixes up to 8 channels at 22050 Hz mono in a task on core 0 (Doom runs on core 1),
// and plays through the same DAC path as the CyberPi MP3 player sketch.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/i2s.h"

#include "config.h"
#include "doomtype.h"
#include "deh_str.h"
#include "i_sound.h"
#include "w_wad.h"
#include "z_zone.h"

#include "../cyberpi/io/aw9523b.h"

// ---------------- settings ----------------
#define CP_SOUND_ENABLED 1      // 0 = never start audio (game stays silent)
#define CP_OUT_RATE      22050  // output sample rate (Hz)
#define CP_BLOCK         128    // samples mixed per block (~6 ms)
#define CP_CHANNELS      8      // Doom uses up to 8 sound channels
#define CP_GAIN          2      // master loudness multiplier (1 = quiet, 2 = normal, 3 = loud/may clip)
#define CP_AMP_ENABLE    AW_P1_3
#define CP_MAX_LUMPS     160    // distinct sound effects kept track of at once
#define CP_STARTUP_BEEP  1      // 1 = play a short beep when sound starts (proves the speaker works)
#define CP_SOUND_DEBUG   1      // 1 = print sound events to the serial monitor

// ---------------- state ----------------
int   use_libsamplerate   = 0;      // referenced by m_config.c when FEATURE_SOUND is on
float libsamplerate_scale = 0.65f;

static boolean  use_prefix = true;
static boolean  ready = false;

extern int webplay_sound_enabled(void);   // online play: speaker stays silent unless the PC page turns it on
static portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;

// One entry per sound lump that has been played. 'users' counts channels currently using it,
// so the lump is only allowed to be purged from Doom's memory when nobody is playing it.
typedef struct {
  int lump;
  int users;
  const uint8_t *raw;
} lumpref_t;
static lumpref_t refs[CP_MAX_LUMPS];
static int nrefs = 0;

typedef struct {
  int       active;       // being mixed right now
  int       finished;     // mixer reached the end; engine thread still has to release the lump
  unsigned  gen;          // bumped on every start/stop so the mixer can detect changes
  int       ref;          // index into refs[], -1 if none
  const uint8_t *data;
  int       len;
  uint32_t  pos;          // 16.16 fixed point position in samples
  uint32_t  step;         // 16.16 fixed point step per output sample
  int       vol;          // 0..127
} chan_t;
static chan_t chans[CP_CHANNELS];

// ---------------- lump handling (engine thread only) ----------------
static int find_ref(int lump) {
  for (int i = 0; i < nrefs; i++) if (refs[i].lump == lump) return i;
  if (nrefs >= CP_MAX_LUMPS) return -1;
  refs[nrefs].lump = lump; refs[nrefs].users = 0; refs[nrefs].raw = NULL;
  return nrefs++;
}

static void release_ref(int r) {
  if (r < 0 || r >= nrefs) return;
  if (refs[r].users > 0) refs[r].users--;
  if (refs[r].users == 0 && refs[r].raw) Z_ChangeTag((void *)refs[r].raw, PU_CACHE);
}

// Doom sound lump: 2 bytes format (3), 2 bytes rate, 4 bytes length, then 16 pad bytes,
// the samples (unsigned 8-bit), and 16 pad bytes.
static boolean parse_lump(const uint8_t *d, int lumplen, const uint8_t **samples, int *len, int *rate) {
  if (!d || lumplen < 8 || d[0] != 0x03 || d[1] != 0x00) return false;
  *rate = (d[3] << 8) | d[2];
  uint32_t length = (uint32_t)d[4] | ((uint32_t)d[5] << 8) | ((uint32_t)d[6] << 16) | ((uint32_t)d[7] << 24);
  if (length > (uint32_t)(lumplen - 8) || length <= 48 || *rate <= 0) return false;
  *samples = d + 8 + 16;
  *len = (int)length - 32;
  return true;
}

// ---------------- mixer task (core 0) ----------------
static void mixer_task(void *arg) {
  static int32_t  acc[CP_BLOCK];
  static uint16_t out[CP_BLOCK * 2];
  for (;;) {
    memset(acc, 0, sizeof(acc));
    for (int c = 0; c < CP_CHANNELS; c++) {
      chan_t s;
      portENTER_CRITICAL(&mux); s = chans[c]; portEXIT_CRITICAL(&mux);
      if (!s.active) continue;
      uint32_t pos = s.pos;
      int done = 0;
      for (int i = 0; i < CP_BLOCK; i++) {
        uint32_t idx = pos >> 16;
        if (idx >= (uint32_t)s.len) { done = 1; break; }
        acc[i] += ((int)s.data[idx] - 128) * s.vol;
        pos += s.step;
      }
      portENTER_CRITICAL(&mux);
      if (chans[c].gen == s.gen && chans[c].active) {
        chans[c].pos = pos;
        if (done) { chans[c].active = 0; chans[c].finished = 1; }
      }
      portEXIT_CRITICAL(&mux);
    }
    for (int i = 0; i < CP_BLOCK; i++) {
      int32_t v = acc[i] * CP_GAIN;
      if (v > 32767) v = 32767; else if (v < -32768) v = -32768;
      uint16_t u = (uint16_t)(v + 32768);          // DAC wants unsigned, silence = mid-scale
      out[2 * i] = u; out[2 * i + 1] = u;
    }
    size_t w;
    i2s_write(I2S_NUM_0, out, sizeof(out), &w, portMAX_DELAY);
  }
}

// ---------------- sound module ----------------
static boolean CP_InitSound(boolean use_sfx_prefix) {
#if CP_SOUND_ENABLED
  use_prefix = use_sfx_prefix;
  memset(chans, 0, sizeof(chans));
  for (int c = 0; c < CP_CHANNELS; c++) chans[c].ref = -1;

  aw_pinMode(CP_AMP_ENABLE, AW_GPIO_MODE_OUTPUT);
  aw_digitalWrite(CP_AMP_ENABLE, 1);

  i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_DAC_BUILT_IN),
    .sample_rate = CP_OUT_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .intr_alloc_flags = 0,
    .dma_buf_count = 8,
    .dma_buf_len = CP_BLOCK,
    .use_apll = 0,
    .tx_desc_auto_clear = 1,
  };
  if (i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL) != ESP_OK) {
    printf("Sound: i2s install failed, running silent\n");
    return false;
  }
  i2s_set_dac_mode(I2S_DAC_CHANNEL_RIGHT_EN);

#if CP_STARTUP_BEEP
  if (webplay_sound_enabled())
  {                                              // ~0.3 s, 440 Hz square wave, straight to the speaker
    static uint16_t beep[CP_BLOCK * 2];
    size_t w;
    for (int blk = 0; blk < 52; blk++) {
      for (int i = 0; i < CP_BLOCK; i++) {
        int n = blk * CP_BLOCK + i;
        uint16_t u = ((n / 25) & 1) ? 0xC000 : 0x4000;
        beep[2 * i] = u; beep[2 * i + 1] = u;
      }
      i2s_write(I2S_NUM_0, beep, sizeof(beep), &w, portMAX_DELAY);
    }
  }
#endif

  if (xTaskCreatePinnedToCore(mixer_task, "sndmix", 4096, NULL, 2, NULL, 0) != pdPASS) {
    printf("Sound: could not start mixer task, running silent\n");
    return false;
  }
  ready = true;
  printf("Sound: on (%d Hz, %d channels)\n", CP_OUT_RATE, CP_CHANNELS);
  return true;
#else
  (void)use_sfx_prefix;
  return false;
#endif
}

static void CP_ShutdownSound(void) { }

static int CP_GetSfxLumpNum(sfxinfo_t *sfx) {
  char buf[9];
  if (sfx->link != NULL) sfx = sfx->link;
  if (use_prefix) snprintf(buf, sizeof(buf), "ds%s", DEH_String(sfx->name));
  else            snprintf(buf, sizeof(buf), "%s", DEH_String(sfx->name));
  return W_GetNumForName(buf);
}

// Free channels the mixer has finished with (runs on the engine thread, which owns Doom's memory).
static void CP_UpdateSound(void) {
  if (!ready) return;
  for (int c = 0; c < CP_CHANNELS; c++) {
    int ref = -1;
    portENTER_CRITICAL(&mux);
    if (chans[c].finished) { ref = chans[c].ref; chans[c].finished = 0; chans[c].ref = -1; }
    portEXIT_CRITICAL(&mux);
    if (ref >= 0) release_ref(ref);
  }
}

static void CP_UpdateSoundParams(int channel, int vol, int sep) {
  (void)sep;                                   // mono speaker, no panning
  if (!ready || channel < 0 || channel >= CP_CHANNELS) return;
  if (vol < 0) vol = 0; else if (vol > 127) vol = 127;
  portENTER_CRITICAL(&mux);
  if (chans[channel].active) chans[channel].vol = vol;
  portEXIT_CRITICAL(&mux);
}

static void CP_StopSound(int channel) {
  if (!ready || channel < 0 || channel >= CP_CHANNELS) return;
  int ref;
  portENTER_CRITICAL(&mux);
  ref = chans[channel].ref;
  chans[channel].active = 0; chans[channel].finished = 0; chans[channel].ref = -1;
  chans[channel].gen++;
  portEXIT_CRITICAL(&mux);
  if (ref >= 0) release_ref(ref);
}

static int CP_StartSound(sfxinfo_t *sfx, int channel, int vol, int sep) {
  (void)sep;
#if CP_SOUND_DEBUG
  if (!webplay_sound_enabled()) return -1;
  static int dbg_count = 0;
  if (dbg_count < 12) { dbg_count++; printf("Sound: start ch=%d lump=%d vol=%d ready=%d\n", channel, sfx->lumpnum, vol, (int)ready); }
#endif
  if (!ready || channel < 0 || channel >= CP_CHANNELS || sfx->lumpnum < 0) return -1;

  CP_StopSound(channel);

  int r = find_ref(sfx->lumpnum);
  if (r < 0) return -1;
  // (Re)load the lump and pin it in memory while a channel uses it.
  const uint8_t *raw = (const uint8_t *)W_CacheLumpNum(sfx->lumpnum, PU_STATIC);
  const uint8_t *samples; int len, rate;
  if (!parse_lump(raw, W_LumpLength(sfx->lumpnum), &samples, &len, &rate)) {
#if CP_SOUND_DEBUG
    printf("Sound: lump %d is not a usable sound effect\n", sfx->lumpnum);
#endif
    if (raw && refs[r].users == 0) Z_ChangeTag((void *)raw, PU_CACHE);
    return -1;
  }
  refs[r].raw = raw;
  refs[r].users++;

  if (vol < 0) vol = 0; else if (vol > 127) vol = 127;
  portENTER_CRITICAL(&mux);
  chans[channel].data = samples;
  chans[channel].len = len;
  chans[channel].pos = 0;
  chans[channel].step = (uint32_t)(((uint64_t)rate << 16) / CP_OUT_RATE);
  chans[channel].vol = vol;
  chans[channel].ref = r;
  chans[channel].finished = 0;
  chans[channel].gen++;
  chans[channel].active = 1;
  portEXIT_CRITICAL(&mux);
  return channel;
}

static boolean CP_SoundIsPlaying(int channel) {
  if (!ready || channel < 0 || channel >= CP_CHANNELS) return false;
  int a;
  portENTER_CRITICAL(&mux); a = chans[channel].active; portEXIT_CRITICAL(&mux);
  return a ? true : false;
}

static void CP_PrecacheSounds(sfxinfo_t *sounds, int num_sounds) {
  (void)sounds; (void)num_sounds;              // sounds are loaded on first use
}

static snddevice_t cp_sound_devices[] = {
  SNDDEVICE_SB, SNDDEVICE_PAS, SNDDEVICE_GUS, SNDDEVICE_WAVEBLASTER, SNDDEVICE_SOUNDCANVAS, SNDDEVICE_AWE32,
};

sound_module_t DG_sound_module = {
  cp_sound_devices,
  sizeof(cp_sound_devices) / sizeof(cp_sound_devices[0]),
  CP_InitSound,
  CP_ShutdownSound,
  CP_GetSfxLumpNum,
  CP_UpdateSound,
  CP_UpdateSoundParams,
  CP_StartSound,
  CP_StopSound,
  CP_SoundIsPlaying,
  CP_PrecacheSounds,
};

// ---------------- music module: silent stub ----------------
static int music_dummy;
static boolean CP_MusInit(void) { return true; }
static void    CP_MusShutdown(void) { }
static void    CP_MusSetVolume(int v) { (void)v; }
static void    CP_MusPause(void) { }
static void    CP_MusResume(void) { }
static void   *CP_MusRegister(void *data, int len) { (void)data; (void)len; return &music_dummy; }
static void    CP_MusUnRegister(void *h) { (void)h; }
static void    CP_MusPlay(void *h, boolean looping) { (void)h; (void)looping; }
static void    CP_MusStop(void) { }
static boolean CP_MusIsPlaying(void) { return false; }
static void    CP_MusPoll(void) { }

static snddevice_t cp_music_devices[] = { SNDDEVICE_NONE };

music_module_t DG_music_module = {
  cp_music_devices,
  1,
  CP_MusInit,
  CP_MusShutdown,
  CP_MusSetVolume,
  CP_MusPause,
  CP_MusResume,
  CP_MusRegister,
  CP_MusUnRegister,
  CP_MusPlay,
  CP_MusStop,
  CP_MusIsPlaying,
  CP_MusPoll,
};
