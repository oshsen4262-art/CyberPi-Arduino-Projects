#pragma once
/*
 * Online play: lets a PC browser watch the game and send controls back.
 *   port 80 : the web page (/), and controls coming from the browser (/in)
 *   port 81 : the video stream (/stream)
 * Everything here is safe to call when nobody is connected.
 */
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

/* Start the two small web servers. Returns 1 on success, 0 on failure (e.g. out of memory). */
int  webplay_start(void);

/* 1 while a browser is receiving the video stream. */
int  webplay_streaming(void);

/* Doom thread: offer the current 320x200 8-bit frame and its 768-byte RGB palette. Cheap if nobody is watching.
 * Skips the frame when the CyberPi is short of internal RAM. */
void webplay_offer_frame(const uint8_t *indexed, const uint8_t *palRGB);

/* 1 if the CyberPi speaker may play (always in offline play; in online play only when the PC page turns it on). */
int  webplay_sound_enabled(void);

/* 1 while a browser is watching and the CyberPi screen should be left alone. */
int  webplay_skip_lcd(void);

/* Counters for the serial log: 0 = page loads, 1 = control messages received, 2 = frames offered by Doom, 3 = frames sent. */
unsigned webplay_stat(int which);

/* How many frames were skipped because internal RAM was low (for the serial log). */
unsigned webplay_low_mem_skips(void);

/* Doom thread: bit mask of the keys the browser is holding (bit order = K_* enum in CyberPiDoom.ino). */
uint32_t webplay_keys(void);

/* Doom thread: turn amount (mouse / right stick) collected since the last call. */
int  webplay_take_mouse(void);

/* Doom thread: number of "next weapon" / "previous weapon" presses since the last call. */
void webplay_take_weapon_steps(int *next, int *prev);

#ifdef __cplusplus
}
#endif
