#include <Arduino.h>
#include <esp_http_server.h>
#include <esp_heap_caps.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "webplay.h"
#include "page.h"

#define FRAME_W   320
#define FRAME_H   200
#define HDR_BYTES 8
#define PAL_BYTES 768
#define KEY_MASK  0x1FFFFFu          /* 21 held-key bits */
#define MIN_FREE_INTERNAL_HEAP (10 * 1024)   /* below this the video pauses so the game, buttons and WiFi keep working */

static httpd_handle_t ctlServer = NULL;   /* port 80 */
static httpd_handle_t vidServer = NULL;   /* port 81 */

/* ---- controls coming from the browser (written by the web task, read by the Doom task) ---- */
static volatile uint32_t inKeys   = 0;    /* keys held right now */
static volatile uint32_t inLatch  = 0;    /* keys that were down at any moment since Doom last looked (so quick taps are not lost) */
static volatile int32_t  inMouse  = 0;
static volatile int32_t  inNext   = 0;
static volatile int32_t  inPrev   = 0;
static volatile uint32_t inLastMs = 0;

static volatile int streaming  = 0;
/* ---- video hand-off: the Doom task fills the buffer, the web task sends it ---- */
enum { FB_FREE = 0, FB_READY = 1, FB_SENDING = 2 };
static volatile int fbState    = FB_FREE;
static volatile int streamMode = 1;       /* 1 = 320x200, 2 = 160x100 */
static uint8_t *frameBuf = NULL;          /* header + palette + pixels */
static uint16_t frameSeq = 0;
static volatile unsigned lowMemSkips = 0;
static volatile int webActive = 0;        /* 1 once online play is running */
static volatile int soundOn   = 0;        /* set from the PC page: CyberPi speaker allowed (off by default) */
static volatile int screenOn  = 0;        /* set from the PC page: also draw on the CyberPi screen (off by default) */

/* Online play: no sound on the CyberPi unless the PC page turns it on. Offline play: always on. */
extern "C" int webplay_sound_enabled(void) { return !webActive || soundOn; }
/* Online play with a browser watching: leave the CyberPi screen alone unless the PC page turns it on. */
extern "C" int webplay_skip_lcd(void) { return webActive && streaming && !screenOn; }
static volatile unsigned cntPage = 0, cntIn = 0, cntOffered = 0, cntSent = 0;   /* for the serial log */

extern "C" unsigned webplay_stat(int which) {
  switch (which) { case 0: return cntPage; case 1: return cntIn; case 2: return cntOffered; default: return cntSent; }
}

extern "C" unsigned webplay_low_mem_skips(void) { return lowMemSkips; }

extern "C" int webplay_streaming(void) { return streaming; }

extern "C" void webplay_offer_frame(const uint8_t *src, const uint8_t *pal) {
  if (!streaming || fbState != FB_FREE || !frameBuf) return;
  static uint32_t lastOffer = 0;                       /* at most ~14 frames/s to the browser: gentler on WiFi and on the CPU */
  if (millis() - lastOffer < 70) return;
  if (heap_caps_get_free_size(MALLOC_CAP_INTERNAL) < MIN_FREE_INTERNAL_HEAP) { lowMemSkips++; return; }   /* out of RAM: skip this frame */
  lastOffer = millis();
  const int mode = streamMode;
  const uint32_t div = (mode == 3) ? 4 : (mode == 2) ? 2 : 1;      /* 1 = 320x200, 2 = 160x100, 3 = 80x50 */
  const uint32_t w = FRAME_W / div;
  const uint32_t h = FRAME_H / div;
  const uint32_t len = PAL_BYTES + w * h;
  uint8_t *p = frameBuf;
  frameSeq++;
  p[0] = 0xD0; p[1] = (uint8_t)mode; p[2] = frameSeq & 255; p[3] = frameSeq >> 8;
  p[4] = len & 255; p[5] = (len >> 8) & 255; p[6] = (len >> 16) & 255; p[7] = (len >> 24) & 255;
  memcpy(p + HDR_BYTES, pal, PAL_BYTES);
  uint8_t *out = p + HDR_BYTES + PAL_BYTES;
  if (div > 1) {                            /* shrink: take one pixel out of every div x div block */
    const uint32_t o = div / 2;
    for (uint32_t y = 0; y < h; y++) {
      const uint8_t *row = src + (y * div + o) * FRAME_W + o;
      for (uint32_t x = 0; x < w; x++) out[y * w + x] = row[x * div];
    }
  } else {
    memcpy(out, src, FRAME_W * FRAME_H);
  }
  __sync_synchronize();
  cntOffered++;
  fbState = FB_READY;
}

/* ---- controls, read by the Doom task ---- */
extern "C" uint32_t webplay_keys(void) {
  uint32_t latch = __atomic_exchange_n(&inLatch, 0u, __ATOMIC_SEQ_CST);
  if (millis() - inLastMs > 1500) { inKeys = 0; return 0; }   /* browser went quiet: let go of everything */
  return inKeys | latch;
}
extern "C" int webplay_take_mouse(void) {
  return (int)__atomic_exchange_n(&inMouse, 0, __ATOMIC_SEQ_CST);
}
extern "C" void webplay_take_weapon_steps(int *next, int *prev) {
  *next = (int)__atomic_exchange_n(&inNext, 0, __ATOMIC_SEQ_CST);
  *prev = (int)__atomic_exchange_n(&inPrev, 0, __ATOMIC_SEQ_CST);
}

/* ---------------- HTTP handlers ---------------- */
static esp_err_t page_handler(httpd_req_t *req) {
  cntPage++;
  Serial.println("Web play: page requested by a browser");
  httpd_resp_set_type(req, "text/html; charset=utf-8");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  return httpd_resp_send(req, PAGE_HTML, HTTPD_RESP_USE_STRLEN);
}

static esp_err_t favicon_handler(httpd_req_t *req) {
  httpd_resp_set_status(req, "204 No Content");
  return httpd_resp_send(req, NULL, 0);
}

/* GET /in?k=<hex key mask>&x=<turn>&n=<next weapon>&p=<previous weapon> */
static esp_err_t in_handler(httpd_req_t *req) {
  char q[120], v[16];
  if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK) {
    if (httpd_query_key_value(q, "k", v, sizeof(v)) == ESP_OK) {
      uint32_t k = (uint32_t)strtoul(v, NULL, 16) & KEY_MASK;
      inKeys = k;
      __atomic_fetch_or(&inLatch, k, __ATOMIC_SEQ_CST);
    }
    if (httpd_query_key_value(q, "x", v, sizeof(v)) == ESP_OK) {
      int x = atoi(v);
      if (x > 4000) x = 4000;
      if (x < -4000) x = -4000;
      if (x) __atomic_add_fetch(&inMouse, x, __ATOMIC_SEQ_CST);
    }
    if (httpd_query_key_value(q, "n", v, sizeof(v)) == ESP_OK) {
      int n = atoi(v); if (n > 7) n = 7;
      if (n > 0) __atomic_add_fetch(&inNext, n, __ATOMIC_SEQ_CST);
    }
    if (httpd_query_key_value(q, "p", v, sizeof(v)) == ESP_OK) {
      int p = atoi(v); if (p > 7) p = 7;
      if (p > 0) __atomic_add_fetch(&inPrev, p, __ATOMIC_SEQ_CST);
    }
    if (httpd_query_key_value(q, "a", v, sizeof(v)) == ESP_OK) soundOn  = (v[0] == '1');
    if (httpd_query_key_value(q, "v", v, sizeof(v)) == ESP_OK) screenOn = (v[0] == '1');
  }
  inLastMs = millis();
  cntIn++;
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");
  return httpd_resp_send(req, "ok", 2);
}

/* GET /stream?q=1|2 : endless chunked response. Each frame = 8-byte header, 768-byte palette, pixels. */
static esp_err_t stream_handler(httpd_req_t *req) {
  int mode = 1;
  char q[32], v[8];
  if (httpd_req_get_url_query_str(req, q, sizeof(q)) == ESP_OK &&
      httpd_query_key_value(q, "q", v, sizeof(v)) == ESP_OK) mode = (v[0] == '3') ? 3 : (v[0] == '2') ? 2 : 1;

  httpd_resp_set_type(req, "application/octet-stream");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  httpd_resp_set_hdr(req, "Cache-Control", "no-store");

  streamMode = mode;
  fbState = FB_FREE;
  streaming = 1;
  Serial.printf("Web play: video stream started (%s)\n", mode == 3 ? "ultra low" : mode == 2 ? "lite" : "full");

  esp_err_t res = ESP_OK;
  while (res == ESP_OK) {
    if (fbState != FB_READY) { vTaskDelay(pdMS_TO_TICKS(3)); continue; }
    fbState = FB_SENDING;
    const uint8_t *b = frameBuf;
    size_t total = HDR_BYTES + ((size_t)b[4] | ((size_t)b[5] << 8) | ((size_t)b[6] << 16) | ((size_t)b[7] << 24));
    for (size_t off = 0; off < total && res == ESP_OK;) {
      size_t n = total - off;
      if (n > 8192) n = 8192;
      res = httpd_resp_send_chunk(req, (const char *)(b + off), n);
      off += n;
    }
    fbState = FB_FREE;
    if (res == ESP_OK) cntSent++;
  }
  streaming = 0;
  fbState = FB_FREE;
  Serial.printf("Web play: video stream ended (result %d, errno %d, frames sent so far %u)\n", (int)res, errno, cntSent);
  return res;                               /* not ESP_OK, so the server closes the connection */
}

/* ---------------- start ---------------- */
extern "C" int webplay_start(void) {
  if (ctlServer) return 1;
  if (!frameBuf) {
    size_t sz = HDR_BYTES + PAL_BYTES + FRAME_W * FRAME_H;
    frameBuf = (uint8_t *)heap_caps_malloc(sz, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!frameBuf) frameBuf = (uint8_t *)malloc(sz);
    if (!frameBuf) { Serial.println("Web play: no memory for the video buffer"); return 0; }
  }

  httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
  cfg.server_port = 80;
  cfg.ctrl_port = 32768;
  cfg.max_open_sockets = 2;
  cfg.max_uri_handlers = 4;
  cfg.lru_purge_enable = true;
  cfg.stack_size = 4096;
  cfg.core_id = 0;                          /* keep WiFi work on core 0, Doom runs on core 1 */

  httpd_uri_t uPage = { "/", HTTP_GET, page_handler, NULL };
  httpd_uri_t uIn   = { "/in", HTTP_GET, in_handler, NULL };
  httpd_uri_t uIco  = { "/favicon.ico", HTTP_GET, favicon_handler, NULL };
  if (httpd_start(&ctlServer, &cfg) != ESP_OK) { Serial.println("Web play: could not start the web server (port 80)"); ctlServer = NULL; return 0; }
  httpd_register_uri_handler(ctlServer, &uPage);
  httpd_register_uri_handler(ctlServer, &uIn);
  httpd_register_uri_handler(ctlServer, &uIco);

  httpd_config_t vcfg = HTTPD_DEFAULT_CONFIG();
  vcfg.server_port = 81;
  vcfg.ctrl_port = 32769;
  vcfg.max_open_sockets = 2;
  vcfg.max_uri_handlers = 1;
  vcfg.lru_purge_enable = true;
  vcfg.stack_size = 4096;
  vcfg.core_id = 0;
  httpd_uri_t uStream = { "/stream", HTTP_GET, stream_handler, NULL };
  if (httpd_start(&vidServer, &vcfg) != ESP_OK) {
    Serial.println("Web play: could not start the video server (port 81)");
    httpd_stop(ctlServer); ctlServer = NULL; vidServer = NULL; return 0;
  }
  httpd_register_uri_handler(vidServer, &uStream);
  Serial.println("Web play: servers running (page on port 80, video on port 81)");
  webActive = 1;
  return 1;
}
