#pragma once
/* The web page served to the PC browser (video + keyboard / mouse / controller mapping).
 * Plain ASCII on purpose. Edit with care: it is one big C++ raw string. */
static const char PAGE_HTML[] = R"HTMLPAGE(<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CyberPi Doom</title>
<style>
:root{color-scheme:dark}
*{box-sizing:border-box}
html,body{margin:0;height:100%;background:#000;color:#e6e6e6;font:14px/1.4 system-ui,"Segoe UI",Arial,sans-serif;overflow:hidden}
#stage{position:fixed;inset:0;display:flex;align-items:center;justify-content:center}
#cv{image-rendering:pixelated;background:#0b0b0b;width:min(100vw,calc(100vh * 4 / 3));height:min(100vh,calc(100vw * 3 / 4))}
body.stretch #cv{width:100vw;height:100vh}
#bar{position:fixed;top:0;left:0;right:0;display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:6px 10px;background:rgba(0,0,0,.6);z-index:5}
#bar.locked{display:none}
button,select{font:inherit;color:#eee;background:#2a2a2a;border:1px solid #555;border-radius:6px;padding:4px 10px;cursor:pointer}
button:hover{background:#3a3a3a}
#st{margin-left:auto;opacity:.85}
#pad{opacity:.7}
#hint{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);background:rgba(0,0,0,.75);padding:8px 14px;border-radius:8px;z-index:4;pointer-events:none;display:none}
#panel{position:fixed;inset:0;background:rgba(10,10,10,.94);z-index:10;overflow:auto;display:none}
#panel.open{display:block}
#pin{max-width:780px;margin:0 auto;padding:16px 18px 70px}
h2{margin:6px 0 10px}h3{margin:22px 0 8px;border-bottom:1px solid #333;padding-bottom:4px}
.set{display:flex;align-items:center;gap:10px;margin:8px 0;flex-wrap:wrap}
.set label{min-width:260px}
.set small{opacity:.65}
.row{display:flex;gap:10px;align-items:center;padding:5px 0;border-bottom:1px solid #222;flex-wrap:wrap}
.nm{width:210px;flex:none}
.chips{display:flex;gap:6px;flex-wrap:wrap}
.chip{background:#1d3550;border-color:#2f5a8a}
#listen{position:fixed;inset:0;background:rgba(0,0,0,.82);z-index:20;display:none;align-items:center;justify-content:center;text-align:center;flex-direction:column;gap:14px;font-size:18px}
#listen.on{display:flex}
</style></head><body>
<div id="stage"><canvas id="cv" width="320" height="200"></canvas></div>
<div id="bar">
 <button id="bSet">Controls &amp; settings</button>
 <button id="bMenu">Doom menu</button>
 <button id="bFs">Fullscreen</button>
 <span id="pad"></span>
 <span id="st">Starting...</span>
</div>
<div id="hint"></div>
<div id="panel"><div id="pin">
 <h2>CyberPi Doom - controls &amp; settings</h2>
 <p><button id="bClose">Close (back to the game)</button></p>

 <h3>Mouse</h3>
 <div class="set"><label><input type="checkbox" id="cMouseLook"> Mouse look (click the game to capture the mouse)</label></div>
 <div class="set"><label for="cMouseSens">Mouse turn speed</label><input type="range" id="cMouseSens" min="0.2" max="5" step="0.1"><span id="vMouseSens"></span></div>
 <div class="set"><label><input type="checkbox" id="cHoldUse"> Holding the mouse fire button also presses USE (opens doors)</label></div>
 <div class="set"><label for="cHoldMs">...after holding for</label><input type="range" id="cHoldMs" min="200" max="1200" step="50"><span id="vHoldMs"></span></div>

 <h3>Controller (PlayStation, Xbox, ...)</h3>
 <div class="set"><small>Plug in or pair the controller with your PC, then press any button on it so the browser notices it.</small></div>
 <div class="set"><label for="cStickAxis">Analog turn axis (right stick left/right)</label>
  <select id="cStickAxis"><option>0</option><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option></select><small>2 is right for PS4/PS5/Xbox pads</small></div>
 <div class="set"><label for="cStickSens">Stick turn speed</label><input type="range" id="cStickSens" min="0.3" max="3" step="0.1"><span id="vStickSens"></span></div>
 <div class="set"><label for="cDead">Stick dead zone</label><input type="range" id="cDead" min="0.05" max="0.5" step="0.05"><span id="vDead"></span></div>

 <h3>Picture</h3>
 <div class="set"><label for="cQual">Video quality</label><select id="cQual"><option value="1">Full (320x200)</option><option value="2">Lite (160x100, for weak WiFi)</option><option value="3">Ultra low (80x50, for very weak WiFi)</option></select></div>
 <div class="set"><label><input type="checkbox" id="cAspect"> Keep the original 4:3 shape</label></div>
 <h3>Sound and CyberPi screen</h3>
 <div class="set"><label><input type="checkbox" id="cSound"> Play sound on the CyberPi speaker</label><small>off = silent. Sound on the PC is not available.</small></div>
 <div class="set"><label><input type="checkbox" id="cScreen"> Also show the game on the CyberPi screen</label><small>off = the CyberPi screen stays idle</small></div>

 <h3>Button mapping</h3>
 <p><small>Click <b>+ Add</b>, then press a key, click a mouse button, scroll the wheel, press a controller button or push a stick. Click a blue chip to remove it. One input can only do one thing.</small></p>
 <div id="binds"></div>
 <p><button id="bReset">Reset all controls to default</button></p>
</div></div>
<div id="listen"><div id="lmsg"></div><button id="lcancel">Cancel</button></div>

<script>
(function(){
'use strict';
var $=function(id){return document.getElementById(id);};

/* ---------- actions (the first 21 are held keys, the bit number is sent to the CyberPi) ---------- */
var ACTIONS=[
 ['fwd','Move forward'],['back','Move backward'],['tl','Turn left'],['tr','Turn right'],
 ['sl','Strafe left'],['sr','Strafe right'],['fire','Fire'],['use','Use / open doors'],
 ['enter','Menu: select (Enter)'],['esc','Menu / back (Esc)'],['run','Run'],['map','Map'],
 ['yes','Yes (Y)'],['no','No (N)'],
 ['w1','Weapon 1 (fist / saw)'],['w2','Weapon 2 (pistol)'],['w3','Weapon 3 (shotgun)'],['w4','Weapon 4 (chaingun)'],
 ['w5','Weapon 5 (rocket launcher)'],['w6','Weapon 6 (plasma gun)'],['w7','Weapon 7 (BFG)'],
 ['wnext','Next weapon'],['wprev','Previous weapon']
];
var NBITS=21;
var DEF={
 fwd:['k:KeyW','k:ArrowUp','a:1-','g:12'],
 back:['k:KeyS','k:ArrowDown','a:1+','g:13'],
 tl:['k:ArrowLeft','g:14'],
 tr:['k:ArrowRight','g:15'],
 sl:['k:KeyA','a:0-'],
 sr:['k:KeyD','a:0+'],
 fire:['m:0','k:ControlLeft','g:7','g:2'],
 use:['m:2','k:KeyE','k:Space','g:0'],
 enter:['k:Enter','g:3','g:0'],
 esc:['k:Escape','k:Backquote','g:9'],
 run:['k:ShiftLeft','g:6','g:10'],
 map:['k:Tab','g:8'],
 yes:['k:KeyY'],no:['k:KeyN'],
 w1:['k:Digit1'],w2:['k:Digit2'],w3:['k:Digit3'],w4:['k:Digit4'],w5:['k:Digit5'],w6:['k:Digit6'],w7:['k:Digit7'],
 wnext:['k:KeyX','w:d','g:5'],
 wprev:['k:KeyZ','w:u','g:4']
};
var cfg={mouseLook:true,mouseSens:1.5,holdUse:true,holdMs:400,stickAxis:2,stickSens:1,dead:0.15,aspect:true,quality:3,sound:false,screen:false};
var QN=['','full','lite','ultra low'];
var binds={};
function cloneDef(){var o={};for(var k in DEF)o[k]=DEF[k].slice();return o;}
binds=cloneDef();
function load(){
 try{var c=JSON.parse(localStorage.getItem('cpdoom.cfg2')||'null');if(c&&typeof c==='object'){for(var k in cfg)if(typeof c[k]===typeof cfg[k])cfg[k]=c[k];}}catch(e){}
 try{var b=JSON.parse(localStorage.getItem('cpdoom.binds')||'null');
  if(b&&typeof b==='object'){ACTIONS.forEach(function(a){if(Array.isArray(b[a[0]]))binds[a[0]]=b[a[0]].filter(function(x){return typeof x==='string';});});}}catch(e){}
}
function save(){try{localStorage.setItem('cpdoom.cfg2',JSON.stringify(cfg));localStorage.setItem('cpdoom.binds',JSON.stringify(binds));}catch(e){}}
load();

/* ---------- labels ---------- */
var KN={ControlLeft:'Ctrl',ControlRight:'Ctrl (R)',ShiftLeft:'Shift',ShiftRight:'Shift (R)',AltLeft:'Alt',AltRight:'Alt (R)',Space:'Space',Enter:'Enter',Escape:'Esc',Tab:'Tab',Backquote:'`',ArrowUp:'\u2191',ArrowDown:'\u2193',ArrowLeft:'\u2190',ArrowRight:'\u2192',Backspace:'Backspace'};
var PADN=['\u2715','\u25EF','\u25A2','\u25B3','L1','R1','L2','R2','Share','Options','L3','R3','D-pad \u2191','D-pad \u2193','D-pad \u2190','D-pad \u2192','PS','Touchpad'];
var AXN=['L-stick','L-stick','R-stick','R-stick'];
var AXD=[['\u2190','\u2192'],['\u2191','\u2193'],['\u2190','\u2192'],['\u2191','\u2193']];
function label(b){
 var t=b.charAt(0),v=b.slice(2);
 if(t==='k')return KN[v]||v.replace(/^Key/,'').replace(/^Digit/,'').replace(/^Numpad/,'Num ');
 if(t==='m')return ['Mouse left','Mouse middle','Mouse right','Mouse 4','Mouse 5'][+v]||('Mouse '+v);
 if(t==='w')return v==='u'?'Wheel up':'Wheel down';
 if(t==='g')return 'Pad '+(PADN[+v]||('button '+v));
 if(t==='a'){var n=+v.slice(0,-1),neg=v.slice(-1)==='-';return 'Pad '+(AXN[n]||('axis '+n))+' '+(AXD[n]?AXD[n][neg?0:1]:(neg?'\u2212':'+'));}
 return b;
}

/* ---------- input state ---------- */
var keysDown={},mouseDown={};          // plain objects used as sets
var pulse=0;                           // one-shot bits (menu button, wheel bindings)
var pend={dx:0,n:0,p:0};               // turn counts and weapon steps waiting to be sent
var panelOpen=false,listening=null;
var locked=function(){return document.pointerLockElement===cv;};
var cv=$('cv');

function getPad(){
 var l=navigator.getGamepads?navigator.getGamepads():[];
 for(var i=0;i<l.length;i++){if(l[i]&&l[i].connected)return l[i];}
 return null;
}
function btnDown(pad,i){var x=pad&&pad.buttons[i];return !!x&&(x.pressed||x.value>0.5);}
function bindDown(b,pad){
 var t=b.charAt(0),v=b.slice(2);
 if(t==='k')return !!keysDown[v];
 if(t==='m')return !!mouseDown[+v];
 if(t==='g')return btnDown(pad,+v);
 if(t==='a'){if(!pad)return false;var n=+v.slice(0,-1),s=v.slice(-1)==='-'?-1:1,a=pad.axes[n];return a!==undefined&&a*s>0.5;}
 return false;
}
function actDown(id,pad){var l=binds[id];for(var i=0;i<l.length;i++)if(bindDown(l[i],pad))return true;return false;}
function actIndex(id){for(var i=0;i<ACTIONS.length;i++)if(ACTIONS[i][0]===id)return i;return -1;}
function keyIsBound(code){var k='k:'+code;for(var id in binds)if(binds[id].indexOf(k)>=0)return true;return false;}

/* ---------- sending input to the CyberPi ---------- */
var inflight=false,sentAt=0,lastSend=0,lastMask=-1,lastTick=performance.now(),linkBadAt=0;
var prevNext=false,prevPrev=false,fireSince=-1;
function sendInput(mask,dx,n,p,now){
 inflight=true;sentAt=now;lastSend=now;lastMask=mask;
 var ac=(typeof AbortController!=='undefined')?new AbortController():null;
 var to=setTimeout(function(){if(ac)ac.abort();},900);
 fetch('/in?k='+(mask>>>0).toString(16)+'&x='+dx+'&n='+n+'&p='+p+'&a='+(cfg.sound?1:0)+'&v='+(cfg.screen?1:0),ac?{signal:ac.signal}:{})
  .then(function(){linkBadAt=0;})
  .catch(function(){linkBadAt=Date.now();})
  .then(function(){clearTimeout(to);inflight=false;});
}
var padSeen='';
function tick(){
 var now=performance.now(),dt=Math.min(0.1,(now-lastTick)/1000);lastTick=now;
 var pad=getPad();
 var pn=pad?pad.id.replace(/\(.*$/,'').slice(0,40):'';
 if(pn!==padSeen){padSeen=pn;$('pad').textContent=pn?('Controller: '+pn):'No controller';}

 if(listening){listenPad(pad);}

 var mask=0;
 if(!listening&&!panelOpen){
  for(var i=0;i<NBITS;i++){if(actDown(ACTIONS[i][0],pad))mask|=(1<<i);}
  // hold the mouse fire button => also USE
  var mf=false,fl=binds.fire;
  for(var j=0;j<fl.length;j++){if(fl[j].charAt(0)==='m'&&mouseDown[+fl[j].slice(2)])mf=true;}
  if(cfg.holdUse&&mf){if(fireSince<0)fireSince=now;else if(now-fireSince>=cfg.holdMs)mask|=(1<<7);}else fireSince=-1;
  // weapon next / previous (one step per press)
  var dn=actDown('wnext',pad),dp=actDown('wprev',pad);
  if(dn&&!prevNext)pend.n++;
  if(dp&&!prevPrev)pend.p++;
  prevNext=dn;prevPrev=dp;
  // analog turning with the right stick
  if(pad){
   var s=pad.axes[cfg.stickAxis];
   if(s!==undefined){
    var a=Math.abs(s);
    if(a>cfg.dead){a=(a-cfg.dead)/(1-cfg.dead);pend.dx+=(s<0?-1:1)*a*a*3000*cfg.stickSens*dt;}
   }
  }
  mask|=pulse;
 } else {pend.dx=0;pend.n=0;pend.p=0;}

 if(inflight&&now-sentAt>1100)inflight=false;
 var dxi=Math.round(pend.dx);
 if(!inflight&&(mask!==lastMask||dxi!==0||pend.n||pend.p||pulse||now-lastSend>250)){
  if(dxi>4000)dxi=4000;if(dxi<-4000)dxi=-4000;
  var n=Math.min(pend.n,7),p=Math.min(pend.p,7);
  sendInput(mask,dxi,n,p,now);
  pend.dx-=dxi;pend.n=0;pend.p=0;pulse=0;
 }
}
setInterval(tick,25);

/* ---------- keyboard, mouse, wheel ---------- */
window.addEventListener('keydown',function(e){
 if(listening){e.preventDefault();if(!e.repeat){addBind(listening.id,'k:'+e.code);stopListen();}return;}
 if(panelOpen){if(e.code==='Escape')closePanel();return;}
 keysDown[e.code]=true;
 if(keyIsBound(e.code)&&!/^F\d+$/.test(e.code))e.preventDefault();
});
window.addEventListener('keyup',function(e){delete keysDown[e.code];if(!panelOpen&&keyIsBound(e.code))e.preventDefault();});
function releaseAll(){keysDown={};mouseDown={};}
window.addEventListener('blur',releaseAll);
document.addEventListener('visibilitychange',function(){if(document.hidden)releaseAll();});

cv.addEventListener('mousedown',function(e){
 e.preventDefault();
 if(panelOpen)return;
 if(cfg.mouseLook&&!locked()){try{cv.requestPointerLock();}catch(x){}return;}
 mouseDown[e.button]=true;
});
window.addEventListener('mouseup',function(e){delete mouseDown[e.button];});
cv.addEventListener('contextmenu',function(e){e.preventDefault();});
document.addEventListener('mousemove',function(e){
 if(cfg.mouseLook&&locked()&&!panelOpen&&!listening)pend.dx+=e.movementX*cfg.mouseSens;
});
document.addEventListener('pointerlockchange',function(){
 $('bar').className=locked()?'locked':'';
 if(!locked())releaseAll();
 refreshHint();
});
window.addEventListener('wheel',function(e){
 if(listening){e.preventDefault();addBind(listening.id,'w:'+(e.deltaY>0?'d':'u'));stopListen();return;}
 if(panelOpen)return;
 e.preventDefault();
 var key='w:'+(e.deltaY>0?'d':'u');
 ACTIONS.forEach(function(a,i){
  if(binds[a[0]].indexOf(key)<0)return;
  if(a[0]==='wnext')pend.n++;else if(a[0]==='wprev')pend.p++;else if(i<NBITS)pulse|=(1<<i);
 });
},{passive:false});

/* ---------- rebinding ---------- */
function addBind(id,b){
 ACTIONS.forEach(function(a){var l=binds[a[0]],i=l.indexOf(b);if(i>=0)l.splice(i,1);});
 binds[id].push(b);save();renderBinds();
}
function startListen(id,name){
 listening={id:id,init:false,pressed:{},axis:{}};
 $('lmsg').textContent='"'+name+'": press a key, click a mouse button, scroll the wheel, press a controller button or push a stick';
 $('listen').className='on';
}
function stopListen(){listening=null;$('listen').className='';}
function listenPad(pad){
 if(!pad||!listening)return;
 var i,down;
 if(!listening.init){
  for(i=0;i<pad.buttons.length;i++)listening.pressed[i]=btnDown(pad,i);
  for(i=0;i<pad.axes.length;i++){listening.axis[i+'-']=pad.axes[i]<-0.7;listening.axis[i+'+']=pad.axes[i]>0.7;}
  listening.init=true;return;
 }
 for(i=0;i<pad.buttons.length;i++){
  down=btnDown(pad,i);
  if(down&&!listening.pressed[i]){addBind(listening.id,'g:'+i);stopListen();return;}
  listening.pressed[i]=down;
 }
 for(i=0;i<pad.axes.length;i++){
  var neg=pad.axes[i]<-0.7,pos=pad.axes[i]>0.7;
  if(neg&&!listening.axis[i+'-']){addBind(listening.id,'a:'+i+'-');stopListen();return;}
  if(pos&&!listening.axis[i+'+']){addBind(listening.id,'a:'+i+'+');stopListen();return;}
  listening.axis[i+'-']=neg;listening.axis[i+'+']=pos;
 }
}
$('listen').addEventListener('mousedown',function(e){
 if(e.target.id==='lcancel')return;
 if(listening){e.preventDefault();addBind(listening.id,'m:'+e.button);stopListen();}
});
$('listen').addEventListener('contextmenu',function(e){e.preventDefault();});
$('lcancel').addEventListener('click',stopListen);

function renderBinds(){
 var box=$('binds');box.textContent='';
 ACTIONS.forEach(function(a){
  var id=a[0],row=document.createElement('div');row.className='row';
  var nm=document.createElement('span');nm.className='nm';nm.textContent=a[1];row.appendChild(nm);
  var chips=document.createElement('span');chips.className='chips';
  binds[id].forEach(function(b){
   var c=document.createElement('button');c.className='chip';c.textContent=label(b)+'  \u2715';c.title='Click to remove';
   c.addEventListener('click',function(){binds[id]=binds[id].filter(function(x){return x!==b;});save();renderBinds();});
   chips.appendChild(c);
  });
  var add=document.createElement('button');add.textContent='+ Add';
  add.addEventListener('click',function(){startListen(id,a[1]);});
  chips.appendChild(add);row.appendChild(chips);box.appendChild(row);
 });
}

/* ---------- settings panel ---------- */
function syncUi(){
 $('cMouseLook').checked=cfg.mouseLook;
 $('cMouseSens').value=cfg.mouseSens;$('vMouseSens').textContent=cfg.mouseSens;
 $('cHoldUse').checked=cfg.holdUse;
 $('cHoldMs').value=cfg.holdMs;$('vHoldMs').textContent=cfg.holdMs+' ms';
 $('cStickAxis').value=String(cfg.stickAxis);
 $('cStickSens').value=cfg.stickSens;$('vStickSens').textContent=cfg.stickSens;
 $('cDead').value=cfg.dead;$('vDead').textContent=cfg.dead;
 $('cQual').value=String(cfg.quality);
 $('cAspect').checked=cfg.aspect;
 $('cSound').checked=cfg.sound;
 $('cScreen').checked=cfg.screen;
 document.body.className=cfg.aspect?'':'stretch';
}
function bindCfg(id,key,kind,after){
 $(id).addEventListener('input',function(){
  var v=$(id).value;
  if(kind==='bool')v=$(id).checked;else v=parseFloat(v);
  cfg[key]=v;save();syncUi();refreshHint();if(after)after();
 });
}
bindCfg('cMouseLook','mouseLook','bool',function(){if(!cfg.mouseLook&&locked())document.exitPointerLock();});
bindCfg('cMouseSens','mouseSens','num');
bindCfg('cHoldUse','holdUse','bool');
bindCfg('cHoldMs','holdMs','num');
bindCfg('cStickAxis','stickAxis','num');
bindCfg('cStickSens','stickSens','num');
bindCfg('cDead','dead','num');
bindCfg('cAspect','aspect','bool');
bindCfg('cSound','sound','bool');
bindCfg('cScreen','screen','bool');
bindCfg('cQual','quality','num',function(){startStream();});
function openPanel(){if(locked())document.exitPointerLock();releaseAll();panelOpen=true;$('panel').className='open';refreshHint();}
function closePanel(){panelOpen=false;$('panel').className='';refreshHint();}
$('bSet').addEventListener('click',openPanel);
$('bClose').addEventListener('click',closePanel);
$('bMenu').addEventListener('click',function(){pulse|=(1<<9);});
$('bFs').addEventListener('click',function(){var d=document.documentElement;if(d.requestFullscreen)d.requestFullscreen();});
$('bReset').addEventListener('click',function(){if(confirm('Reset all button mappings to the defaults?')){binds=cloneDef();save();renderBinds();}});
function refreshHint(){
 var h=$('hint');
 if(cfg.mouseLook&&!locked()&&!panelOpen){h.textContent='Click the game to capture the mouse (Esc lets go)';h.style.display='block';}
 else h.style.display='none';
}

/* ---------- video ---------- */
var ctx=cv.getContext('2d',{alpha:false});
var img=null,img32=null,imgW=0,imgH=0,pal32=new Uint32Array(256);
function ensureImg(w,h){
 if(imgW===w&&imgH===h)return;
 imgW=w;imgH=h;cv.width=w;cv.height=h;
 img=ctx.createImageData(w,h);img32=new Uint32Array(img.data.buffer);
}
var frames=0,lastFpsT=Date.now(),fps=0,streamMode=1,connected=false;
function drawFrame(buf,len,mode){
 var w=mode===3?80:(mode===2?160:320),h=mode===3?50:(mode===2?100:200);
 if(len!==768+w*h)return;
 ensureImg(w,h);
 for(var i=0;i<256;i++)pal32[i]=(0xFF000000|(buf[i*3+2]<<16)|(buf[i*3+1]<<8)|buf[i*3])>>>0;
 for(var k=0,p=768,n=w*h;k<n;k++)img32[k]=pal32[buf[p+k]];
 ctx.putImageData(img,0,0);
 frames++;streamMode=mode;
}
function setStatus(t){$('st').textContent=t;}
setInterval(function(){
 var now=Date.now();
 if(now-lastFpsT>=1000){fps=Math.round(frames*1000/(now-lastFpsT));frames=0;lastFpsT=now;
  if(connected){setStatus((linkBadAt&&now-linkBadAt<2000)?'Lost contact with the CyberPi':('Playing - '+fps+' fps ('+QN[streamMode]+')'));}}
},500);

var payBuf=new Uint8Array(768+320*200),streamGen=0,streamAbort=null;
function sleep(ms){return new Promise(function(r){setTimeout(r,ms);});}
function startStream(){
 streamGen++;var gen=streamGen;
 if(streamAbort)try{streamAbort.abort();}catch(e){}
 runStream(gen);
}
async function runStream(gen){
 while(gen===streamGen){
  var ac=new AbortController();streamAbort=ac;
  try{
   setStatus('Connecting to the CyberPi...');connected=false;
   var url='http://'+location.hostname+':81/stream?q='+cfg.quality+'&t='+Date.now();
   var resp=await fetch(url,{signal:ac.signal});
   if(!resp.ok||!resp.body)throw new Error('bad response');
   var reader=resp.body.getReader();
   var hdr=new Uint8Array(8),hdrGot=0,inPay=false,payLen=0,payGot=0,mode=1;
   connected=true;
   for(;;){
    var r=await reader.read();
    if(r.done)break;
    var v=r.value,p=0,n=v.length;
    while(p<n){
     if(!inPay){
      var t1=Math.min(8-hdrGot,n-p);hdr.set(v.subarray(p,p+t1),hdrGot);hdrGot+=t1;p+=t1;
      if(hdrGot===8){
       if(hdr[0]!==0xD0)throw new Error('bad stream header');
       mode=hdr[1];payLen=(hdr[4]|(hdr[5]<<8)|(hdr[6]<<16)|(hdr[7]<<24))>>>0;
       if(payLen>payBuf.length)throw new Error('frame too big');
       inPay=true;payGot=0;
      }
     } else {
      var t2=Math.min(payLen-payGot,n-p);payBuf.set(v.subarray(p,p+t2),payGot);payGot+=t2;p+=t2;
      if(payGot===payLen){drawFrame(payBuf,payLen,mode);inPay=false;hdrGot=0;}
     }
    }
   }
  }catch(e){}
  if(gen!==streamGen)return;
  connected=false;setStatus('Stream lost - retrying...');
  await sleep(1500);
 }
}

syncUi();renderBinds();refreshHint();startStream();
window.__cpdoom={drawFrame:drawFrame,tick:tick,binds:binds,cfg:cfg};
})();
</script></body></html>
)HTMLPAGE";
