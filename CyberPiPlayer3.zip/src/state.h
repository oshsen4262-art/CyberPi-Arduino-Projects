#pragma once
#include <Arduino.h>

struct Track { String name; uint32_t size; };

struct Status {
  bool     playing = false, paused = false, shuffleOn = false, stopped = true;
  int      curIdx = -1;     // index into tracks[] (flash) or ramTracks[] (RAM) — see curIsRam
  bool     curIsRam = false;
  uint32_t posBytes = 0, sizeBytes = 0;
  int      volume = 60;
  bool     screenOn = true;
  bool     audioReady = false;
};

enum CmdType { CMD_TOGGLE, CMD_NEXT, CMD_PREV, CMD_PLAY_INDEX, CMD_SHUFFLE, CMD_VOLUME, CMD_STOP, CMD_RESCAN };
struct Cmd { CmdType type; int arg; };
