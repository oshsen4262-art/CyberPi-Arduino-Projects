/*
 * CyberPi Player (MP3) v3
 * ------------------
 * - Upload MP3s from any browser over WiFi (press "+", then pick files)
 * - Files are stored in the CyberPi's flash (LittleFS)
 * - Plays through the built-in speaker (ESP32 DAC, same path Makeblock's library uses)
 *
 * Self-contained: Makeblock's display/button drivers and the MP3 decoder are bundled in the "src"
 * folder next to this file, so there are NO libraries to install.
 * Needs only: Arduino-ESP32 core 2.0.x (2.0.7 or 2.0.17). Core 3.x will not work.
 * Board:  ESP32 Dev Module, PSRAM: Enabled, partition scheme with the biggest SPIFFS
 *
 * v3 change: audio decoding now runs in its own FreeRTOS task on the other CPU core, and the
 * web server / buttons / screen run in a separate task that only ever reads small status flags
 * (never touches the decoder or the file directly). In v2 both jobs shared one loop, so a few
 * hundred milliseconds of MP3 decoding could delay the web server long enough that the page,
 * the skip buttons and the progress bar all appeared to freeze until the track changed.
 *
 * Controls on the device:
 *   Joystick press / A : play / pause
 *   Joystick left/right: previous / next
 *   Joystick up/down   : volume
 *   B                  : shuffle on/off
 *   Menu               : screen on/off (saves battery)
 */

#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <LittleFS.h>
#include <driver/i2s.h>
#include <esp_heap_caps.h>
#include "src/audio/AudioFileSource.h"
#include "src/audio/AudioGeneratorMP3.h"
#include "src/audio/AudioOutput.h"
#include <esp_system.h>
#include <functional>
extern "C" {
#include "src/cyberpi/i2c/i2c.h"
#include "src/cyberpi/io/aw9523b.h"
#include "src/cyberpi/lcd/lcd.h"
}
#include "src/state.h"

// ---------------- settings ----------------
#define WIFI_SSID  "Starlight"
#define WIFI_PASS  "YOUR_WIFI_PASSWORD"   // if this can't connect, the CyberPi starts its own WiFi instead
#define AP_SSID    "CyberPi-MP3"
#define AP_PASS    "cyberpi123"           // at least 8 characters
#define HOSTNAME   "cyberpi"              // http://cyberpi.local when on your WiFi
#define MAX_TRACKS 64

// ---------------- CyberPi pins (AW9523B expander) ----------------
#define JOY_UP     AW_P0_1
#define JOY_DOWN   AW_P0_4
#define JOY_RIGHT  AW_P0_2
#define JOY_LEFT   AW_P0_0
#define JOY_CENTER AW_P0_3
#define BTN_A      AW_P0_6
#define BTN_B      AW_P0_5
#define BTN_MENU   AW_P1_0
#define AMP_ENABLE AW_P1_3

// ---------------- crash tracking (survives restarts, not power-off) ----------------
RTC_NOINIT_ATTR uint32_t rtcMagic;
RTC_NOINIT_ATTR uint32_t rtcStage;
#define RTC_MAGIC 0xC0DEF00D
enum { ST_NONE = 0, ST_DISPLAY = 1, ST_STORAGE = 2, ST_AUDIO = 3, ST_WIFI = 4, ST_WEB = 5, ST_RUN = 6, ST_PLAY = 7 };
void setStage(uint32_t st) { rtcStage = st; rtcMagic = RTC_MAGIC; }
const char *stageName(uint32_t st) {
  switch (st) {
    case ST_DISPLAY: return "display init";
    case ST_STORAGE: return "storage";
    case ST_AUDIO:   return "audio init";
    case ST_WIFI:    return "WiFi start";
    case ST_WEB:     return "web server";
    case ST_RUN:     return "idle/running";
    case ST_PLAY:    return "playing";
    default:         return "unknown";
  }
}

// =====================================================================================
// Shared state between the two tasks. "dataMx" guards the track list and every LittleFS
// call. "statusMx" guards the small now-playing snapshot that the web/screen tasks poll.
// Neither is ever held during file I/O by the *reading* side, and the audio task always
// finishes closing its file (and reports stopped=true) before an upload or delete begins,
// so the two tasks never touch flash at the same moment.
// =====================================================================================
SemaphoreHandle_t dataMx;
SemaphoreHandle_t statusMx;
QueueHandle_t      cmdQueue;

Track tracks[MAX_TRACKS];
int   nTracks = 0;

// "Temporary" tracks: held in PSRAM only, never written to flash. They vanish on any restart —
// that's just what RAM is — which is exactly the point: play something once without using up
// the permanent library.
#define MAX_RAM_TRACKS 16
struct RamTrack { String name; uint8_t *data = nullptr; uint32_t size = 0; };
RamTrack ramTracks[MAX_RAM_TRACKS];
int      nRamTracks = 0;

Status status;

void sendCmd(CmdType t, int arg = 0) {
  Cmd c{t, arg};
  xQueueSend(cmdQueue, &c, 0);   // never block the caller; queue has room for a handful of commands
}

Status getStatus() {
  Status s;
  xSemaphoreTake(statusMx, portMAX_DELAY);
  s = status;
  xSemaphoreGive(statusMx);
  return s;
}

void updateStatus(const std::function<void(Status &)> &fn) {
  xSemaphoreTake(statusMx, portMAX_DELAY);
  fn(status);
  xSemaphoreGive(statusMx);
}

// ---- combined flash+RAM helpers -----------------------------------------------------
// Nothing persists a "flash rescan happened, so shift every RAM index" style position: the
// currently-playing track is always addressed as (idx, isRam), which a flash-side change can
// never invalidate. "pos" (a single number spanning flash-then-RAM) only ever exists transiently,
// computed fresh from the CURRENT track counts, for the web UI's list and for next/prev/shuffle.
int flashCountSafe() {
  xSemaphoreTake(dataMx, portMAX_DELAY);
  int n = nTracks;
  xSemaphoreGive(dataMx);
  return n;
}
int ramCountSafe() {
  xSemaphoreTake(dataMx, portMAX_DELAY);
  int n = nRamTracks;
  xSemaphoreGive(dataMx);
  return n;
}
int trackCountSafe() { return flashCountSafe() + ramCountSafe(); }

int posOf(int idx, bool ram) { return ram ? (flashCountSafe() + idx) : idx; }
void fromPos(int pos, int &idx, bool &ram) {
  int nf = flashCountSafe();
  if (pos < nf) { idx = pos; ram = false; }
  else { idx = pos - nf; ram = true; }
}

String trackName(int idx, bool ram) {
  String n;
  xSemaphoreTake(dataMx, portMAX_DELAY);
  if (ram) { if (idx >= 0 && idx < nRamTracks) n = ramTracks[idx].name; }
  else     { if (idx >= 0 && idx < nTracks)    n = tracks[idx].name; }
  xSemaphoreGive(dataMx);
  return n;
}

bool dirty = true;   // screen redraw hint, only touched by the UI task
String ipText = "";
int failStreak = 0;
uint16_t cWhite, cGrey, cBlue, cGreen, cOrange, cBg, cCard;

// ---------------- audio output: mono -> ESP32 DAC (right channel / GPIO25) ----------------
class CyberPiOutput : public AudioOutput {
 public:
  bool begin() { fill = 0; return true; }
  bool SetRate(int hz) {
    flushOut();
    if (getStatus().audioReady) i2s_set_sample_rates(I2S_NUM_0, hz);
    return true;
  }
  bool ConsumeSample(int16_t s[2]) {
    // If our staging buffer is full, flush it and tell the decoder "not consumed yet" instead
    // of accepting the sample. That makes AudioGeneratorMP3::loop() return control to the audio
    // task (which then checks for skip/pause/stop commands) roughly every ~500 samples, instead
    // of looping internally, non-stop, for the entire song.
    if (fill >= BUFN) { flushOut(); return false; }
    int vol = getStatus().volume;
    int32_t m = ((int32_t)s[0] + (int32_t)s[1]) / 2;
    m = (m * vol) / 100;
    uint16_t v = (uint16_t)(m + 32768);   // DAC wants unsigned, silence = mid-scale
    buf[fill++] = v;                      // left
    buf[fill++] = v;                      // right
    return true;
  }
  bool stop() { flushOut(); return true; }
  void flushOut() {
    if (!fill) return;
    if (!getStatus().audioReady) { fill = 0; return; }
    size_t w;
    i2s_write(I2S_NUM_0, buf, fill * 2, &w, pdMS_TO_TICKS(200));
    fill = 0;
  }
  void silence() {
    flushOut();
    if (!getStatus().audioReady) { delay(10); return; }
    uint16_t z[512];
    for (int i = 0; i < 512; i++) z[i] = 0x8000;
    size_t w;
    i2s_write(I2S_NUM_0, z, sizeof(z), &w, pdMS_TO_TICKS(200));
  }
 private:
  static const int BUFN = 1024;
  uint16_t buf[BUFN];
  int fill = 0;
};

// ---------------- audio input: a file in LittleFS (only ever opened by the audio task) ----------------
class LfsSource : public AudioFileSource {
 public:
  LfsSource(const char *path) { f = LittleFS.open(path, "r"); }
  ~LfsSource() { close(); }
  bool open(const char *path) { close(); f = LittleFS.open(path, "r"); return (bool)f; }
  uint32_t read(void *data, uint32_t len) { return f ? f.read((uint8_t *)data, len) : 0; }
  bool seek(int32_t pos, int dir) {
    if (!f) return false;
    SeekMode m = (dir == SEEK_SET) ? SeekSet : ((dir == SEEK_CUR) ? SeekCur : SeekEnd);
    return f.seek(pos, m);
  }
  bool close() { if (f) f.close(); return true; }
  bool isOpen() { return (bool)f; }
  uint32_t getSize() { return f ? f.size() : 0; }
  uint32_t getPos() { return f ? f.position() : 0; }
 private:
  File f;
};

// ---------------- audio input: a track held entirely in PSRAM (the "temporary" pool) ----------------
// Does NOT own the buffer — it's just reading it. ramTracks[] owns the memory and frees it when
// the track is deleted or the board restarts.
class RamSource : public AudioFileSource {
 public:
  RamSource(const uint8_t *d, uint32_t sz) : data(d), size(sz), pos(0) {}
  bool open(const char *) { return data && size; }
  uint32_t read(void *out, uint32_t len) {
    if (!data) return 0;
    if (pos + len > size) len = (pos < size) ? size - pos : 0;
    if (len) memcpy(out, data + pos, len);
    pos += len;
    return len;
  }
  bool seek(int32_t p, int dir) {
    int32_t np = (dir == SEEK_SET) ? p : (dir == SEEK_CUR) ? (int32_t)pos + p : (int32_t)size + p;
    if (np < 0 || (uint32_t)np > size) return false;
    pos = np;
    return true;
  }
  bool close() { return true; }
  bool isOpen() { return data && size; }
  uint32_t getSize() { return size; }
  uint32_t getPos() { return pos; }
 private:
  const uint8_t *data;
  uint32_t size, pos;
};

CyberPiOutput      out;
AudioGeneratorMP3  *mp3 = nullptr;
AudioFileSource    *src = nullptr;   // either an LfsSource (flash) or a RamSource (temporary)

// ---------------- web page ----------------
const char PAGE[] PROGMEM = R"HTML(<!doctype html><html><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1"><title>CyberPi Player</title>
<style>
:root{color-scheme:dark}
*{box-sizing:border-box}
body{font:16px system-ui,sans-serif;background:#0c0f2e;color:#fff;margin:0;padding:20px 18px 32px;max-width:480px;margin-inline:auto}
h1{font-size:30px;font-weight:800;margin:4px 0 18px;line-height:1.1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.topbar{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}
.iconbtn{background:none;border:0;color:#fff;width:38px;height:38px;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;flex:none}
.iconbtn:active{background:rgba(255,255,255,.12)}
.iconbtn svg{width:22px;height:22px}
.art{width:100%;aspect-ratio:1;max-width:280px;margin:6px auto 26px;border-radius:22px;background:linear-gradient(160deg,#2a2f5c,#181b3a);display:flex;align-items:center;justify-content:center;box-shadow:0 12px 30px rgba(0,0,0,.35)}
.art svg{width:38%;height:38%;opacity:.55}
.controls{display:flex;align-items:center;justify-content:center;gap:34px;margin-bottom:22px}
.skip{background:none;border:0;color:#fff;cursor:pointer;padding:6px}
.skip svg{width:34px;height:34px}
.skip:active{opacity:.6}
.play{width:82px;height:82px;border-radius:50%;border:0;cursor:pointer;background:linear-gradient(135deg,#6b7bff,#b262e8);display:flex;align-items:center;justify-content:center;box-shadow:0 8px 22px rgba(107,123,255,.45)}
.play:active{filter:brightness(1.15)}
.play svg{width:32px;height:32px;fill:#fff}
.bar{height:5px;background:#262a55;border-radius:3px;overflow:hidden;margin:0 4px 8px}
.bar i{display:block;height:100%;background:linear-gradient(90deg,#6b7bff,#b262e8);width:0%;transition:width .25s linear}
.subrow{display:flex;justify-content:space-between;color:#8a8fbd;font-size:13px;margin:0 4px 22px}
.card{background:#161a3f;border-radius:16px;padding:14px 16px;margin-bottom:14px}
.card h2{font-size:13px;color:#8a8fbd;margin:0 0 10px;font-weight:600;letter-spacing:.03em;text-transform:uppercase}
.vol{display:flex;align-items:center;gap:10px}
input[type=range]{flex:1;accent-color:#8b6bff}
.row{display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid #23274f}
.row:last-child{border:0}
.rowicon{width:30px;height:30px;border-radius:8px;background:#20244c;display:flex;align-items:center;justify-content:center;flex:none}
.rowicon svg{width:15px;height:15px;opacity:.5}
.name{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14px}
.sm{color:#8a8fbd;font-size:12px}
.row.on .name{color:#a9b3ff}
.row button{background:none;border:0;color:#8a8fbd;cursor:pointer;padding:6px;flex:none}
.row button svg{width:16px;height:16px}
.empty{color:#8a8fbd;font-size:14px;padding:6px 0}
.overlay{position:fixed;inset:0;background:rgba(5,6,20,.72);display:none;align-items:flex-end;justify-content:center;z-index:10}
.overlay.show{display:flex}
.sheet{background:#161a3f;width:100%;max-width:480px;border-radius:20px 20px 0 0;padding:20px 18px 28px}
.sheet h3{margin:0 0 14px;font-size:16px}
.sheet button.big{width:100%;padding:13px;border-radius:12px;border:0;background:#20244c;color:#fff;font-size:15px;margin-bottom:10px;cursor:pointer}
.sheet button.big.accent{background:linear-gradient(135deg,#6b7bff,#b262e8)}
.sheet button.big.danger{background:#3a1f2e;color:#ff8fae}
.upitem{margin-bottom:12px}
.upitem .name{font-size:13px}
.upitem .stats{color:#8a8fbd;font-size:12px;margin-top:3px}
.segrow{display:flex;background:#20244c;border-radius:12px;padding:4px;margin-bottom:14px}
.segrow button{flex:1;border:0;background:none;color:#8a8fbd;padding:10px 6px;border-radius:9px;font-size:13px;cursor:pointer;text-align:center}
.segrow button.sel{background:linear-gradient(135deg,#6b7bff,#b262e8);color:#fff}
.seghint{color:#8a8fbd;font-size:12px;margin:-8px 0 14px;line-height:1.4}
.badge{font-size:10px;color:#b8a2ff;background:#2a2354;border-radius:6px;padding:2px 6px;flex:none;margin-right:2px}
.ramline{color:#8a8fbd;font-size:12px;margin-top:10px}
</style></head><body>
<div class=topbar>
 <h1 id=title>CyberPi Player</h1>
 <div style="display:flex;gap:2px">
  <button class=iconbtn onclick="openAdd()" title="Add music">
   <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
  </button>
  <button class=iconbtn onclick="openMenu()" title="Menu">
   <svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
  </button>
 </div>
</div>

<div class=art>
 <svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 18V6l11-2v12"/><circle cx="6" cy="18" r="3" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="17" cy="16" r="3" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>
</div>

<div class=controls>
 <button class=skip onclick="a('prev')"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 5h2v14H6zM20 5v14L9 12z"/></svg></button>
 <button class=play id=pp onclick="a('toggle')"><svg id=ppicon viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg></button>
 <button class=skip onclick="a('next')"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M18 5h-2v14h2zM4 5v14l11-7z"/></svg></button>
</div>

<div class=bar><i id=bar></i></div>
<div class=subrow><span id=sub>Nothing selected</span><span id=cnt></span></div>

<div class=card>
 <h2>Volume</h2>
 <div class=vol>
  <svg width=18 height=18 viewBox="0 0 24 24" fill="#8a8fbd"><path d="M3 10v4h4l5 5V5L7 10H3z"/></svg>
  <input type=range id=vol min=0 max=100 oninput="vv(this.value)">
  <span class=sm id=vl>60</span>
 </div>
</div>

<div class=card id=libCard style="display:none">
 <h2>Library</h2>
 <div id=list></div>
</div>

<!-- Add sheet -->
<div class=overlay id=addOverlay onclick="if(event.target===this)closeAdd()">
 <div class=sheet>
  <h3>Add music</h3>
  <div class=segrow>
   <button id=locFlash class=sel onclick="setLoc('flash')">Save permanently</button>
   <button id=locRam onclick="setLoc('ram')">Play now, don't save</button>
  </div>
  <div class=seghint id=locHint>Stored in flash. Stays after a restart, counts against your permanent library space.</div>
  <button class="big accent" onclick="document.getElementById('f').click()">Choose MP3 files</button>
  <input id=f type=file accept=".mp3,audio/mpeg" multiple hidden>
  <div id=upList></div>
  <div class=ramline id=ramLine></div>
  <button class=big onclick="closeAdd()">Close</button>
 </div>
</div>

<!-- Menu sheet -->
<div class=overlay id=menuOverlay onclick="if(event.target===this)closeMenu()">
 <div class=sheet>
  <h3>Menu</h3>
  <button class=big onclick="toggleLib()">Show library</button>
  <button class=big onclick="a('shuffle');closeMenu()" id=shBtn>Shuffle: off</button>
  <button class="big danger" onclick="delCur()">Delete current track</button>
  <button class=big onclick="closeMenu()">Close</button>
 </div>
</div>

<script>
const $=id=>document.getElementById(id);let S={files:[]},busy=0,addLoc='flash';
async function call(u){try{const r=await fetch(u,{method:'POST'});S=await r.json();draw()}catch(e){}}
const a=p=>call('/api/'+p);
const play=i=>call('/api/play?i='+i);
function delCur(){
 if(S.cur<0||!S.files[S.cur])return;
 const n=S.files[S.cur].n;
 if(confirm('Delete '+n+'?')){call('/api/delete?i='+S.cur);closeMenu()}
}
function del(i,n){if(confirm('Delete '+n+'?'))call('/api/delete?i='+i)}
let vt;function vv(v){$('vl').textContent=v;clearTimeout(vt);vt=setTimeout(()=>call('/api/vol?v='+v),150)}
const mb=b=>(b/1048576).toFixed(1)+' MB';
function openAdd(){$('addOverlay').classList.add('show')}
function closeAdd(){$('addOverlay').classList.remove('show')}
function openMenu(){$('menuOverlay').classList.add('show')}
function closeMenu(){$('menuOverlay').classList.remove('show')}
function toggleLib(){const c=$('libCard');c.style.display=c.style.display==='none'?'block':'none';closeMenu()}
function setLoc(loc){
 addLoc=loc;
 $('locFlash').className=loc==='flash'?'sel':'';
 $('locRam').className=loc==='ram'?'sel':'';
 $('locHint').textContent=loc==='flash'
  ?'Stored in flash. Stays after a restart, counts against your permanent library space.'
  :'Held in RAM only \u2014 plays right away but disappears the moment the CyberPi restarts or loses power. Doesn\u2019t touch your permanent library.';
}

function draw(){
 const f=S.files||[];
 const cur=(S.cur>=0&&f[S.cur])?f[S.cur]:null;
 $('title').textContent=cur?cur.n.replace(/\\.mp3$/i,''):'CyberPi Player';
 $('ppicon').innerHTML=(S.playing&&!S.paused)
  ?'<path d="M7 5h4v14H7zM13 5h4v14h-4z"/>'
  :'<path d="M8 5v14l11-7z"/>';
 $('sub').textContent=!cur?'Nothing selected':(!S.playing?'Stopped':(S.paused?'Paused':'Playing'))+(cur&&cur.loc==='ram'?' \u2022 temporary':'');
 $('cnt').textContent=f.length?((S.cur>=0?S.cur+1:0)+' / '+f.length):'';
 $('shBtn').textContent='Shuffle: '+(S.shuffle?'on':'off');
 if(document.activeElement!==$('vol')){$('vol').value=S.vol;$('vl').textContent=S.vol}
 $('bar').style.width=(S.size?100*S.pos/S.size:0)+'%';
 if(S.ramTotal)$('ramLine').textContent='Temporary (RAM): '+mb(S.ramUsed)+' used of '+mb(S.ramTotal)+' \u2014 cleared on restart';
 const l=$('list');l.textContent='';
 if(!f.length){const e=document.createElement('div');e.className='empty';e.textContent='No tracks yet. Press + to add some.';l.append(e)}
 f.forEach((t,i)=>{
  const r=document.createElement('div');r.className='row'+(i===S.cur?' on':'');
  const ic=document.createElement('div');ic.className='rowicon';
  ic.innerHTML='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 18V6l11-2v12"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg>';
  const n=document.createElement('div');n.className='name';n.textContent=t.n.replace(/\\.mp3$/i,'');
  if(t.loc==='ram'){const bd=document.createElement('span');bd.className='badge';bd.textContent='TEMP';r.append(ic,bd)}
  else r.append(ic);
  const s=document.createElement('span');s.className='sm';s.textContent=mb(t.s);
  const b=document.createElement('button');b.innerHTML='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>';b.onclick=()=>play(i);
  const d=document.createElement('button');d.innerHTML='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2"/></svg>';d.onclick=()=>del(i,t.n);
  r.append(n,s,b,d);l.append(r)})
}

function fmtSpeed(bps){
 if(bps>1048576)return (bps/1048576).toFixed(1)+' MB/s';
 return (bps/1024).toFixed(0)+' KB/s';
}
function send(file,rowEl){return new Promise(res=>{
 const x=new XMLHttpRequest();x.open('POST','/upload?loc='+addLoc);
 const t0=Date.now();let lastT=t0,lastL=0;
 x.upload.onprogress=e=>{
  if(!e.lengthComputable)return;
  const now=Date.now();
  const dt=(now-lastT)/1000;
  const speed=dt>0.15?(e.loaded-lastL)/dt:0;
  if(dt>0.15){lastT=now;lastL=e.loaded}
  rowEl.querySelector('.stats').textContent=mb(e.loaded)+' / '+mb(e.total)+(speed?' \u2022 '+fmtSpeed(speed):'');
 };
 x.onload=()=>res(x.responseText||(x.status==200?'ok':'failed'));x.onerror=()=>res('failed');
 const fd=new FormData();fd.append('f',file,file.name);x.send(fd)})}
const FAIL_MSG={
 notmp3:'Not a valid mp3 file',
 nospace:'Not enough space \u2014 try the other storage option or delete something first',
 ramfull:'Temporary (RAM) library is full \u2014 delete a temporary track first',
 busy:'Player was busy, try again in a moment',
 ioerror:'Storage error on the device',
 failed:'Upload failed'
};
async function upl(files){
 busy=1;
 const box=$('upList');box.textContent='';
 for(const f of files){
  const item=document.createElement('div');item.className='upitem';
  item.innerHTML='<div class=name>'+f.name+'</div><div class=stats>Starting\u2026</div>';
  box.append(item);
  const reason=await send(f,item);
  item.querySelector('.stats').textContent=reason==='ok'?'Done':(FAIL_MSG[reason]||FAIL_MSG.failed);
 }
 busy=0;await refresh()}
async function refresh(){if(busy)return;try{const r=await fetch('/api/status');S=await r.json();draw()}catch(e){}}
$('f').onchange=e=>{if(e.target.files.length)upl(e.target.files)};
refresh();setInterval(refresh,600);
</script></body></html>)HTML";

// ---------------- helpers (track list; always under dataMx) ----------------
String sanitize(String n) {
  int s = max(n.lastIndexOf('/'), n.lastIndexOf('\\'));
  if (s >= 0) n = n.substring(s + 1);
  if (n.length() > 4 && n.substring(n.length() - 4).equalsIgnoreCase(".mp3")) n = n.substring(0, n.length() - 4);
  String o;
  for (unsigned i = 0; i < n.length() && o.length() < 24; i++) {
    char c = n[i];
    o += (isalnum((unsigned char)c) || c == '-' || c == '_') ? c : '_';
  }
  if (!o.length()) o = "track";
  return o + ".mp3";
}

void scanTracks() {
  xSemaphoreTake(dataMx, portMAX_DELAY);
  Status stSnap = status;
  String keep = (!stSnap.curIsRam && stSnap.curIdx >= 0 && stSnap.curIdx < nTracks) ? tracks[stSnap.curIdx].name : String("");
  nTracks = 0;
  File root = LittleFS.open("/");
  File f = root.openNextFile();
  while (f && nTracks < MAX_TRACKS) {
    String n = f.name();
    if (n.startsWith("/")) n = n.substring(1);
    if (!f.isDirectory() && n.endsWith(".mp3")) {
      tracks[nTracks].name = n;
      tracks[nTracks].size = f.size();
      nTracks++;
    }
    f = root.openNextFile();
  }
  for (int i = 0; i < nTracks; i++)
    for (int j = i + 1; j < nTracks; j++)
      if (tracks[j].name < tracks[i].name) { Track t = tracks[i]; tracks[i] = tracks[j]; tracks[j] = t; }
  int newIdx = -1;
  if (keep.length()) for (int i = 0; i < nTracks; i++) if (tracks[i].name == keep) newIdx = i;
  xSemaphoreGive(dataMx);
  // A flash rescan never touches a currently-playing RAM track's position — only re-anchor
  // when the thing we were tracking was itself on the flash side.
  if (!stSnap.curIsRam) updateStatus([newIdx](Status &s) { s.curIdx = newIdx; });
}

// Ask the audio task to stop and wait until it confirms the file/buffer is released.
// Used before any upload or delete so the two tasks never touch the same data at once.
bool stopAndWait(uint32_t timeoutMs = 1500) {
  sendCmd(CMD_STOP);
  uint32_t t0 = millis();
  while (millis() - t0 < timeoutMs) {
    if (getStatus().stopped) return true;
    delay(10);
  }
  return false;
}

// =====================================================================================
// AUDIO TASK  (its own core; owns mp3/src; the only thing that ever touches file/RAM playback)
// =====================================================================================
void stopTrackAudio() {
  if (mp3) { if (mp3->isRunning()) mp3->stop(); delete mp3; mp3 = nullptr; }
  if (src) { delete src; src = nullptr; }
  updateStatus([](Status &s) { s.playing = false; s.paused = false; s.stopped = true; });
  dirty = true;
}

bool startTrackAudio(int idx, bool ram) {
  stopTrackAudio();
  if (!getStatus().audioReady) return false;
  if (ram) {
    xSemaphoreTake(dataMx, portMAX_DELAY);
    bool ok = (idx >= 0 && idx < nRamTracks && ramTracks[idx].data);
    const uint8_t *d = ok ? ramTracks[idx].data : nullptr;
    uint32_t sz = ok ? ramTracks[idx].size : 0;
    xSemaphoreGive(dataMx);
    if (!ok) return false;
    src = new RamSource(d, sz);
  } else {
    String name = trackName(idx, false);
    if (!name.length()) return false;
    src = new LfsSource(("/" + name).c_str());
  }
  mp3 = new AudioGeneratorMP3();
  if (!src->isOpen() || !mp3->begin(src, &out)) { stopTrackAudio(); return false; }
  updateStatus([idx, ram](Status &s) { s.curIdx = idx; s.curIsRam = ram; s.playing = true; s.paused = false; s.stopped = false; });
  setStage(ST_PLAY);
  dirty = true;
  return true;
}

void playNextAudio(int dir) {
  int n = trackCountSafe();
  if (!n) return;
  Status st = getStatus();
  int curPos = (st.curIdx < 0) ? -1 : posOf(st.curIdx, st.curIsRam);
  int nextPos;
  if (st.shuffleOn && n > 1) { do { nextPos = random(n); } while (nextPos == curPos); }
  else nextPos = (curPos < 0) ? 0 : (curPos + dir + n) % n;
  int idx; bool ram;
  fromPos(nextPos, idx, ram);
  startTrackAudio(idx, ram);
}

void togglePlayAudio() {
  Status st = getStatus();
  failStreak = 0;
  if (!st.playing) {
    int n = trackCountSafe();
    if (n) {
      if (st.curIdx >= 0) startTrackAudio(st.curIdx, st.curIsRam);
      else { int idx; bool ram; fromPos(0, idx, ram); startTrackAudio(idx, ram); }
    }
  } else updateStatus([](Status &s) { s.paused = !s.paused; });
  dirty = true;
}

void audioTask(void *param) {
  uint32_t startedAt = 0;
  for (;;) {
    // drain any pending commands (non-blocking)
    Cmd c;
    while (xQueueReceive(cmdQueue, &c, 0) == pdTRUE) {
      switch (c.type) {
        case CMD_TOGGLE: togglePlayAudio(); startedAt = millis(); break;
        case CMD_NEXT:   failStreak = 0; playNextAudio(1); startedAt = millis(); break;
        case CMD_PREV:   failStreak = 0; playNextAudio(-1); startedAt = millis(); break;
        case CMD_PLAY_INDEX: {
          failStreak = 0;
          bool ram = c.arg & 0x10000;
          startTrackAudio(c.arg & 0xFFFF, ram);
          startedAt = millis();
          break;
        }
        case CMD_SHUFFLE: updateStatus([](Status &s) { s.shuffleOn = !s.shuffleOn; }); dirty = true; break;
        case CMD_VOLUME:  updateStatus([c](Status &s) { s.volume = c.arg; }); dirty = true; break;
        case CMD_STOP:    stopTrackAudio(); break;
        case CMD_RESCAN:  scanTracks(); break;
      }
    }

    Status st = getStatus();
    if (st.playing && !st.paused && mp3) {
      if (!mp3->loop()) {
        bool bad = (millis() - startedAt) < 1500;
        stopTrackAudio();
        failStreak = bad ? failStreak + 1 : 0;
        if (failStreak < trackCountSafe()) { playNextAudio(1); startedAt = millis(); }
      } else if (src) {
        updateStatus([&](Status &s) { s.posBytes = src->getPos(); s.sizeBytes = src->getSize(); });
      }
    } else {
      out.silence();
      vTaskDelay(pdMS_TO_TICKS(5));   // idle: don't spin the core
    }
  }
}

// ---------------- screen ----------------
// Own 5x7 font (public domain "classic" GFX font), drawn straight into the CyberPi framebuffer.
static const uint8_t FONT5X7[95][5] = {
  {0x00,0x00,0x00,0x00,0x00}, // ' '
  {0x00,0x00,0x5F,0x00,0x00}, // '!'
  {0x00,0x07,0x00,0x07,0x00}, // '"'
  {0x14,0x7F,0x14,0x7F,0x14}, // '#'
  {0x24,0x2A,0x7F,0x2A,0x12}, // '$'
  {0x23,0x13,0x08,0x64,0x62}, // '%'
  {0x36,0x49,0x56,0x20,0x50}, // '&'
  {0x00,0x08,0x07,0x03,0x00}, // '\''
  {0x00,0x1C,0x22,0x41,0x00}, // '('
  {0x00,0x41,0x22,0x1C,0x00}, // ')'
  {0x2A,0x1C,0x7F,0x1C,0x2A}, // '*'
  {0x08,0x08,0x3E,0x08,0x08}, // '+'
  {0x00,0x80,0x70,0x30,0x00}, // ','
  {0x08,0x08,0x08,0x08,0x08}, // '-'
  {0x00,0x00,0x60,0x60,0x00}, // '.'
  {0x20,0x10,0x08,0x04,0x02}, // '/'
  {0x3E,0x51,0x49,0x45,0x3E}, // '0'
  {0x00,0x42,0x7F,0x40,0x00}, // '1'
  {0x72,0x49,0x49,0x49,0x46}, // '2'
  {0x21,0x41,0x49,0x4D,0x33}, // '3'
  {0x18,0x14,0x12,0x7F,0x10}, // '4'
  {0x27,0x45,0x45,0x45,0x39}, // '5'
  {0x3C,0x4A,0x49,0x49,0x31}, // '6'
  {0x41,0x21,0x11,0x09,0x07}, // '7'
  {0x36,0x49,0x49,0x49,0x36}, // '8'
  {0x46,0x49,0x49,0x29,0x1E}, // '9'
  {0x00,0x00,0x14,0x00,0x00}, // ':'
  {0x00,0x40,0x34,0x00,0x00}, // ';'
  {0x00,0x08,0x14,0x22,0x41}, // '<'
  {0x14,0x14,0x14,0x14,0x14}, // '='
  {0x00,0x41,0x22,0x14,0x08}, // '>'
  {0x02,0x01,0x59,0x09,0x06}, // '?'
  {0x3E,0x41,0x5D,0x59,0x4E}, // '@'
  {0x7C,0x12,0x11,0x12,0x7C}, // 'A'
  {0x7F,0x49,0x49,0x49,0x36}, // 'B'
  {0x3E,0x41,0x41,0x41,0x22}, // 'C'
  {0x7F,0x41,0x41,0x41,0x3E}, // 'D'
  {0x7F,0x49,0x49,0x49,0x41}, // 'E'
  {0x7F,0x09,0x09,0x09,0x01}, // 'F'
  {0x3E,0x41,0x41,0x51,0x73}, // 'G'
  {0x7F,0x08,0x08,0x08,0x7F}, // 'H'
  {0x00,0x41,0x7F,0x41,0x00}, // 'I'
  {0x20,0x40,0x41,0x3F,0x01}, // 'J'
  {0x7F,0x08,0x14,0x22,0x41}, // 'K'
  {0x7F,0x40,0x40,0x40,0x40}, // 'L'
  {0x7F,0x02,0x1C,0x02,0x7F}, // 'M'
  {0x7F,0x04,0x08,0x10,0x7F}, // 'N'
  {0x3E,0x41,0x41,0x41,0x3E}, // 'O'
  {0x7F,0x09,0x09,0x09,0x06}, // 'P'
  {0x3E,0x41,0x51,0x21,0x5E}, // 'Q'
  {0x7F,0x09,0x19,0x29,0x46}, // 'R'
  {0x26,0x49,0x49,0x49,0x32}, // 'S'
  {0x03,0x01,0x7F,0x01,0x03}, // 'T'
  {0x3F,0x40,0x40,0x40,0x3F}, // 'U'
  {0x1F,0x20,0x40,0x20,0x1F}, // 'V'
  {0x3F,0x40,0x38,0x40,0x3F}, // 'W'
  {0x63,0x14,0x08,0x14,0x63}, // 'X'
  {0x03,0x04,0x78,0x04,0x03}, // 'Y'
  {0x61,0x59,0x49,0x4D,0x43}, // 'Z'
  {0x00,0x7F,0x41,0x41,0x41}, // '['
  {0x02,0x04,0x08,0x10,0x20}, // '\\'
  {0x00,0x41,0x41,0x41,0x7F}, // ']'
  {0x04,0x02,0x01,0x02,0x04}, // '^'
  {0x40,0x40,0x40,0x40,0x40}, // '_'
  {0x00,0x03,0x07,0x08,0x00}, // '`'
  {0x20,0x54,0x54,0x78,0x40}, // 'a'
  {0x7F,0x28,0x44,0x44,0x38}, // 'b'
  {0x38,0x44,0x44,0x44,0x28}, // 'c'
  {0x38,0x44,0x44,0x28,0x7F}, // 'd'
  {0x38,0x54,0x54,0x54,0x18}, // 'e'
  {0x00,0x08,0x7E,0x09,0x02}, // 'f'
  {0x18,0xA4,0xA4,0x9C,0x78}, // 'g'
  {0x7F,0x08,0x04,0x04,0x78}, // 'h'
  {0x00,0x44,0x7D,0x40,0x00}, // 'i'
  {0x20,0x40,0x40,0x3D,0x00}, // 'j'
  {0x7F,0x10,0x28,0x44,0x00}, // 'k'
  {0x00,0x41,0x7F,0x40,0x00}, // 'l'
  {0x7C,0x04,0x78,0x04,0x78}, // 'm'
  {0x7C,0x08,0x04,0x04,0x78}, // 'n'
  {0x38,0x44,0x44,0x44,0x38}, // 'o'
  {0xFC,0x18,0x24,0x24,0x18}, // 'p'
  {0x18,0x24,0x24,0x18,0xFC}, // 'q'
  {0x7C,0x08,0x04,0x04,0x08}, // 'r'
  {0x48,0x54,0x54,0x54,0x24}, // 's'
  {0x04,0x04,0x3F,0x44,0x24}, // 't'
  {0x3C,0x40,0x40,0x20,0x7C}, // 'u'
  {0x1C,0x20,0x40,0x20,0x1C}, // 'v'
  {0x3C,0x40,0x30,0x40,0x3C}, // 'w'
  {0x44,0x28,0x10,0x28,0x44}, // 'x'
  {0x4C,0x90,0x90,0x90,0x7C}, // 'y'
  {0x44,0x64,0x54,0x4C,0x44}, // 'z'
  {0x00,0x08,0x36,0x41,0x00}, // '{'
  {0x00,0x00,0x77,0x00,0x00}, // '|'
  {0x00,0x41,0x36,0x08,0x00}, // '}'
  {0x02,0x01,0x02,0x04,0x02}, // '~'
};

static uint16_t fb[128 * 128];                       // our own framebuffer (internal RAM)
void clearFb(uint16_t c = 0) { for (int i = 0; i < 128 * 128; i++) fb[i] = c; }
void present() { lcd_draw(fb, 128, 128); }           // sends the frame to the display (~15 ms)

void px(int x, int y, uint16_t c) {
  if (x >= 0 && x < 128 && y >= 0 && y < 128) fb[y * 128 + x] = c;
}

void rect(int x, int y, int w, int h, uint16_t c) {
  for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) px(x + i, y + j, c);
}

int textWidth(const String &s, int scale) { return (int)s.length() * 6 * scale; }

void drawStrClip(int x, int y, const String &s, int scale, uint16_t color, int clipL, int clipR) {
  for (unsigned i = 0; i < s.length(); i++) {
    int ch = (unsigned char)s[i];
    if (ch < 32 || ch > 126) ch = '?';
    int gx = x + (int)i * 6 * scale;
    if (gx + 5 * scale <= clipL || gx >= clipR) continue;
    const uint8_t *g = FONT5X7[ch - 32];
    for (int c = 0; c < 5; c++) {
      for (int r = 0; r < 7; r++) {
        if (!((g[c] >> r) & 1)) continue;
        for (int dy = 0; dy < scale; dy++)
          for (int dx = 0; dx < scale; dx++) {
            int X = gx + c * scale + dx;
            if (X >= clipL && X < clipR) px(X, y + r * scale + dy, color);
          }
      }
    }
  }
}

void drawStr(int x, int y, const String &s, int scale, uint16_t color) {
  drawStrClip(x, y, s, scale, color, 0, 128);
}

void splash(const String &a, const String &b, const String &c) {
  clearFb(cBg);
  drawStr(4, 12, a, a.length() <= 10 ? 2 : 1, cWhite);
  drawStr(4, 40, b, 1, cBlue);
  drawStr(4, 56, c, 1, cGrey);
  present();
}

void updateScreen() {
  static uint32_t last = 0;
  Status st = getStatus();
  if (!st.screenOn) return;

  String name = (st.curIdx >= 0) ? trackName(st.curIdx, st.curIsRam) : String("(no track)");
  name.replace(".mp3", "");
  int w = textWidth(name, 2);
  bool scrolling = st.playing && !st.paused && w > 120;

  if (!dirty && millis() - last < (scrolling ? 100UL : 400UL)) return;
  last = millis(); dirty = false;

  int n = trackCountSafe();
  int pos = (st.curIdx >= 0) ? posOf(st.curIdx, st.curIsRam) : -1;
  String stTxt = !st.playing ? "STOPPED" : (st.paused ? "PAUSED" : "PLAYING");
  stTxt += " " + String(n && pos >= 0 ? pos + 1 : 0) + "/" + String(n);
  if (st.curIsRam) stTxt += " TEMP";
  if (st.shuffleOn) stTxt += " SHUF";

  clearFb(cBg);
  drawStr(4, 3, "CyberPi Player", 1, cGrey);
  if (scrolling) {
    int period = w + 30;
    int off = (int)((millis() / 45) % period);
    drawStrClip(4 - off, 16, name, 2, cWhite, 4, 124);
    drawStrClip(4 - off + period, 16, name, 2, cWhite, 4, 124);
  } else {
    drawStrClip(4, 16, name, 2, cWhite, 4, 124);
  }
  drawStr(4, 38, stTxt, 1, st.playing && !st.paused ? cGreen : cOrange);
  rect(4, 52, 120, 6, cGrey);
  if (st.sizeBytes) rect(4, 52, (int)(120ULL * st.posBytes / st.sizeBytes), 6, cBlue);
  drawStr(4, 66, "VOL " + String(st.volume), 1, cWhite);
  rect(4, 78, 120, 4, cGrey);
  rect(4, 78, 120 * st.volume / 100, 4, cGreen);
  drawStr(4, 94, ipText, 1, cBlue);
  drawStr(4, 106, "A:play  L/R:skip", 1, cGrey);
  drawStr(4, 117, "U/D:vol  B:shuffle", 1, cGrey);
  present();
}

// ---------------- device buttons (UI task) ----------------
static bool pc = false, pa = false, pb = false, pm = false;
static int pjx = 0;

// One I2C read of both input ports; a pressed button reads as 0.
static bool readPad(bool &c, bool &a, bool &b, bool &m, int &jx, int &jy) {
  uint16_t g = aw_get_gpio();
  if ((g & 0x007F) == 0) return false;               // all controls "pressed" at once = failed read, ignore
  auto down = [&](int pin) { return ((g >> pin) & 1) == 0; };
  c = down(JOY_CENTER); a = down(BTN_A); b = down(BTN_B); m = down(BTN_MENU);
  jx = down(JOY_RIGHT) ? 1 : (down(JOY_LEFT) ? -1 : 0);
  jy = down(JOY_DOWN) ? 1 : (down(JOY_UP) ? -1 : 0);
  return true;
}

void primeButtons() {
  bool c, a, b, m; int jx, jy;
  if (readPad(c, a, b, m, jx, jy)) { pc = c; pa = a; pb = b; pm = m; pjx = jx; }
}

void handleInput() {
  static uint32_t lastVol = 0;
  bool c, a, b, m; int jx, jy;
  if (!readPad(c, a, b, m, jx, jy)) return;

  if ((c && !pc) || (a && !pa)) sendCmd(CMD_TOGGLE);
  if (jx != pjx) {
    if (jx > 0) sendCmd(CMD_NEXT);
    if (jx < 0) sendCmd(CMD_PREV);
  }
  if (b && !pb) sendCmd(CMD_SHUFFLE);
  if (m && !pm) {
    bool nowOn = !getStatus().screenOn;
    updateStatus([nowOn](Status &s) { s.screenOn = nowOn; });
    if (nowOn) lcd_on(); else lcd_off();
    dirty = true;
  }
  if (jy != 0 && millis() - lastVol > 120) {
    int nv = constrain(getStatus().volume - jy * 5, 0, 100);
    updateStatus([nv](Status &s) { s.volume = nv; });
    lastVol = millis();
    dirty = true;
  }
  pc = c; pa = a; pb = b; pm = m; pjx = jx;
}

// ---------------- web API (UI task) ----------------
WebServer server(80);

void sendStatusJson() {
  Status st = getStatus();
  int pos = (st.curIdx >= 0) ? posOf(st.curIdx, st.curIsRam) : -1;
  String j = "{\"files\":[";
  xSemaphoreTake(dataMx, portMAX_DELAY);
  bool first = true;
  for (int i = 0; i < nTracks; i++) {
    if (!first) j += ","; first = false;
    j += "{\"n\":\"" + tracks[i].name + "\",\"s\":" + String((unsigned long)tracks[i].size) + ",\"loc\":\"flash\"}";
  }
  for (int i = 0; i < nRamTracks; i++) {
    if (!first) j += ","; first = false;
    j += "{\"n\":\"" + ramTracks[i].name + "\",\"s\":" + String((unsigned long)ramTracks[i].size) + ",\"loc\":\"ram\"}";
  }
  xSemaphoreGive(dataMx);
  j += "],\"cur\":" + String(pos);
  j += String(",\"playing\":") + (st.playing ? "true" : "false");
  j += String(",\"paused\":") + (st.paused ? "true" : "false");
  j += String(",\"shuffle\":") + (st.shuffleOn ? "true" : "false");
  j += ",\"vol\":" + String(st.volume);
  j += ",\"pos\":" + String((unsigned long)st.posBytes);
  j += ",\"size\":" + String((unsigned long)st.sizeBytes);
  j += ",\"used\":" + String((unsigned long)LittleFS.usedBytes());
  j += ",\"total\":" + String((unsigned long)LittleFS.totalBytes());
  size_t ramFree = heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
  size_t ramTotal = ESP.getPsramSize();
  j += ",\"ramUsed\":" + String((unsigned long)(ramTotal > ramFree ? ramTotal - ramFree : 0));
  j += ",\"ramTotal\":" + String((unsigned long)ramTotal) + "}";
  server.send(200, "application/json", j);
}

File     upFile;
bool     upFail = false, upOpen = false, upToRam = false;
String   upName, upReason = "ok";
uint8_t *upRamBuf = nullptr;
uint32_t upRamLen = 0, upRamCap = 0;

void failUpload(const char *reason) { upFail = true; upReason = reason; }

// Grows the staging buffer only when it truly has to (an underestimated Content-Length, or none
// at all). Each grow step still means briefly holding the old AND new buffer at once, so it adds
// a modest amount of headroom rather than doubling — doubling could ask for close to 2x the
// file's actual size in one momentary spike.
bool ramGrow(uint32_t need) {
  if (need <= upRamCap) return true;
  uint32_t newCap = need + (256 * 1024);   // the file itself, plus a little slack
  uint8_t *nb = (uint8_t *)heap_caps_malloc(newCap, MALLOC_CAP_SPIRAM);
  if (!nb) return false;
  if (upRamBuf) { memcpy(nb, upRamBuf, upRamLen); free(upRamBuf); }
  upRamBuf = nb; upRamCap = newCap;
  return true;
}

void onUploadData() {
  HTTPUpload &u = server.upload();
  if (u.status == UPLOAD_FILE_START) {
    upFail = false; upReason = "ok"; upOpen = false;
    upToRam = server.hasArg("loc") && server.arg("loc") == "ram";
    String low = u.filename; low.toLowerCase();
    if (!low.endsWith(".mp3")) { failUpload("notmp3"); return; }
    if (!stopAndWait()) { failUpload("busy"); return; }   // audio task must fully release the file/buffer first
    if (upToRam) {
      if (ramCountSafe() >= MAX_RAM_TRACKS) { failUpload("ramfull"); return; }
      upRamLen = 0; upRamCap = 0;
      if (upRamBuf) { free(upRamBuf); upRamBuf = nullptr; }
      // The browser tells us the whole request's size upfront (a little bigger than the file
      // itself, since it includes the multipart wrapper) — use that to allocate once, exactly,
      // instead of growing the buffer as data arrives.
      long declared = server.header("Content-Length").toInt();
      uint32_t initial = declared > 0 ? (uint32_t)declared + 4096 : 262144;
      if (!ramGrow(initial)) { failUpload("nospace"); return; }
      upName = sanitize(u.filename);
      upOpen = true;
    } else {
      long declared = server.header("Content-Length").toInt();
      uint32_t free_ = LittleFS.totalBytes() - LittleFS.usedBytes();
      if (declared > 0 && (uint32_t)declared > free_ + 8192) { failUpload("nospace"); return; }
      upName = sanitize(u.filename);
      LittleFS.remove("/" + upName);
      upFile = LittleFS.open("/" + upName, "w");
      if (!upFile) { failUpload("ioerror"); return; }
      upOpen = true;
    }
  } else if (u.status == UPLOAD_FILE_WRITE) {
    if (!upOpen || upFail) return;
    if (upToRam) {
      if (!ramGrow(upRamLen + u.currentSize)) { failUpload("nospace"); return; }
      memcpy(upRamBuf + upRamLen, u.buf, u.currentSize);
      upRamLen += u.currentSize;
    } else {
      if (upFile.write(u.buf, u.currentSize) != u.currentSize) failUpload("nospace");
    }
  } else if (u.status == UPLOAD_FILE_END || u.status == UPLOAD_FILE_ABORTED) {
    bool aborted = (u.status == UPLOAD_FILE_ABORTED);
    if (upToRam) {
      if (upOpen && !upFail && !aborted) {
        xSemaphoreTake(dataMx, portMAX_DELAY);
        if (nRamTracks < MAX_RAM_TRACKS) {
          ramTracks[nRamTracks].name = upName;
          ramTracks[nRamTracks].data = upRamBuf;
          ramTracks[nRamTracks].size = upRamLen;
          nRamTracks++;
          upRamBuf = nullptr;   // ownership moved into ramTracks[]
        } else failUpload("ramfull");
        xSemaphoreGive(dataMx);
      }
      if (upRamBuf) { free(upRamBuf); upRamBuf = nullptr; }   // failed/aborted: release the staging buffer
    } else if (upOpen) {
      upFile.close();
      if (upFail || aborted) LittleFS.remove("/" + upName);
    }
    upOpen = false;
  }
}

void onUploadDone() {
  scanTracks();
  dirty = true;
  server.send(upFail ? 400 : 200, "text/plain", upReason);
}

void setupWeb() {
  server.on("/", HTTP_GET, []() { server.send_P(200, "text/html", PAGE); });
  server.on("/api/status", HTTP_GET, sendStatusJson);
  server.on("/api/toggle", HTTP_POST, []() { sendCmd(CMD_TOGGLE); delay(15); sendStatusJson(); });
  server.on("/api/next", HTTP_POST, []() { sendCmd(CMD_NEXT); delay(15); sendStatusJson(); });
  server.on("/api/prev", HTTP_POST, []() { sendCmd(CMD_PREV); delay(15); sendStatusJson(); });
  server.on("/api/shuffle", HTTP_POST, []() { sendCmd(CMD_SHUFFLE); delay(5); sendStatusJson(); });
  server.on("/api/vol", HTTP_POST, []() {
    int v = constrain((int)server.arg("v").toInt(), 0, 100);
    sendCmd(CMD_VOLUME, v);
    delay(5); sendStatusJson();
  });
  server.on("/api/play", HTTP_POST, []() {
    int pos = server.arg("i").toInt();
    int n = trackCountSafe();
    if (pos >= 0 && pos < n) {
      int idx; bool ram; fromPos(pos, idx, ram);
      sendCmd(CMD_PLAY_INDEX, idx | (ram ? 0x10000 : 0));
    }
    delay(15); sendStatusJson();
  });
  server.on("/api/delete", HTTP_POST, []() {
    int pos = server.arg("i").toInt();
    int n = trackCountSafe();
    if (pos >= 0 && pos < n) {
      int idx; bool ram; fromPos(pos, idx, ram);
      Status st = getStatus();
      if (idx == st.curIdx && ram == st.curIsRam) stopAndWait();
      if (ram) {
        xSemaphoreTake(dataMx, portMAX_DELAY);
        if (idx >= 0 && idx < nRamTracks) {
          if (ramTracks[idx].data) free(ramTracks[idx].data);
          for (int k = idx; k < nRamTracks - 1; k++) ramTracks[k] = ramTracks[k + 1];
          nRamTracks--;
        }
        xSemaphoreGive(dataMx);
      } else {
        xSemaphoreTake(dataMx, portMAX_DELAY);
        String nm = (idx >= 0 && idx < nTracks) ? tracks[idx].name : String("");
        xSemaphoreGive(dataMx);
        if (nm.length()) LittleFS.remove("/" + nm);
        scanTracks();
      }
      dirty = true;
    }
    sendStatusJson();
  });
  server.on("/upload", HTTP_POST, onUploadDone, onUploadData);
  server.begin();
}

// ---------------- audio hardware ----------------
// Same setup Makeblock's library uses: ESP32 built-in DAC through I2S0, right channel only
// (GPIO25 -> speaker amplifier, which is enabled through the AW9523B pin AMP_ENABLE).
void initAudio() {
  aw_digitalWrite(AMP_ENABLE, 1);

  i2s_config_t cfg = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_DAC_BUILT_IN),
    .sample_rate = 22050,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .intr_alloc_flags = 0,
    .dma_buf_count = 24,
    .dma_buf_len = 256,
    .use_apll = 0,
    .tx_desc_auto_clear = 0,
  };
  if (i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL) != ESP_OK) return;
  i2s_set_dac_mode(I2S_DAC_CHANNEL_RIGHT_EN);
  updateStatus([](Status &s) { s.audioReady = true; });
  for (int i = 0; i < 30; i++) out.silence();
}

const char *resetName(esp_reset_reason_t r) {
  switch (r) {
    case ESP_RST_POWERON:  return "power-on";
    case ESP_RST_EXT:      return "reset button";
    case ESP_RST_SW:       return "software restart";
    case ESP_RST_PANIC:    return "CRASH (panic)";
    case ESP_RST_INT_WDT:  return "watchdog (int)";
    case ESP_RST_TASK_WDT: return "watchdog (task)";
    case ESP_RST_WDT:      return "watchdog";
    case ESP_RST_BROWNOUT: return "BROWNOUT (power dip)";
    case ESP_RST_DEEPSLEEP:return "deep sleep";
    default:               return "other";
  }
}

// ---------------- setup / loop ----------------
void setup() {
  Serial.begin(115200);

  dataMx = xSemaphoreCreateMutex();
  statusMx = xSemaphoreCreateMutex();
  cmdQueue = xQueueCreate(8, sizeof(Cmd));

  // Why did we (re)start, and how far did the last run get?
  esp_reset_reason_t rr = esp_reset_reason();
  bool abnormal = (rr == ESP_RST_PANIC || rr == ESP_RST_INT_WDT || rr == ESP_RST_TASK_WDT ||
                   rr == ESP_RST_WDT || rr == ESP_RST_BROWNOUT);
  uint32_t lastStage = (rtcMagic == RTC_MAGIC && rr != ESP_RST_POWERON) ? rtcStage : ST_NONE;
  Serial.printf("\nReset reason: %s, last stage: %s\n", resetName(rr), stageName(lastStage));

  // --- display + buttons ---
  setStage(ST_DISPLAY);
  i2c_init();
  aw_init();
  aw_pinMode(AMP_ENABLE, AW_GPIO_MODE_OUTPUT);
  int pads[] = { JOY_UP, JOY_DOWN, JOY_RIGHT, JOY_LEFT, JOY_CENTER, BTN_A, BTN_B, BTN_MENU };
  for (int i = 0; i < 8; i++) aw_pinMode((aw_gpio_num_t)pads[i], AW_GPIO_MODE_INPUT);
  lcd_init();
  lcd_on();
  cWhite  = color24to16(0xFFFFFF);
  cGrey   = color24to16(0x8B90A0);
  cBlue   = color24to16(0x3B82F6);
  cGreen  = color24to16(0x22C55E);
  cOrange = color24to16(0xF59E0B);
  cBg     = color24to16(0x000000);   // pure black: navy showed up green on the display (likely an
  cCard   = color24to16(0x161A3F);   // R/B channel swap in the panel's color order), and black is
                                      // the one color unaffected by that swap either way
  primeButtons();
  randomSeed(esp_random());

  if (abnormal) {
    splash("Last restart:", resetName(rr), String("during: ") + stageName(lastStage));
    delay(5000);
  }
  bool skipAudio = abnormal && lastStage == ST_AUDIO;    // audio init crashed last time: boot without it
  bool wifiSafe  = abnormal && lastStage == ST_WIFI;     // WiFi start crashed last time: gentler WiFi

  // --- storage ---
  setStage(ST_STORAGE);
  splash("Starting...", "Preparing storage", "");
  if (!LittleFS.begin(true)) splash("Storage error", "LittleFS failed", "Check partition scheme");
  scanTracks();
  Serial.printf("Flash %u MB, storage %u KB, %d tracks\n",
                (unsigned)(ESP.getFlashChipSize() / 1048576), (unsigned)(LittleFS.totalBytes() / 1024), trackCountSafe());

  // --- audio ---
  setStage(ST_AUDIO);
  if (skipAudio) { splash("Audio is OFF", "It crashed last time", "Tell Claude the above"); delay(3000); }
  else initAudio();

  // --- WiFi ---
  setStage(ST_WIFI);
  bool connected = false;
  if (!wifiSafe) {
    splash("Connecting WiFi", WIFI_SSID, "");
    WiFi.mode(WIFI_STA);
    WiFi.setTxPower(WIFI_POWER_15dBm);               // lower TX power = smaller current spikes
    WiFi.setHostname(HOSTNAME);
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    uint32_t t0 = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - t0 < 12000) delay(200);
    connected = (WiFi.status() == WL_CONNECTED);
  }
  if (connected) {
    ipText = WiFi.localIP().toString();
    MDNS.begin(HOSTNAME);
    splash("Open in browser:", ipText, String(HOSTNAME) + ".local");
  } else {
    WiFi.disconnect(true);
    WiFi.mode(WIFI_AP);
    WiFi.setTxPower(wifiSafe ? WIFI_POWER_8_5dBm : WIFI_POWER_15dBm);
    WiFi.softAP(AP_SSID, AP_PASS);
    ipText = "AP " + WiFi.softAPIP().toString();
    splash(String("WiFi: ") + AP_SSID, String("Pass: ") + AP_PASS, WiFi.softAPIP().toString());
  }
  WiFi.setSleep(false);
  Serial.println("Web UI: " + ipText);
  delay(3000);

  // --- web ---
  setStage(ST_WEB);
  setupWeb();

  // --- start the audio task on the other core, so decoding never delays the web/UI task ---
  xTaskCreatePinnedToCore(audioTask, "audio", 8192, NULL, 5, NULL, 0);

  setStage(ST_RUN);
  dirty = true;
}

void loop() {
  server.handleClient();
  handleInput();
  updateScreen();
  delay(1);
}
