CyberPi Browser
===============
1. Unzip so the folder "CyberPiBrowser" holds all the files (CyberPiBrowser.ino + the .h files).
2. Arduino IDE: Board "ESP32 Wrover Module", PSRAM "Enabled" (use "Disabled" if it will not start),
   Partition "Huge APP" (or default). No extra libraries are needed.
3. Upload. The screen shows the start page.
   - First time: join the WiFi "CyberPi-Browser" with your phone, open http://192.168.4.1 ,
     tap "WiFi settings", enter your home WiFi, save. The CyberPi restarts and joins it.
   - Then open http://<address shown at the bottom of the B list> to edit preset links.

Controls: joystick = mouse (push at top/bottom edge to scroll), A = click,
          B = preset links list, MENU = back / stop, joystick press = reload.

If the screen is dark / garbled: the LCD wiring values in the sketch are a best guess.
Open http://<ip>/hw (works even with a dark screen) and change the pins/offset/MADCTL;
"Save & test" redraws a colour-bar test pattern. The values are stored, no re-flashing.

Page layout: centred / right-aligned text, list indents, block quotes, buttons, inputs, bordered boxes and
table columns are drawn. Hidden (display:none) elements are skipped. Pictures on white backgrounds are
darkened to fit the black theme.
