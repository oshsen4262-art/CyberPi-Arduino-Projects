// Engine.h - URL helpers, page model, streaming HTML -> text-line layout, and renderer.
// Pure C++ (no Arduino), so it can be tested on a PC.
#pragma once
#include <ctype.h>
#include "Common.h"

// ---------------------------------------------------------------- URLs
struct Url { std::string scheme, host, path; int port = 0; };

static inline std::string lower(std::string s) { for (auto &c : s) c = (char)tolower((unsigned char)c); return s; }

static bool parseUrl(const std::string &s, Url &u) {
  size_t p = s.find("://");
  if (p == std::string::npos) return false;
  u.scheme = lower(s.substr(0, p));
  if (u.scheme != "http" && u.scheme != "https") return false;
  size_t hs = p + 3, he = s.find_first_of("/?#", hs);
  std::string hostport = s.substr(hs, he == std::string::npos ? std::string::npos : he - hs);
  std::string rest = he == std::string::npos ? "" : s.substr(he);
  size_t h = rest.find('#'); if (h != std::string::npos) rest.erase(h);
  if (rest.empty() || rest[0] != '/') rest = "/" + rest;
  u.path = rest;
  size_t at = hostport.rfind('@'); if (at != std::string::npos) hostport.erase(0, at + 1);
  u.port = u.scheme == "https" ? 443 : 80;
  size_t c = hostport.rfind(':');
  if (c != std::string::npos && hostport.find(']') == std::string::npos) { u.port = atoi(hostport.c_str() + c + 1); hostport.erase(c); }
  u.host = lower(hostport);
  return !u.host.empty() && u.port > 0;
}

static std::string urlOrigin(const Url &u) {
  std::string o = u.scheme + "://" + u.host;
  if ((u.scheme == "http" && u.port != 80) || (u.scheme == "https" && u.port != 443)) o += ":" + std::to_string(u.port);
  return o;
}

static std::string normalizePath(const std::string &path) {
  size_t q = path.find('?');
  std::string p = q == std::string::npos ? path : path.substr(0, q), query = q == std::string::npos ? "" : path.substr(q);
  std::vector<std::string> seg;
  size_t i = 0;
  while (i <= p.size()) {
    size_t j = p.find('/', i); if (j == std::string::npos) j = p.size();
    std::string part = p.substr(i, j - i);
    if (part == "..") { if (!seg.empty()) seg.pop_back(); }
    else if (part != ".") seg.push_back(part);
    i = j + 1;
  }
  std::string out;
  for (size_t k = 0; k < seg.size(); k++) { if (k == 0 && seg[k].empty()) continue; out += "/" + seg[k]; }
  if (out.empty()) out = "/";
  if (!p.empty() && p.back() == '/' && out.back() != '/') out += "/";
  return out + query;
}

// Returns "" when the link cannot be followed (javascript:, mailto:, #fragment only, ...).
static std::string resolveUrl(const std::string &base, const std::string &refIn) {
  std::string ref;
  for (char c : refIn) if (c != '\n' && c != '\r' && c != '\t') ref += c;
  size_t a = ref.find_first_not_of(' '); if (a == std::string::npos) return "";
  ref = ref.substr(a);
  while (!ref.empty() && ref.back() == ' ') ref.pop_back();
  if (ref.empty() || ref[0] == '#') return "";
  { size_t h = ref.find('#'); if (h != std::string::npos) ref.erase(h); }
  std::string lr = lower(ref.substr(0, 11));
  if (lr.rfind("javascript:", 0) == 0 || lr.rfind("mailto:", 0) == 0 || lr.rfind("tel:", 0) == 0 || lr.rfind("data:", 0) == 0) return "";
  if (lr.rfind("http://", 0) == 0 || lr.rfind("https://", 0) == 0) { Url u; if (!parseUrl(ref, u)) return ""; return urlOrigin(u) + normalizePath(u.path); }
  Url b; if (!parseUrl(base, b)) return "";
  std::string spc; for (char c : ref) { if (c == ' ') spc += "%20"; else spc += c; } ref = spc;
  if (ref.rfind("//", 0) == 0) return resolveUrl(base, b.scheme + ":" + ref);
  if (ref[0] == '/') return urlOrigin(b) + normalizePath(ref);
  if (ref[0] == '?') { std::string p = b.path; size_t q = p.find('?'); if (q != std::string::npos) p.erase(q); return urlOrigin(b) + p + ref; }
  std::string dir = b.path; size_t q = dir.find('?'); if (q != std::string::npos) dir.erase(q);
  size_t sl = dir.rfind('/'); dir = dir.substr(0, sl + 1);
  return urlOrigin(b) + normalizePath(dir + ref);
}

// ---------------------------------------------------------------- page model
struct Img { std::string url, alt; uint16_t *px = nullptr; int w = 0, h = 0; uint8_t state = 0; int line = -1; }; // state 0 pending 1 ok 2 failed
// kind 0 text, 1 image, 2 rule, 3 gap, 4 box padding (invisible)
struct Line {
  int32_t y = 0; uint16_t h = LINE_H; uint8_t kind = 0, style = 0;
  int16_t img = -1; uint16_t link = 0; uint16_t *lk = nullptr;
  int16_t x = MARGIN_X;                       // where the text starts (pixels): indent / centring / right alignment
  int16_t w = SCR_W - 2 * MARGIN_X;           // width of the container the line sits in (images centre inside it)
  char text[COLS + 1];
};
// A rectangle / panel / left bar drawn behind a run of lines.
enum : uint8_t { BX_BORDER = 1, BX_FILL = 2, BX_BAR = 4, BX_TOP = 8, BX_BTN = 16, BX_INPUT = 32, BX_SHRINK = 64 };
struct Box { int32_t first = 0, last = -1; int16_t x0 = 0, x1 = 0; uint8_t kind = 0, nsep = 0; uint8_t sep[4] = {0, 0, 0, 0}; };

struct Page {
  std::string url, base, title;
  std::vector<Line> lines;
  std::vector<Box> boxes;
  std::vector<std::string> links;   // index 0 unused
  std::vector<Img> imgs;
  int32_t totalH = 0;
  bool truncated = false;
  size_t maxLines = 700, maxLinks = 500, maxImgs = 8, maxBoxes = 300;
  Page() { links.push_back(""); }
  ~Page() { clear(); }
  void clear() {
    for (auto &l : lines) if (l.lk) { free(l.lk); l.lk = nullptr; }
    for (auto &i : imgs) if (i.px) { free(i.px); i.px = nullptr; }
    lines.clear(); imgs.clear(); boxes.clear(); links.assign(1, ""); totalH = 0;
  }
  void relayout() { int32_t y = 0; for (auto &l : lines) { l.y = y; y += l.h; } totalH = y; }
  bool push(const Line &l) {
    if (lines.size() >= maxLines) { truncated = true; return false; }
    lines.push_back(l);
    lines.back().y = totalH; totalH += l.h; return true;
  }
  Page(const Page &) = delete; Page &operator=(const Page &) = delete;
};

// ---------------------------------------------------------------- HTML parser (streaming)
class HtmlParser {
public:
  explicit HtmlParser(Page &p) : pg(p) {}
  bool plain = false;

  void startPlain() { plain = true; pre = true; style = 2; skipNl = false; }

  void feed(uint8_t c) {
    if (pg.truncated) return;
    if (plain) { utf8(c); return; }
    switch (st) {
      case TEXT:
        if (c == '<' && !u8n) { st = LT; return; }
        if (c == '&' && !u8n) { st = ENT; ent.clear(); return; }
        utf8(c); return;
      case ENT:
        if (c == ';') { entity(); st = TEXT; return; }
        if ((isalnum(c) || c == '#') && ent.size() < 10) { ent += (char)c; return; }
        entityLiteral(); st = TEXT; feed(c); return;
      case LT:
        if (isalpha(c) || c == '/') { tag.assign(1, (char)c); st = TAG; q = 0; return; }
        if (c == '!') { st = BANG; bang.clear(); return; }
        if (c == '?') { st = SKIPTAG; return; }
        textCp('<'); st = TEXT; feed(c); return;
      case BANG:
        bang += (char)c;
        if (bang == "--") { st = COMMENT; cm = 0; return; }
        if (bang.size() >= 2 || c == '>') { st = (c == '>') ? TEXT : SKIPTAG; }
        return;
      case COMMENT:
        if (c == '-') { if (cm < 2) cm++; }
        else if (c == '>' && cm >= 2) { st = TEXT; cm = 0; }
        else cm = 0;
        return;
      case SKIPTAG: if (c == '>') st = TEXT; return;
      case TAG:
        if (q) { if (c == q) q = 0; }
        else if (c == '"' || c == '\'') q = (char)c;
        else if (c == '>') { st = TEXT; handleTag(); return; }
        if (tag.size() < 1500) tag += (char)c;
        return;
      case RAW:
        rawWin += (char)tolower(c);
        if (rawWin.size() > 12) rawWin.erase(0, rawWin.size() - 12);
        if (c == '>' && rawWin.size() >= rawEnd.size() + 1 && rawWin.find(rawEnd) != std::string::npos) { st = TEXT; rawWin.clear(); }
        return;
    }
  }

  void finish() { closeAll(); flushWord(); flushLine(); if (pg.truncated) { Line l; strcpy(l.text, "[page truncated]"); l.style = 3; pg.truncated = false; size_t m = pg.maxLines; pg.maxLines = m + 1; pg.push(l); pg.maxLines = m; pg.truncated = true; } }
  void feedString(const std::string &s) { for (unsigned char c : s) feed(c); }

private:
  enum St { TEXT, ENT, LT, BANG, COMMENT, SKIPTAG, TAG, RAW } st = TEXT;
  Page &pg;
  std::string tag, ent, bang, rawWin, rawEnd;
  char q = 0; int cm = 0;
  // utf-8
  int u8n = 0; uint32_t u8cp = 0;
  bool lastQ = false;
  // layout state
  char lt[COLS + 1]; uint16_t ll[COLS + 4]; int col = 0; bool hasLink = false;
  char w[40]; uint16_t wl[40]; int wn = 0;
  uint16_t curLink = 0; uint8_t style = 0;
  bool pre = false, skipNl = false, wantGap = false, inTitle = false, glue = false;
  int skipDepth = 0;
  int olStack[8]; int olDepth = 0;

  // ---- layout geometry: the current container, alignment, boxes ----
  int curL = MARGIN_X, curR = SCR_W - MARGIN_X;      // container left/right edge in pixels
  uint8_t alignM = 0;                                // 0 left, 1 centre, 2 right
  int maxC() const { int c = (curR - curL) / CHAR_W; return c < 3 ? 3 : (c > COLS ? COLS : c); }
  enum : uint8_t { T_DIV = 1, T_P, T_CENTER, T_BQ, T_UL, T_LI, T_DD, T_PRE, T_H, T_A, T_BTN, T_FORM, T_FSET };
  struct Ctx { uint8_t tag; uint8_t align; int16_t L, R, box; };
  Ctx stk[40]; int sp = 0, boxDepth = 0;
  bool bulletPend = false; char bulletText[8] = ""; int bulletHang = 2, bulletL = MARGIN_X;
  std::string hidName; int hidDepth = 0;             // display:none / hidden elements are skipped
  // ---- table row capture (so cells can be laid out as columns) ----
  struct Cell { std::string s; std::vector<uint16_t> lk; int8_t align = -1; bool th = false; };
  struct Tbl {
    bool border = false, rowOpen = false, cap = false, cellOpen = false, capSp = false;
    int spBase = 0, cellSp = 0, rows = 0, nGrid = 0; int gridW[4] = {0, 0, 0, 0}; size_t capBytes = 0;
    std::vector<Cell> cells;
    std::vector<std::vector<Cell>> buf; size_t bufBytes = 0; bool gridDone = false;   // first rows are held back to pick column widths
  };
  Tbl tb[4]; int tbN = 0, tblOverflow = 0;

  // ---- text input path ----
  void utf8(uint8_t c) {
    if (u8n) {
      if ((c & 0xC0) == 0x80) { u8cp = (u8cp << 6) | (c & 0x3F); if (--u8n == 0) textCp(u8cp); return; }
      u8n = 0; textCp('?');
    }
    if (c < 0x80) textCp(c);
    else if ((c & 0xE0) == 0xC0) { u8n = 1; u8cp = c & 0x1F; }
    else if ((c & 0xF0) == 0xE0) { u8n = 2; u8cp = c & 0x0F; }
    else if ((c & 0xF8) == 0xF0) { u8n = 3; u8cp = c & 0x07; }
    else textCp('?');
  }
  void textCp(uint32_t cp) {
    if (cp < 128) { lastQ = false; textChar((char)cp); return; }
    static const char *latin = "AAAAAAACEEEEIIIIDNOOOOO*OUUUUYTsaaaaaaaceeeeiiiidnooooo/ouuuuyty";
    const char *rep = nullptr; char one[2] = {0, 0};
    switch (cp) {
      case 0xA0: case 0x2002: case 0x2003: case 0x2009: case 0x202F: rep = " "; break;
      case 0x200B: case 0x200C: case 0x200D: case 0x200E: case 0x200F: case 0xFEFF: case 0xAD: return;
      case 0x2018: case 0x2019: case 0x2032: rep = "'"; break;
      case 0x201C: case 0x201D: case 0x2033: rep = "\""; break;
      case 0x2013: case 0x2014: case 0x2212: rep = "-"; break;
      case 0x2026: rep = "..."; break;
      case 0x2022: case 0xB7: case 0x25CF: rep = "*"; break;
      case 0xA9: rep = "(c)"; break;
      case 0xAE: rep = "(R)"; break;
      case 0x2122: rep = "(TM)"; break;
      case 0xAB: rep = "<<"; break;
      case 0xBB: rep = ">>"; break;
      case 0xD7: rep = "x"; break;
      case 0xB0: rep = "o"; break;
      case 0x20AC: rep = "EUR"; break;
      case 0xA3: rep = "GBP"; break;
      case 0x2190: rep = "<-"; break;
      case 0x2192: rep = "->"; break;
      case 0x2191: rep = "^"; break;
      case 0x2193: rep = "v"; break;
      default:
        if (cp >= 0xC0 && cp <= 0xFF) { one[0] = latin[cp - 0xC0]; rep = one; }
    }
    if (!rep) { if (!lastQ) { textChar('?'); lastQ = true; } return; }
    lastQ = false;
    for (const char *p = rep; *p; p++) textChar(*p);
  }
  void entity() {
    static const struct { const char *n; uint32_t c; } E[] = {
      {"amp",38},{"lt",60},{"gt",62},{"quot",34},{"apos",39},{"nbsp",160},{"copy",169},{"reg",174},{"hellip",8230},
      {"mdash",8212},{"ndash",8211},{"lsquo",8216},{"rsquo",8217},{"ldquo",8220},{"rdquo",8221},{"bull",8226},
      {"middot",183},{"laquo",171},{"raquo",187},{"times",215},{"deg",176},{"trade",8482},{"euro",8364},
      {"pound",163},{"larr",8592},{"rarr",8594},{"uarr",8593},{"darr",8595},{"shy",173},{"zwnj",8204}};
    uint32_t cp = 0;
    if (!ent.empty() && ent[0] == '#') {
      if (ent.size() > 1 && (ent[1] == 'x' || ent[1] == 'X')) cp = (uint32_t)strtoul(ent.c_str() + 2, nullptr, 16);
      else cp = (uint32_t)strtoul(ent.c_str() + 1, nullptr, 10);
    } else {
      for (auto &e : E) if (ent == e.n) { cp = e.c; break; }
      if (!cp && ent.size() >= 5) {   // eacute, agrave, ouml, ntilde, ccedil, aring, oslash ... -> base letter
        static const char *suf[] = {"acute", "grave", "circ", "uml", "tilde", "cedil", "ring", "slash"};
        for (const char *sx : suf) { size_t l = strlen(sx); if (ent.size() == l + 1 && ent.compare(1, l, sx) == 0 && isalpha((unsigned char)ent[0])) { cp = (unsigned char)ent[0]; break; } }
        if (!cp && ent == "szlig") { textChar('s'); cp = 's'; }
        if (!cp && ent == "aelig") { textChar('a'); cp = 'e'; }
      }
    }
    if (cp) textCp(cp);
  }
  void entityLiteral() { textChar('&'); for (char c : ent) textChar(c); }

  void textChar(char c) {
    if (skipDepth > 0) return;
    if (inTitle) {
      if (isspace((unsigned char)c)) { if (!pg.title.empty() && pg.title.back() != ' ') pg.title += ' '; }
      else if (pg.title.size() < 48) pg.title += c;
      return;
    }
    if (capActive()) { capChar(c); return; }
    if (pre) { preChar(c); return; }
    if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f') { flushWord(); glue = false; return; }
    if ((unsigned char)c < 32) return;
    w[wn] = c; wl[wn] = curLink; wn++;
    if (wn >= 36) { flushWord(); glue = true; }
  }
  void preChar(char c) {
    if (skipNl && c == '\n') { skipNl = false; return; }
    skipNl = false;
    if (c == '\r') return;
    if (c == '\n') { if (col == 0) pushEmpty(); else flushLine(); return; }
    if (c == '\t') { for (int i = 0; i < 4; i++) putCh(' ', curLink); return; }
    if ((unsigned char)c < 32) return;
    putCh(c, curLink);
  }

  // ---- line building ----
  void putCh(char c, uint16_t link) {
    if (col >= maxC()) flushLine();
    lt[col] = c; ll[col] = link; if (link) hasLink = true; col++;
  }
  void pushEmpty() { Line l; l.text[0] = 0; l.style = style; l.x = (int16_t)curL; l.w = (int16_t)(curR - curL); pg.push(l); }
  void gapIfWanted() {
    if (wantGap && !pg.lines.empty() && pg.lines.back().kind != 3) { Line g; g.kind = 3; g.h = 4; g.text[0] = 0; pg.push(g); }
    wantGap = false;
  }
  void padLine() { Line g; g.kind = 4; g.h = 2; g.text[0] = 0; g.x = (int16_t)curL; g.w = (int16_t)(curR - curL); pg.push(g); }
  void flushLine() {
    if (col == 0) return;
    gapIfWanted();
    Line l; int off = 0;
    if (bulletPend) {                                   // first line of a list item: bullet, then hanging indent
      bulletPend = false;
      int bl = (int)strlen(bulletText);
      for (int i = 0; i < bulletHang && i < COLS; i++) l.text[off++] = i < bl ? bulletText[i] : ' ';
      l.x = (int16_t)bulletL;
    } else {
      int space = (curR - curL) - col * CHAR_W; if (space < 0) space = 0;
      l.x = (int16_t)(curL + (alignM == 1 ? space / 2 : alignM == 2 ? space : 0));
    }
    int n = col; if (off + n > COLS) n = COLS - off;
    memcpy(l.text + off, lt, n); l.text[off + n] = 0;
    l.style = style; l.w = (int16_t)(curR - curL);
    if (hasLink) {
      l.lk = (uint16_t *)malloc((off + n) * sizeof(uint16_t));
      if (l.lk) { memset(l.lk, 0, off * sizeof(uint16_t)); memcpy(l.lk + off, ll, n * sizeof(uint16_t)); }
    }
    if (!pg.push(l) && l.lk) free(l.lk);
    col = 0; hasLink = false;
  }
  void flushWord() {
    if (wn == 0) return;
    int n = wn; wn = 0;
    bool g = glue; glue = false;
    if (g) { for (int i = 0; i < n; i++) putCh(w[i], wl[i]); return; }
    if (col > 0 && col + 1 + n > maxC()) flushLine();
    if (col > 0) { uint16_t sl = (ll[col - 1] && ll[col - 1] == wl[0]) ? wl[0] : 0; putCh(' ', sl); }
    for (int i = 0; i < n; i++) putCh(w[i], wl[i]);
  }
  void literalWord(const char *s) { flushWord(); for (const char *p = s; *p; p++) { w[wn] = *p; wl[wn] = 0; wn++; } flushWord(); }
  void blockBreak(bool gap) { if (capActive()) { capBreak(); return; } flushWord(); flushLine(); if (gap) wantGap = true; }

  uint16_t addLink(const std::string &href) {
    if (pg.links.size() >= pg.maxLinks) return 0;
    pg.links.push_back(href);
    return (uint16_t)(pg.links.size() - 1);
  }

  // ---- boxes ----
  // Opens a box around the lines that follow. Returns its index (or -1 when it is not drawn).
  // Insets the container; the caller restores curL/curR (normally through popCtx()).
  int openBox(uint8_t kind, bool shrink) {
    abortCapture();
    if (pg.boxes.size() >= pg.maxBoxes || boxDepth >= 3 || (curR - curL) < 9 * CHAR_W) return -1;
    flushWord(); flushLine(); gapIfWanted();
    Box b; b.kind = kind | (kind & BX_BAR ? 0 : BX_TOP) | (shrink ? BX_SHRINK : 0);
    b.x0 = (int16_t)curL; b.x1 = (int16_t)(curR - 1);
    b.first = (int32_t)pg.lines.size();
    if (kind & BX_BAR) curL += 6; else { padLine(); curL += 3; curR -= 3; }
    boxDepth++;
    pg.boxes.push_back(b);
    return (int)pg.boxes.size() - 1;
  }
  void closeBox(int idx) {
    flushWord(); flushLine();
    Box &b = pg.boxes[idx];
    if (!(b.kind & BX_BAR)) padLine();
    b.last = (int32_t)pg.lines.size() - 1;
    boxDepth--;
    bool content = false;
    for (int32_t i = b.first; i <= b.last && i < (int32_t)pg.lines.size(); i++) if (pg.lines[i].kind <= 2) { content = true; break; }
    if (!content) {                                       // empty box: take it back
      if (b.first < (int32_t)pg.lines.size()) {
        for (size_t i = b.first; i < pg.lines.size(); i++) if (pg.lines[i].lk) free(pg.lines[i].lk);
        pg.lines.resize(b.first); pg.relayout();
      }
      b.kind = 0; b.last = -1; return;
    }
    if (b.kind & BX_SHRINK) {                             // wrap tightly around the text (buttons, inputs, badges)
      int mn = 9999, mx = -1;
      for (int32_t i = b.first; i <= b.last; i++) {
        const Line &L = pg.lines[i];
        if (L.kind != 0 || !L.text[0]) continue;
        int e = L.x + (int)strlen(L.text) * CHAR_W;
        if (L.x < mn) mn = L.x;
        if (e > mx) mx = e;
      }
      if (mx >= 0) { int x0 = mn - 3, x1 = mx + 1; if (x0 > b.x0) b.x0 = (int16_t)x0; if (x1 < b.x1) b.x1 = (int16_t)x1; }
    }
  }

  // ---- container stack (alignment / indent / box are restored when the element closes) ----
  Ctx *pushCtx(uint8_t tagId) {
    if (sp >= 40) return nullptr;
    Ctx &c = stk[sp++]; c.tag = tagId; c.align = alignM; c.L = (int16_t)curL; c.R = (int16_t)curR; c.box = -1;
    return &c;
  }
  void popCtx() {
    if (sp <= 0) return;
    flushWord(); flushLine();
    Ctx c = stk[--sp];
    if (c.box >= 0) closeBox(c.box);
    curL = c.L; curR = c.R; alignM = c.align;
    if (c.tag == T_LI) bulletPend = false;
    if (c.tag == T_H) style = 0;
    if (c.tag == T_PRE) { pre = false; style = 0; }
  }
  bool popTo(uint8_t tagId) {
    for (int i = sp - 1; i >= 0; i--) if (stk[i].tag == tagId) { while (sp > i) popCtx(); return true; }
    return false;
  }
  bool topIs(uint8_t tagId) const { return sp > 0 && stk[sp - 1].tag == tagId; }

  // ---- table row capture ----
  bool capActive() const { return tbN > 0 && tblOverflow == 0 && tb[tbN - 1].cap && tb[tbN - 1].cellOpen; }
  void capChar(char c) {
    Tbl &t = tb[tbN - 1]; Cell &ce = t.cells.back();
    if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f') { t.capSp = true; return; }
    if ((unsigned char)c < 32) return;
    if (t.capSp) {
      if (!ce.s.empty() && ce.s.back() != '\n') { ce.s += ' '; ce.lk.push_back((ce.lk.back() && ce.lk.back() == curLink) ? curLink : 0); }
      t.capSp = false;
    }
    ce.s += c; ce.lk.push_back(curLink);
    if (++t.capBytes > 1500) abortCapture();               // too much for a column layout
  }
  void capBreak() {
    Tbl &t = tb[tbN - 1]; Cell &ce = t.cells.back();
    if (!ce.s.empty() && ce.s.back() != '\n') { ce.s += '\n'; ce.lk.push_back(0); }
    t.capSp = false;
  }
  void replayCell(const Cell &c) {
    uint16_t keep = curLink;
    for (size_t k = 0; k < c.s.size(); k++) { if (c.s[k] == '\n') blockBreak(false); else { curLink = c.lk[k]; textChar(c.s[k]); } }
    flushWord(); curLink = keep;
  }
  // Give up on columns for this row: print what was captured as ordinary text, carry on streaming.
  void abortCapture() {
    if (tbN == 0 || tblOverflow > 0 || !tb[tbN - 1].cap) return;
    Tbl &t = tb[tbN - 1]; t.cap = false;
    std::vector<Cell> cs; cs.swap(t.cells);
    flushBuf(t);
    for (size_t i = 0; i < cs.size(); i++) { if (i) literalWord("|"); replayCell(cs[i]); }
  }

  struct WL { std::string t; std::vector<uint16_t> lk; };
  static void wrapCell(const Cell &c, int width, std::vector<WL> &out) {
    WL cur;
    size_t i = 0, n = c.s.size();
    while (i < n) {
      char ch = c.s[i];
      if (ch == '\n') { if (!cur.t.empty()) { out.push_back(cur); cur = WL(); } i++; continue; }
      if (ch == ' ') { i++; continue; }
      size_t j = i; while (j < n && c.s[j] != ' ' && c.s[j] != '\n') j++;
      int len = (int)(j - i);
      bool sp = !cur.t.empty();
      if (sp && (int)cur.t.size() + 1 + len > width) { out.push_back(cur); cur = WL(); sp = false; }
      if (sp) { cur.t += ' '; cur.lk.push_back((i > 0 && c.s[i - 1] == ' ') ? c.lk[i - 1] : 0); }
      size_t p = i;
      while (p < j) {
        int room = width - (int)cur.t.size();
        if (room <= 0) { out.push_back(cur); cur = WL(); room = width; }
        int take = (int)(j - p); if (take > room) take = room;
        for (int k = 0; k < take; k++) { cur.t += c.s[p + k]; cur.lk.push_back(c.lk[p + k]); }
        p += take;
      }
      i = j;
    }
    if (!cur.t.empty() || out.empty()) out.push_back(cur);
  }
  // Column widths for n columns in W text columns, from one or more sample rows: a column is never narrower than its
  // longest word (up to 9), then extra room goes to the columns whose text is still wrapping.
  static int longestWord(const std::string &s) { int best = 0, cur = 0; for (char c : s) { if (c == ' ' || c == '\n') cur = 0; else if (++cur > best) best = cur; } return best; }
  static void gridWidths(const std::vector<const std::vector<Cell> *> &rs, int n, int W, int *w) {
    int nat[4] = {1, 1, 1, 1}, minw[4] = {1, 1, 1, 1};
    for (auto *r : rs) for (int i = 0; i < n; i++) {
      int l = (int)(*r)[i].s.size(); if (l > nat[i]) nat[i] = l;
      int lw = longestWord((*r)[i].s); if (lw > 9) lw = 9; if (lw > minw[i]) minw[i] = lw;
    }
    int sum = 0; for (int i = 0; i < n; i++) { w[i] = minw[i]; if (w[i] > nat[i]) w[i] = nat[i]; if (nat[i] >= 3 && w[i] < 3) w[i] = 3; if (w[i] < 1) w[i] = 1; sum += w[i]; }
    while (sum > W) { int b = 0; for (int i = 1; i < n; i++) if (w[i] > w[b]) b = i; if (w[b] <= 2) break; w[b]--; sum--; }
    int rem = W - sum;
    while (rem > 0) {
      int act = 0; for (int i = 0; i < n; i++) if (w[i] < nat[i]) act++;
      if (!act) break;
      int share = rem / act; if (share < 1) share = 1;
      for (int i = 0; i < n && rem > 0; i++) if (w[i] < nat[i]) { int g = nat[i] - w[i]; if (g > share) g = share; if (g > rem) g = rem; w[i] += g; rem -= g; }
    }
    if (rem > 0) {                                        // everything fits: spread the extra over the wordier columns
      int k = 0; for (int i = 0; i < n; i++) if (nat[i] >= 3) k++;
      if (k == 0) w[n - 1] += rem;
      else { int last = -1, give = rem / k; for (int i = 0; i < n; i++) if (nat[i] >= 3) { w[i] += give; rem -= give; last = i; } w[last] += rem; }
    }
  }
  static void trimCell(Cell &c) {
    while (!c.s.empty() && (c.s.back() == ' ' || c.s.back() == '\n')) { c.s.pop_back(); c.lk.pop_back(); }
    size_t a = 0; while (a < c.s.size() && (c.s[a] == ' ' || c.s[a] == '\n')) a++;
    if (a) { c.s.erase(0, a); c.lk.erase(c.lk.begin(), c.lk.begin() + a); }
  }
  // One table row as columns: each visual line is a single Line, columns separated by one character.
  void emitRow(Tbl &t, std::vector<Cell> &cs, const int *w, int n) {
    std::vector<std::vector<WL>> cols(n);
    size_t rows = 1;
    for (int i = 0; i < n; i++) { wrapCell(cs[i], w[i], cols[i]); if (cols[i].size() > rows) rows = cols[i].size(); }
    int total = n - 1; for (int i = 0; i < n; i++) total += w[i];
    if (total > COLS) return;
    bool allTh = true; for (auto &c : cs) if (!c.th) allTh = false;
    flushWord(); flushLine(); gapIfWanted();
    int bi = -1;
    if (t.border && pg.boxes.size() < pg.maxBoxes) {
      Box b; b.kind = BX_BORDER | (t.rows == 0 ? BX_TOP : 0) | (allTh ? BX_FILL : 0);
      b.x0 = (int16_t)curL; b.x1 = (int16_t)(curL + 3 + total * CHAR_W + 1);
      int start = 0; for (int j = 1; j < n && j <= 4; j++) { start += w[j - 1] + 1; b.sep[b.nsep++] = (uint8_t)(start * CHAR_W); }
      b.first = (int32_t)pg.lines.size(); padLine();
      pg.boxes.push_back(b); bi = (int)pg.boxes.size() - 1;
    }
    int x0 = curL + (t.border ? 3 : 0);
    for (size_t r = 0; r < rows; r++) {
      Line l; l.x = (int16_t)x0; l.w = (int16_t)(total * CHAR_W); l.style = allTh ? 1 : 0;
      char buf[COLS + 2]; uint16_t lkb[COLS + 2]; bool anyLk = false;
      memset(buf, ' ', total); buf[total] = 0; memset(lkb, 0, sizeof lkb);
      int pos = 0;
      for (int i = 0; i < n; i++) {
        if (r < cols[i].size()) {
          const WL &q = cols[i][r]; int len = (int)q.t.size();
          int al = cs[i].align >= 0 ? cs[i].align : (cs[i].th && allTh ? 1 : 0);   // only header rows are centred
          int off = al == 1 ? (w[i] - len) / 2 : al == 2 ? (w[i] - len) : 0; if (off < 0) off = 0;
          for (int k = 0; k < len && pos + off + k < total; k++) { buf[pos + off + k] = q.t[k]; lkb[pos + off + k] = q.lk[k]; if (q.lk[k]) anyLk = true; }
        }
        pos += w[i] + 1;
      }
      memcpy(l.text, buf, total + 1);
      if (anyLk) { l.lk = (uint16_t *)malloc(total * sizeof(uint16_t)); if (l.lk) memcpy(l.lk, lkb, total * sizeof(uint16_t)); }
      if (!pg.push(l) && l.lk) free(l.lk);
    }
    if (bi >= 0) { padLine(); pg.boxes[bi].last = (int32_t)pg.lines.size() - 1; }
    t.rows++;
  }
  int availCols(const Tbl &t) const { int a = (curR - curL - (t.border ? 6 : 0)) / CHAR_W; return a > COLS ? COLS : a; }
  void emitOne(Tbl &t, std::vector<Cell> &cs) {
    int n = (int)cs.size();
    int avail = availCols(t);
    if (n == 1) {
      if (!t.border) { uint8_t sa = alignM; if (cs[0].align >= 0) alignM = (uint8_t)cs[0].align; replayCell(cs[0]); blockBreak(false); alignM = sa; return; }
      int w1[1] = {avail}; emitRow(t, cs, w1, 1); return;
    }
    int W = avail - (n - 1);
    if (n > 4 || W < n * 3) { for (int i = 0; i < n; i++) { if (i) literalWord("|"); replayCell(cs[i]); } blockBreak(false); return; }
    int w[4];
    if (t.nGrid == n) { for (int i = 0; i < n; i++) w[i] = t.gridW[i]; }
    else { std::vector<const std::vector<Cell> *> one(1, &cs); gridWidths(one, n, W, w); }
    emitRow(t, cs, w, n);
  }
  // Rows are held back (up to 10) so the column widths can be chosen from all of them together.
  void flushBuf(Tbl &t) {
    if (t.gridDone) return;
    t.gridDone = true;
    int n = 0;
    for (auto &r : t.buf) if (r.size() >= 2 && r.size() <= 4) { n = (int)r.size(); break; }
    int W = availCols(t) - (n - 1);
    if (n >= 2 && W >= n * 3) {
      std::vector<const std::vector<Cell> *> rs;
      for (auto &r : t.buf) if ((int)r.size() == n) rs.push_back(&r);
      gridWidths(rs, n, W, t.gridW); t.nGrid = n;
    }
    std::vector<std::vector<Cell>> rows; rows.swap(t.buf);
    for (auto &r : rows) emitOne(t, r);
  }
  void emitCaptured(Tbl &t) {
    std::vector<Cell> cs; cs.swap(t.cells);
    bool any = false; size_t bytes = 0;
    for (auto &c : cs) { trimCell(c); if (!c.s.empty()) any = true; bytes += c.s.size(); }
    if (!any) return;
    if (t.gridDone) { emitOne(t, cs); return; }
    t.buf.push_back(std::move(cs)); t.bufBytes += bytes;
    if (t.buf.size() >= 10 || t.bufBytes > 2500) flushBuf(t);
  }
  void startRow() {
    if (tbN == 0 || tblOverflow > 0) { blockBreak(false); return; }
    endRow();
    Tbl &t = tb[tbN - 1];
    flushWord(); flushLine();
    t.rowOpen = true; t.cap = true; t.cellOpen = false; t.cells.clear(); t.capBytes = 0; t.capSp = false; t.cellSp = sp;
  }
  void endCell() {
    if (tbN == 0 || tblOverflow > 0) return;
    Tbl &t = tb[tbN - 1];
    while (sp > t.cellSp) popCtx();
    t.cellOpen = false;
  }
  void endRow() {
    if (tbN == 0 || tblOverflow > 0) return;
    Tbl &t = tb[tbN - 1];
    if (!t.rowOpen) return;
    endCell();
    t.rowOpen = false;
    if (t.cap) { t.cap = false; emitCaptured(t); } else blockBreak(false);
  }
  void startCell(bool th, int align) {
    if (tbN == 0 || tblOverflow > 0) { if (col > 0 || wn > 0) literalWord("|"); return; }
    Tbl &t = tb[tbN - 1];
    if (!t.rowOpen) startRow(); else endCell();
    t.cellSp = sp;
    if (t.cap) { Cell c; c.th = th; c.align = (int8_t)align; t.cells.push_back(c); t.capSp = false; }
    else if (col > 0 || wn > 0) literalWord("|");
    t.cellOpen = true;
  }
  void openTable(bool border) {
    abortCapture();
    blockBreak(true);
    if (tbN < 4) { Tbl &t = tb[tbN++]; t = Tbl(); t.spBase = sp; t.border = border; }
    else tblOverflow++;
  }
  void closeTable() {
    if (tblOverflow > 0) { tblOverflow--; return; }
    if (tbN == 0) return;
    endRow();
    flushBuf(tb[tbN - 1]);
    while (sp > tb[tbN - 1].spBase) popCtx();
    tbN--;
  }
  void closeAll() {
    tblOverflow = 0;
    while (tbN > 0) closeTable();
    while (sp > 0) popCtx();
  }
  // ---- tags ----
  static bool getAttr(const std::string &t, const char *name, std::string &out) {
    size_t i = 0, n = t.size();
    while (i < n && !isspace((unsigned char)t[i]) && t[i] != '/') i++;   // skip tag name
    while (i < n) {
      while (i < n && (isspace((unsigned char)t[i]) || t[i] == '/')) i++;
      size_t s = i;
      while (i < n && !isspace((unsigned char)t[i]) && t[i] != '=' && t[i] != '/') i++;
      std::string an = lower(t.substr(s, i - s));
      while (i < n && isspace((unsigned char)t[i])) i++;
      std::string val;
      if (i < n && t[i] == '=') {
        i++;
        while (i < n && isspace((unsigned char)t[i])) i++;
        if (i < n && (t[i] == '"' || t[i] == '\'')) { char qc = t[i++]; size_t vs = i; while (i < n && t[i] != qc) i++; val = t.substr(vs, i - vs); if (i < n) i++; }
        else { size_t vs = i; while (i < n && !isspace((unsigned char)t[i])) i++; val = t.substr(vs, i - vs); }
      }
      if (an == name) { out = val; return true; }
    }
    return false;
  }
  static std::string decodeAttr(const std::string &v) {
    std::string o;
    for (size_t i = 0; i < v.size(); i++) {
      if (v[i] == '&') {
        if (v.compare(i, 5, "&amp;") == 0) { o += '&'; i += 4; continue; }
        if (v.compare(i, 4, "&lt;") == 0) { o += '<'; i += 3; continue; }
        if (v.compare(i, 4, "&gt;") == 0) { o += '>'; i += 3; continue; }
        if (v.compare(i, 6, "&quot;") == 0) { o += '"'; i += 5; continue; }
        if (v.compare(i, 5, "&#38;") == 0) { o += '&'; i += 4; continue; }
      }
      o += v[i];
    }
    return o;
  }
  static bool isIn(const std::string &n, const char *list) { // comma separated, with commas at ends
    std::string k = "," + n + ","; return strstr(list, k.c_str()) != nullptr;
  }

  // ---- styling hints (inline style, a few class names, a few attributes) ----
  struct Fx { int8_t align = -1; uint8_t bx = 0; bool hide = false, cbox = false, btn = false, tblBorder = false; };
  static std::string trimS(const std::string &s) {
    size_t a = s.find_first_not_of(" \t\r\n"); if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n"); return s.substr(a, b - a + 1);
  }
  static bool isFillColor(const std::string &v) {
    if (v.empty()) return false;
    static const char *no[] = {"none", "transparent", "inherit", "initial", "unset", "white", "#fff", "#ffffff", "#fefefe", "rgb(255,255,255)", "rgb(255, 255, 255)", "url(", "linear", "radial", "var(", "currentcolor"};
    for (const char *s : no) if (v.compare(0, strlen(s), s) == 0) return false;
    return true;
  }
  static bool noBorder(const std::string &v) { return v.empty() || v[0] == '0' || v.compare(0, 4, "none") == 0 || v.find("transparent") != std::string::npos || v.compare(0, 6, "hidden") == 0; }
  static void parseStyle(const std::string &st, Fx &fx) {
    std::string s = lower(st); size_t i = 0;
    while (i < s.size()) {
      size_t e = s.find(';', i); if (e == std::string::npos) e = s.size();
      std::string d = s.substr(i, e - i); i = e + 1;
      size_t c = d.find(':'); if (c == std::string::npos) continue;
      std::string p = trimS(d.substr(0, c)), v = trimS(d.substr(c + 1));
      if (p == "text-align") { if (v.compare(0, 6, "center") == 0) fx.align = 1; else if (v.compare(0, 5, "right") == 0 || v.compare(0, 3, "end") == 0) fx.align = 2; else if (v.compare(0, 4, "left") == 0 || v.compare(0, 5, "start") == 0) fx.align = 0; }
      else if (p == "display") { if (v.compare(0, 4, "none") == 0) fx.hide = true; }
      else if (p == "visibility") { if (v.compare(0, 6, "hidden") == 0) fx.hide = true; }
      else if (p == "border") { if (!noBorder(v)) fx.bx |= BX_BORDER; }
      else if (p == "background" || p == "background-color") { if (isFillColor(v)) fx.bx |= BX_FILL; }
    }
  }
  static void classFx(const std::string &cls, Fx &fx) {
    static const char *HIDE = ",hidden,d-none,sr-only,visually-hidden,screen-reader-text,skip-link,mw-jump-link,mw-editsection,u-hidden,is-hidden,invisible,";
    static const char *RIGHT = ",text-right,text-end,alignright,has-text-align-right,pull-right,float-right,float-end,";
    static const char *BOXC = ",card,box,panel,alert,notice,callout,message,note,well,infobox,hatnote,ambox,mbox,navbox,warning,info,error,success,jumbotron,toast,notification,thumbinner,";
    static const char *TBLC = ",wikitable,bordered,table-bordered,infobox,";
    size_t i = 0;
    while (i < cls.size()) {
      while (i < cls.size() && isspace((unsigned char)cls[i])) i++;
      size_t s = i; while (i < cls.size() && !isspace((unsigned char)cls[i])) i++;
      if (i == s) break;
      std::string t = cls.substr(s, i - s);
      if (isIn(t, HIDE)) fx.hide = true;
      if (t.find("center") != std::string::npos && t.find("items") == std::string::npos && t.find("vertical") == std::string::npos && t.find("middle") == std::string::npos) { if (fx.align < 0) fx.align = 1; }
      else if (isIn(t, RIGHT)) { if (fx.align < 0) fx.align = 2; }
      if (isIn(t, BOXC)) fx.cbox = true;
      if (isIn(t, TBLC)) fx.tblBorder = true;
      if (t == "btn" || t == "button" || t == "badge" || t == "pill" || t == "chip" || t == "cta" || t.compare(0, 4, "btn-") == 0 || t.compare(0, 7, "button-") == 0) fx.btn = true;
    }
  }
  Fx fxOf() const {
    Fx fx; std::string v;
    if (getAttr(tag, "align", v)) { v = lower(v); if (v == "center" || v == "middle") fx.align = 1; else if (v == "right") fx.align = 2; else if (v == "left") fx.align = 0; }
    if (getAttr(tag, "hidden", v)) fx.hide = true;
    if (getAttr(tag, "bgcolor", v) && isFillColor(lower(v))) fx.bx |= BX_FILL;
    if (getAttr(tag, "style", v)) parseStyle(decodeAttr(v), fx);
    if (getAttr(tag, "class", v)) classFx(lower(decodeAttr(v)), fx);
    return fx;
  }

  // ---- form controls drawn as boxes ----
  int alignOff(int widthPx) const { int sp2 = (curR - curL) - widthPx; if (sp2 < 0) sp2 = 0; return alignM == 1 ? sp2 / 2 : alignM == 2 ? sp2 : 0; }
  void controlBox(const std::string &label, bool dim, uint8_t kind, int minCols, int nLines) {
    abortCapture(); blockBreak(false);
    int sL = curL, sR = curR;
    int bi = openBox(kind, true);
    int cols = maxC();
    std::string t; for (char c : label) t += ((unsigned char)c >= 32 && (unsigned char)c < 127) ? c : '?';
    if ((int)t.size() > cols) t.resize(cols);
    while ((int)t.size() < minCols && (int)t.size() < cols) t += ' ';
    for (int k = 0; k < nLines; k++) {
      Line l; strncpy(l.text, t.c_str(), COLS); l.text[COLS] = 0;
      l.style = dim ? 3 : 0; l.w = (int16_t)(curR - curL); l.x = (int16_t)(curL + alignOff((int)t.size() * CHAR_W));
      pg.push(l);
    }
    if (bi >= 0) closeBox(bi);
    curL = sL; curR = sR;
  }
  void inputControl() {
    std::string type = "text", v, val, ph;
    if (getAttr(tag, "type", v)) type = lower(v);
    if (type == "hidden" || type == "image") return;
    getAttr(tag, "value", val); val = decodeAttr(val); getAttr(tag, "placeholder", ph); ph = decodeAttr(ph);
    if (type == "checkbox" || type == "radio") { abortCapture(); bool on = getAttr(tag, "checked", v); literalWord(type == "radio" ? (on ? "(o)" : "( )") : (on ? "[x]" : "[ ]")); return; }
    if (type == "submit" || type == "button" || type == "reset") {
      if (val.empty()) val = type == "reset" ? "Reset" : type == "button" ? "OK" : "Submit";
      controlBox(val, false, BX_BORDER | BX_FILL | BX_BTN, 0, 1); return;
    }
    int size = 14; if (getAttr(tag, "size", v) && atoi(v.c_str()) > 0) size = atoi(v.c_str());
    if (size < 8) size = 8;
    if (size > COLS - 2) size = COLS - 2;
    if (type == "password") val.assign(val.size(), '*');
    bool dim = val.empty();
    controlBox(dim ? ph : val, dim, BX_BORDER | BX_FILL | BX_INPUT, size, 1);
  }
  void textareaBox() { controlBox("", true, BX_BORDER | BX_FILL | BX_INPUT, 16, 3); }

  void handleTag() {
    bool closing = tag[0] == '/';
    size_t s = closing ? 1 : 0, e = s;
    while (e < tag.size() && !isspace((unsigned char)tag[e]) && tag[e] != '/') e++;
    std::string name = lower(tag.substr(s, e - s));
    if (name.empty()) return;

    static const char *SKIP = ",svg,template,select,noscript,iframe,object,canvas,video,audio,textarea,";
    if (isIn(name, SKIP)) {
      if (closing) { if (skipDepth > 0) skipDepth--; }
      else { if (name == "textarea" && skipDepth == 0 && hidDepth == 0) textareaBox(); if (tag.back() != '/') skipDepth++; }
      return;
    }
    if (name == "script" || name == "style") {
      if (!closing) { st = RAW; rawEnd = "</" + name; rawWin.clear(); }
      return;
    }
    if (hidDepth > 0) {                                   // inside a display:none / hidden element
      if (name == hidName) { if (closing) { if (--hidDepth == 0) skipDepth--; } else if (tag.back() != '/') hidDepth++; }
      return;
    }
    if (skipDepth > 0) return;
    Fx fx; if (!closing) fx = fxOf();
    if (fx.hide) {
      static const char *VOIDS = ",br,hr,img,input,meta,link,base,wbr,col,area,source,track,html,body,head,";
      if (!isIn(name, VOIDS) && tag.back() != '/') { hidName = name; hidDepth = 1; skipDepth++; return; }
    }
    if (name == "title") { inTitle = !closing; if (!closing) pg.title.clear(); return; }
    if (name == "br") {
      if (capActive()) { capBreak(); return; }
      flushWord();
      if (col > 0) flushLine();
      else if (!pg.lines.empty() && pg.lines.back().kind != 3) { wantGap = true; gapIfWanted(); }
      return;
    }
    if (name == "a") {
      if (closing) { curLink = 0; popTo(T_A); return; }
      std::string href;
      if (getAttr(tag, "href", href)) curLink = addLink(decodeAttr(href)); else curLink = 0;
      uint8_t bx = fx.btn ? (uint8_t)(BX_BORDER | BX_FILL | BX_BTN) : (uint8_t)(fx.bx & (BX_BORDER | BX_FILL));
      if (bx) { blockBreak(false); Ctx *c = pushCtx(T_A); if (c) c->box = openBox(bx, true); }
      return;
    }
    if (name == "base") { std::string h; if (!closing && getAttr(tag, "href", h)) { std::string r = resolveUrl(pg.base, decodeAttr(h)); if (!r.empty()) pg.base = r; } return; }
    if (name == "img") { if (!closing) image(); return; }
    if (name == "hr") {
      abortCapture(); blockBreak(false);
      Line l; l.kind = 2; l.h = 5; l.text[0] = 0; l.x = (int16_t)curL; l.w = (int16_t)(curR - curL);
      gapIfWanted(); pg.push(l); return;
    }
    if (name == "input") { if (!closing) inputControl(); return; }
    if (name == "button") {
      if (closing) { popTo(T_BTN); blockBreak(false); return; }
      abortCapture(); blockBreak(false);
      Ctx *c = pushCtx(T_BTN); if (c) c->box = openBox(BX_BORDER | BX_FILL | BX_BTN, true);
      return;
    }
    if (name == "table") {
      if (closing) { closeTable(); blockBreak(true); return; }
      std::string v; bool bd = fx.tblBorder || (fx.bx & BX_BORDER);
      if (getAttr(tag, "border", v)) bd = v.empty() ? true : atoi(v.c_str()) > 0;
      openTable(bd); return;
    }
    if (name == "tr") { if (closing) endRow(); else startRow(); return; }
    if (name == "td" || name == "th") { if (closing) endCell(); else startCell(name == "th", fx.align); return; }
    if (name == "li") {
      if (closing) { popTo(T_LI); return; }
      abortCapture();
      if (topIs(T_LI)) popCtx();
      blockBreak(false);
      char b[12];
      if (olDepth > 0 && olStack[olDepth - 1] >= 0) snprintf(b, sizeof b, "%d.", ++olStack[olDepth - 1]); else strcpy(b, "*");
      int hang = (int)strlen(b) + 1;
      Ctx *c = pushCtx(T_LI);
      if (c && (curR - curL) - hang * CHAR_W >= 5 * CHAR_W) { bulletL = curL; bulletHang = hang; strncpy(bulletText, b, 7); bulletText[7] = 0; curL += hang * CHAR_W; bulletPend = true; }
      else literalWord(b);
      return;
    }
    if (name == "ul" || name == "ol") {
      if (closing) { popTo(T_UL); if (olDepth > 0) olDepth--; blockBreak(olDepth == 0); return; }
      abortCapture();
      blockBreak(olDepth == 0);
      pushCtx(T_UL);
      if (olDepth < 8) olStack[olDepth++] = (name == "ol") ? 0 : -1;
      return;
    }
    if (name == "dd") {
      if (closing) { popTo(T_DD); return; }
      if (topIs(T_DD)) popCtx();
      blockBreak(false);
      Ctx *c = pushCtx(T_DD); if (c && (curR - curL) > 10 * CHAR_W) curL += 2 * CHAR_W;
      return;
    }
    if (name == "pre") {
      if (closing) { popTo(T_PRE); pre = false; style = 0; blockBreak(true); return; }
      abortCapture(); blockBreak(true);
      Ctx *c = pushCtx(T_PRE); alignM = 0;
      if (c) c->box = openBox(BX_FILL, false);
      pre = true; style = 2; skipNl = true;
      return;
    }
    if (name.size() == 2 && name[0] == 'h' && name[1] >= '1' && name[1] <= '6') {
      blockBreak(true);
      if (closing) { popTo(T_H); style = 0; return; }
      style = 1;
      uint8_t bx = (uint8_t)(fx.bx & (BX_BORDER | BX_FILL));
      if (fx.align >= 0 || bx) { Ctx *c = pushCtx(T_H); if (c) { if (fx.align >= 0) alignM = (uint8_t)fx.align; if (bx) c->box = openBox(bx, false); } }
      return;
    }
    static const char *GAP = ",p,blockquote,form,figure,dl,";
    static const char *BLK = ",div,section,article,header,footer,main,aside,nav,dt,address,details,summary,fieldset,center,figcaption,legend,body,caption,";
    bool gap = isIn(name, GAP);
    if (!gap && !isIn(name, BLK)) return;
    uint8_t id = 0;
    if (name == "center") id = T_CENTER; else if (name == "blockquote") id = T_BQ; else if (name == "p") id = T_P;
    else if (name == "form") id = T_FORM; else if (name == "fieldset") id = T_FSET;
    else if (name == "div" || name == "section" || name == "article" || name == "header" || name == "footer" || name == "main" || name == "aside" || name == "nav" || name == "figure" || name == "dl" || name == "details") id = T_DIV;
    if (closing) { if (id) popTo(id); blockBreak(gap); return; }
    if (name == "p" && topIs(T_P)) popCtx();
    if (name == "dt" && topIs(T_DD)) popCtx();
    blockBreak(gap);
    uint8_t bx = 0;
    if (id == T_FSET) bx = BX_BORDER;
    else if (id == T_DIV || id == T_P || id == T_FORM || id == T_CENTER) { bx = (uint8_t)(fx.bx & (BX_BORDER | BX_FILL)); if (!bx && fx.cbox) bx = BX_BORDER | BX_FILL; }
    bool always = id == T_DIV || id == T_CENTER || id == T_BQ || id == T_FORM || id == T_FSET;
    if (id && (always || fx.align >= 0 || bx)) {
      Ctx *c = pushCtx(id);
      if (c) {
        if (id == T_CENTER) alignM = 1;
        if (fx.align >= 0) alignM = (uint8_t)fx.align;
        if (id == T_BQ) c->box = openBox(BX_BAR, false);
        else if (bx) c->box = openBox(bx, false);
      }
    }
  }

  void image() {
    std::string src, alt, ws, hs;
    getAttr(tag, "src", src);
    std::string ds; if (getAttr(tag, "data-src", ds) && !ds.empty()) { if (src.empty() || src.rfind("data:", 0) == 0) src = ds; }
    getAttr(tag, "alt", alt);
    alt = decodeAttr(alt);
    bool tiny = false;
    if (getAttr(tag, "width", ws) && atoi(ws.c_str()) > 0 && atoi(ws.c_str()) <= 3) tiny = true;
    if (getAttr(tag, "height", hs) && atoi(hs.c_str()) > 0 && atoi(hs.c_str()) <= 3) tiny = true;
    if (tiny) return;
    std::string full = resolveUrl(pg.base, decodeAttr(src));
    std::string pathOnly = lower(full.substr(0, full.find('?')));
    auto ends = [&](const char *x) { size_t l = strlen(x); return pathOnly.size() >= l && pathOnly.compare(pathOnly.size() - l, l, x) == 0; };
    bool unsupported = full.empty() || ends(".svg") || ends(".gif") || ends(".webp") || ends(".ico") || ends(".avif") || ends(".bmp");
    if (unsupported || pg.imgs.size() >= pg.maxImgs) {
      if (!alt.empty()) { std::string t = "[" + alt.substr(0, 30) + "]"; for (char c : t) { if ((unsigned char)c >= 32 && (unsigned char)c < 127) textChar(c); } flushWord(); }
      return;
    }
    abortCapture();                                       // an image needs its own line: no column layout for this row
    blockBreak(false);
    Line l; l.kind = 1; l.h = LINE_H; l.link = curLink; l.style = 3;
    l.x = (int16_t)curL; l.w = (int16_t)(curR - curL);
    l.img = (int16_t)pg.imgs.size();
    std::string label = "[img";
    if (!alt.empty()) label += ": " + alt;
    label += "]";
    size_t k = 0; for (char c : label) { if (k >= (size_t)maxC()) break; l.text[k++] = ((unsigned char)c >= 32 && (unsigned char)c < 127) ? c : '?'; }
    l.text[k] = 0;
    gapIfWanted();
    Img im; im.url = full; im.alt = alt; im.line = (int)pg.lines.size();
    if (pg.push(l)) pg.imgs.push_back(im);
  }
};

// ---------------------------------------------------------------- rendering
static const uint16_t COL_BG = C565(0, 0, 0);
static uint16_t colText()  { return C565(225, 225, 225); }
static uint16_t colHead()  { return C565(255, 210, 60); }
static uint16_t colPre()   { return C565(150, 225, 150); }
static uint16_t colDim()   { return C565(130, 130, 130); }
static uint16_t colLink()  { return C565(90, 200, 255); }
static uint16_t colHover() { return C565(0, 70, 160); }

static int findLine(const Page &p, int32_t y) {
  int lo = 0, hi = (int)p.lines.size() - 1, r = -1;
  while (lo <= hi) { int m = (lo + hi) / 2; if (p.lines[m].y <= y) { r = m; lo = m + 1; } else hi = m - 1; }
  return r;
}

static int imgX(const Line &L, const Img &im) {
  int x = L.x + (L.w - im.w) / 2;
  if (x + im.w > SCR_W) x = SCR_W - im.w;
  if (x < 0) x = 0;
  return x;
}

static int linkAt(const Page &p, int32_t scroll, int sx, int sy) {
  if (sy < 0 || sy >= VIEW_H) return 0;
  int32_t y = scroll + sy;
  int i = findLine(p, y);
  if (i < 0) return 0;
  const Line &L = p.lines[i];
  if (y >= L.y + L.h) return 0;
  if (L.kind == 1) {
    if (!L.link) return 0;
    const Img &im = p.imgs[L.img];
    int w = im.state == 1 ? im.w : (int)strlen(L.text) * CHAR_W;
    int x0 = im.state == 1 ? imgX(L, im) : L.x;
    return (sx >= x0 && sx < x0 + w) ? L.link : 0;
  }
  if (L.kind == 0 && L.lk) {
    int col = (sx - L.x) / CHAR_W;
    if (sx >= L.x && col >= 0 && col < (int)strlen(L.text)) return L.lk[col];
  }
  return 0;
}

// ---- boxes (drawn behind the text) ----
static void viewH(int x0, int x1, int y, uint16_t c) { if (y < 0 || y >= VIEW_H) return; for (int x = x0; x <= x1; x++) gPx(x, y, c); }
static void viewV(int x, int y0, int y1, uint16_t c) { if (y0 < 0) y0 = 0; if (y1 >= VIEW_H) y1 = VIEW_H - 1; for (int y = y0; y <= y1; y++) gPx(x, y, c); }
static void drawBoxes(const Page &p, int32_t scroll) {
  for (const Box &b : p.boxes) {
    if (!b.kind || b.last < b.first || b.last >= (int32_t)p.lines.size()) continue;
    int y0 = (int)(p.lines[b.first].y - scroll);
    int y1 = (int)(p.lines[b.last].y + p.lines[b.last].h - 1 - scroll);
    if (y1 < 0 || y0 >= VIEW_H) continue;
    int x0 = b.x0, x1 = b.x1;
    bool btn = b.kind & BX_BTN, inp = b.kind & BX_INPUT;
    uint16_t edge = btn ? C565(90, 140, 220) : inp ? C565(150, 150, 160) : C565(105, 105, 115);
    uint16_t fill = btn ? C565(28, 42, 78) : inp ? C565(8, 8, 12) : C565(26, 26, 32);
    if (b.kind & BX_FILL) gFill(x0, y0 < 0 ? 0 : y0, x1 - x0 + 1, (y1 >= VIEW_H ? VIEW_H - 1 : y1) - (y0 < 0 ? 0 : y0) + 1, fill);
    if (b.kind & BX_BAR) { viewV(x0 + 1, y0, y1, C565(120, 120, 135)); viewV(x0 + 2, y0, y1, C565(120, 120, 135)); }
    if (b.kind & BX_BORDER) {
      int k = btn ? 1 : 0;                                     // buttons get rounded corners
      if (b.kind & BX_TOP) viewH(x0 + k, x1 - k, y0, edge);
      viewH(x0 + k, x1 - k, y1, edge);
      viewV(x0, y0 + k, y1 - k, edge); viewV(x1, y0 + k, y1 - k, edge);
      for (int s = 0; s < b.nsep; s++) viewV(x0 + b.sep[s], y0, y1, edge);
    }
  }
}

static void renderPage(const Page &p, int32_t scroll, int hover) {
  gFill(0, 0, SCR_W, VIEW_H, COL_BG);
  drawBoxes(p, scroll);
  int i = findLine(p, scroll);
  if (i < 0) i = 0;
  for (; i < (int)p.lines.size(); i++) {
    const Line &L = p.lines[i];
    int y = L.y - scroll;
    if (y >= VIEW_H) break;
    if (y + L.h <= 0) continue;
    if (L.kind == 3 || L.kind == 4) continue;
    if (L.kind == 2) { gFill(L.x, y + 2, L.w, 1, colDim()); continue; }
    if (L.kind == 1) {
      const Img &im = p.imgs[L.img];
      if (im.state == 1 && im.px) {
        int x0 = imgX(L, im);
        for (int r = 0; r < im.h; r++) {
          int sy = y + 1 + r; if (sy < 0 || sy >= VIEW_H) continue;
          memcpy(g_fb + sy * SCR_W + x0, im.px + r * im.w, im.w * 2);
        }
        if (L.link && L.link == hover) {
          for (int x = x0 - 1; x <= x0 + im.w; x++) { gPx(x, y, colLink()); gPx(x, y + im.h + 1, colLink()); }
          for (int r = 0; r <= im.h + 1; r++) { gPx(x0 - 1, y + r, colLink()); gPx(x0 + im.w, y + r, colLink()); }
        }
      } else {
        uint16_t c = im.state == 2 ? C565(200, 90, 90) : colDim();
        gText(L.x, y, L.text, (L.link ? colLink() : c), COLS);
      }
      continue;
    }
    uint16_t base = L.style == 1 ? colHead() : L.style == 2 ? colPre() : L.style == 3 ? colDim() : colText();
    int n = (int)strlen(L.text);
    for (int k = 0; k < n; k++) {
      int x = L.x + k * CHAR_W;
      uint16_t lk = L.lk ? L.lk[k] : 0;
      if (lk && lk == hover) { gFill(x, y, CHAR_W, LINE_H - 1, colHover()); gChar(x, y, L.text[k], C565(255, 255, 255)); gFill(x, y + 8, CHAR_W, 1, colLink()); }
      else if (lk) { gChar(x, y, L.text[k], colLink()); gFill(x, y + 8, CHAR_W - 1, 1, colLink()); }
      else if (L.text[k] != ' ') gChar(x, y, L.text[k], base);
    }
  }
  if (p.totalH > VIEW_H) {
    int th = VIEW_H * VIEW_H / p.totalH; if (th < 4) th = 4;
    int ty = (int)((int64_t)scroll * (VIEW_H - th) / (p.totalH - VIEW_H));
    gFill(SCR_W - 1, ty, 1, th, C565(110, 110, 110));
  }
}

// ---- dark theme for pictures ----
// Pictures that sit on a white background (logos, diagrams, screenshots of text) would glow on the black page.
// Flat graphics get their lightness flipped (white <-> black, colours kept); photos on a white background only
// have the white turned black; ordinary photos are left alone.
static void darkenImage(uint16_t *px, int w, int h) {
  if (!px || w < 4 || h < 4) return;
  auto Y = [](uint16_t p) { uint16_t v = (uint16_t)((p >> 8) | (p << 8)); int r = (v >> 11) << 3, g = ((v >> 5) & 63) << 2, b = (v & 31) << 3; return (r * 77 + g * 150 + b * 29) >> 8; };
  int lightEdge = 0, edgeN = 0;
  for (int x = 0; x < w; x++) { lightEdge += Y(px[x]) >= 200; lightEdge += Y(px[(h - 1) * w + x]) >= 200; edgeN += 2; }
  for (int y = 1; y < h - 1; y++) { lightEdge += Y(px[y * w]) >= 200; lightEdge += Y(px[y * w + w - 1]) >= 200; edgeN += 2; }
  if (lightEdge * 100 < edgeN * 70) return;                       // does not sit on a light background
  int mid = 0, n = 0;
  for (int i = 0; i < w * h; i += 3) { int y = Y(px[i]); mid += (y > 45 && y < 205); n++; }
  bool flat = mid * 100 < n * 45;
  for (int i = 0; i < w * h; i++) {
    uint16_t v = (uint16_t)((px[i] >> 8) | (px[i] << 8));
    int r = (v >> 11) << 3, g = ((v >> 5) & 63) << 2, b = (v & 31) << 3;
    int y = (r * 77 + g * 150 + b * 29) >> 8;
    if (flat) {
      int d = 255 - 2 * y;
      r += d; g += d; b += d;
      r = r < 0 ? 0 : r > 255 ? 255 : r; g = g < 0 ? 0 : g > 255 ? 255 : g; b = b < 0 ? 0 : b > 255 ? 255 : b;
    } else {
      int mx = r > g ? (r > b ? r : b) : (g > b ? g : b), mn = r < g ? (r < b ? r : b) : (g < b ? g : b);
      int t = (y - 205) * 255 / 45; if (t < 0) t = 0; if (t > 255) t = 255;     // only near-white ...
      t = t * (255 - (mx - mn)) / 255;                                           // ... and only if unsaturated
      r = r * (255 - t) / 255; g = g * (255 - t) / 255; b = b * (255 - t) / 255;
    }
    px[i] = C565((uint8_t)r, (uint8_t)g, (uint8_t)b);
  }
}

static void drawCursor(int cx, int cy) {
  static const char *A[14] = {
    "X.........", "XX........", "XWX.......", "XWWX......", "XWWWX.....", "XWWWWX....", "XWWWWWX...",
    "XWWWWWWX..", "XWWWWXXXX.", "XWXXWX....", "XX.XWX....", "X...XWX...", "....XWX...", ".....XX..."};
  for (int y = 0; y < 14; y++) for (int x = 0; x < 10; x++) {
    char c = A[y][x];
    if (c == 'X') gPx(cx + x, cy + y, C565(0, 0, 0));
    else if (c == 'W') gPx(cx + x, cy + y, C565(255, 255, 255));
  }
}

static void drawStatus(const char *text) {
  gFill(0, VIEW_H, SCR_W, STATUS_H, C565(0, 40, 90));
  gText(1, VIEW_H + 1, text, C565(255, 255, 255), COLS);
}
