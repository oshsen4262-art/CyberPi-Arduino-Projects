// Png.h - streaming PNG decoder (own inflate, 32 KB window) that box-filters down to screen size.
// Not supported: interlaced (Adam7) PNG, 16-bit palettes (do not exist).
#pragma once
#include "Common.h"

struct ByteSink { virtual void put(uint8_t b) = 0; virtual ~ByteSink() {} };

class Inflater {
public:
  bool failed = false;
  // Decode a zlib stream. Input is pulled from 'in', output pushed to 'sink'.
  bool run(ByteSource &in_, ByteSink &sink_) {
    in = &in_; sink = &sink_; bitbuf = 0; bitcnt = 0; wpos = 0; failed = false;
    win = (uint8_t *)g_bigAlloc(32768);
    if (!win) return false;
    int cmf = in->read(), flg = in->read();
    if (cmf < 0 || flg < 0 || (cmf & 15) != 8 || ((cmf << 8) | flg) % 31 != 0 || (flg & 0x20)) { free(win); return false; }
    bool final;
    do {
      final = getBit();
      int type = getBits(2);
      bool ok;
      if (type == 0) ok = stored();
      else if (type == 1) { fixedTrees(); ok = codes(); }
      else if (type == 2) ok = dynamicTrees() && codes();
      else ok = false;
      if (!ok || failed) { free(win); return false; }
    } while (!final);
    free(win);
    return true;
  }

private:
  struct Tree { uint16_t table[16]; uint16_t trans[288]; };
  ByteSource *in = nullptr; ByteSink *sink = nullptr;
  uint8_t *win = nullptr; uint32_t wpos = 0;
  uint32_t bitbuf = 0; int bitcnt = 0;
  Tree lt, dt;

  inline int getBit() {
    if (bitcnt == 0) { int b = in->read(); if (b < 0) { failed = true; b = 0; } bitbuf = (uint32_t)b; bitcnt = 8; }
    int v = bitbuf & 1; bitbuf >>= 1; bitcnt--; return v;
  }
  inline int getBits(int n) { int v = 0; for (int i = 0; i < n; i++) v |= getBit() << i; return v; }
  inline void emit(uint8_t b) { win[wpos++ & 32767] = b; sink->put(b); }

  static void build(Tree *t, const uint8_t *lengths, unsigned num) {
    uint16_t offs[16]; unsigned sum = 0;
    memset(t->table, 0, sizeof(t->table));
    for (unsigned i = 0; i < num; i++) t->table[lengths[i]]++;
    t->table[0] = 0;
    for (int i = 0; i < 16; i++) { offs[i] = (uint16_t)sum; sum += t->table[i]; }
    for (unsigned i = 0; i < num; i++) if (lengths[i]) t->trans[offs[lengths[i]]++] = (uint16_t)i;
  }
  int decodeSym(const Tree *t) {
    int sum = 0, cur = 0, len = 0;
    do {
      cur = 2 * cur + getBit(); len++;
      if (len > 15 || failed) { failed = true; return -1; }
      sum += t->table[len]; cur -= t->table[len];
    } while (cur >= 0);
    return t->trans[sum + cur];
  }
  void fixedTrees() {
    uint8_t l[288];
    for (int i = 0; i < 144; i++) l[i] = 8;
    for (int i = 144; i < 256; i++) l[i] = 9;
    for (int i = 256; i < 280; i++) l[i] = 7;
    for (int i = 280; i < 288; i++) l[i] = 8;
    build(&lt, l, 288);
    uint8_t d[30]; for (int i = 0; i < 30; i++) d[i] = 5;
    build(&dt, d, 30);
  }
  bool dynamicTrees() {
    static const uint8_t order[19] = {16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
    int hlit = getBits(5) + 257, hdist = getBits(5) + 1, hclen = getBits(4) + 4;
    if (hlit > 286 || hdist > 30) return false;
    uint8_t lens[320]; memset(lens, 0, sizeof(lens));
    for (int i = 0; i < hclen; i++) lens[order[i]] = (uint8_t)getBits(3);
    Tree cl; build(&cl, lens, 19);
    int n = 0, total = hlit + hdist;
    uint8_t all[320]; memset(all, 0, sizeof(all));
    while (n < total) {
      int sym = decodeSym(&cl);
      if (sym < 0) return false;
      if (sym < 16) all[n++] = (uint8_t)sym;
      else {
        int prev = 0, rep;
        if (sym == 16) { if (n == 0) return false; prev = all[n - 1]; rep = 3 + getBits(2); }
        else if (sym == 17) rep = 3 + getBits(3);
        else rep = 11 + getBits(7);
        if (n + rep > total) return false;
        while (rep--) all[n++] = (uint8_t)prev;
      }
    }
    build(&lt, all, hlit);
    build(&dt, all + hlit, hdist);
    return true;
  }
  bool stored() {
    bitcnt = 0;
    int l0 = in->read(), l1 = in->read(), n0 = in->read(), n1 = in->read();
    if (l0 < 0 || n1 < 0) return false;
    int len = l0 | (l1 << 8);
    for (int i = 0; i < len; i++) { int b = in->read(); if (b < 0) return false; emit((uint8_t)b); }
    return true;
  }
  bool codes() {
    static const uint16_t lb[29] = {3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
    static const uint8_t le[29] = {0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
    static const uint16_t db[30] = {1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
    static const uint8_t de[30] = {0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};
    for (;;) {
      int sym = decodeSym(&lt);
      if (sym < 0 || failed) return false;
      if (sym < 256) emit((uint8_t)sym);
      else if (sym == 256) return true;
      else {
        sym -= 257;
        if (sym >= 29) return false;
        int len = lb[sym] + getBits(le[sym]);
        int ds = decodeSym(&dt);
        if (ds < 0 || ds >= 30) return false;
        uint32_t dist = db[ds] + getBits(de[ds]);
        if (dist > wpos && wpos < 32768) return false;
        for (int i = 0; i < len; i++) emit(win[(wpos - dist) & 32767]);
      }
    }
  }
};

class PngDecoder : public ByteSink {
public:
  bool decode(ByteSource &src, ImgOut &out) {
    s = &src;
    out.err = nullptr;
    static const uint8_t sig[8] = {0x89, 'P', 'N', 'G', 13, 10, 26, 10};
    for (int i = 0; i < 8; i++) if (s->read() != sig[i]) { out.err = "not a png"; return false; }
    bool haveHdr = false;
    for (;;) {
      uint32_t len = rd32(); uint8_t t[4];
      for (int i = 0; i < 4; i++) { int b = s->read(); if (b < 0) { out.err = "truncated png"; return false; } t[i] = (uint8_t)b; }
      if (!memcmp(t, "IHDR", 4)) {
        if (len < 13) { out.err = "bad png"; return false; }
        W = rd32(); H = rd32();
        depth = s->read(); ctype = s->read(); s->read(); s->read(); int il = s->read();
        for (uint32_t i = 13; i < len; i++) s->read();
        rd32();
        if (il != 0) { out.err = "interlaced png"; return false; }
        if (W <= 0 || H <= 0 || W > 8192 || H > 32768) { out.err = "png too large"; return false; }
        int ch = ctype == 0 ? 1 : ctype == 2 ? 3 : ctype == 3 ? 1 : ctype == 4 ? 2 : ctype == 6 ? 4 : 0;
        if (!ch || (depth != 1 && depth != 2 && depth != 4 && depth != 8 && depth != 16)) { out.err = "bad png"; return false; }
        bitsPP = ch * depth;
        rb = (W * bitsPP + 7) / 8;
        bpp = bitsPP >= 8 ? bitsPP / 8 : 1;
        haveHdr = true;
      } else if (!memcmp(t, "PLTE", 4)) {
        for (uint32_t i = 0; i < len; i++) { int b = s->read(); if (i < 768) plte[i] = (uint8_t)b; }
        rd32();
      } else if (!memcmp(t, "tRNS", 4)) {
        for (uint32_t i = 0; i < len; i++) { int b = s->read(); if (i < 256) trns[i] = (uint8_t)b; }
        if (ctype == 3) trnsN = len < 256 ? len : 256;
        rd32();
      } else if (!memcmp(t, "IDAT", 4)) {
        if (!haveHdr) { out.err = "bad png"; return false; }
        if (!setup(out)) { out.err = "no memory"; return false; }
        idatLeft = len;
        IdatReader rdr(this);
        Inflater inf;
        bool ok = inf.run(rdr, *this);
        flushRow();
        if (!ok && y < H / 2) { out.err = "bad png data"; return false; }
        return true;   // partial images are still shown
      } else if (!memcmp(t, "IEND", 4)) {
        out.err = "no image data"; return false;
      } else {
        for (uint32_t i = 0; i < len; i++) if (s->read() < 0) { out.err = "truncated png"; return false; }
        rd32();
      }
    }
  }

  void put(uint8_t b) override {
    if (y >= H) return;
    raw[rp++] = b;
    if (rp == rb + 1) { processRow(); rp = 0; y++; }
  }

private:
  struct IdatReader : ByteSource {
    PngDecoder *d; bool done = false;
    IdatReader(PngDecoder *p) : d(p) {}
    int read() override {
      if (done) return -1;
      while (d->idatLeft == 0) {
        d->rd32();
        uint32_t len = d->rd32(); uint8_t t[4];
        for (int i = 0; i < 4; i++) { int b = d->s->read(); if (b < 0) { done = true; return -1; } t[i] = (uint8_t)b; }
        if (memcmp(t, "IDAT", 4)) { done = true; return -1; }
        d->idatLeft = len;
      }
      d->idatLeft--;
      int b = d->s->read();
      if (b < 0) done = true;
      return b;
    }
  };
  ByteSource *s = nullptr;
  int W = 0, H = 0, depth = 8, ctype = 0, bitsPP = 8, rb = 0, bpp = 1;
  uint32_t idatLeft = 0;
  uint8_t plte[768] = {0}, trns[256]; int trnsN = 0;
  uint8_t *raw = nullptr, *prev = nullptr;
  int rp = 0, y = 0;
  int dw = 0, dh = 0;
  std::vector<uint8_t> xmap;
  std::vector<uint32_t> aR, aG, aB, aN;
  int curDy = -1;
  uint16_t *dst = nullptr;
  std::vector<uint8_t> rawStore, prevStore;

  uint32_t rd32() { uint32_t v = 0; for (int i = 0; i < 4; i++) { int b = s->read(); v = (v << 8) | (b < 0 ? 0 : b); } return v; }

  bool setup(ImgOut &out) {
    fitDims(W, H, dw, dh);
    out.w = dw; out.h = dh;
    out.px = (uint16_t *)g_bigAlloc((size_t)dw * dh * 2);
    if (!out.px) return false;
    for (int i = 0; i < dw * dh; i++) out.px[i] = 0xFFFF;
    dst = out.px;
    rawStore.assign(rb + 1, 0); prevStore.assign(rb, 0);
    raw = rawStore.data(); prev = prevStore.data();
    xmap.resize(W);
    for (int x = 0; x < W; x++) xmap[x] = (uint8_t)((int64_t)x * dw / W);
    aR.assign(dw, 0); aG.assign(dw, 0); aB.assign(dw, 0); aN.assign(dw, 0);
    // note: every PNG with truncated IDAT still shows what was decoded
    memset(trns, 255, sizeof(trns));
    return true;
  }

  static inline int paeth(int a, int b, int c) {
    int p = a + b - c, pa = abs(p - a), pb = abs(p - b), pc = abs(p - c);
    return (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c);
  }

  void flushRow() {
    if (curDy < 0) return;
    uint16_t *row = dst + curDy * dw;
    for (int i = 0; i < dw; i++) {
      if (aN[i]) row[i] = C565((uint8_t)(aR[i] / aN[i]), (uint8_t)(aG[i] / aN[i]), (uint8_t)(aB[i] / aN[i]));
      aR[i] = aG[i] = aB[i] = aN[i] = 0;
    }
    curDy = -1;
  }

  void processRow() {
    int f = raw[0];
    uint8_t *cur = raw + 1;
    for (int i = 0; i < rb; i++) {
      int a = i >= bpp ? cur[i - bpp] : 0, b = prev[i], c = i >= bpp ? prev[i - bpp] : 0;
      switch (f) {
        case 1: cur[i] = (uint8_t)(cur[i] + a); break;
        case 2: cur[i] = (uint8_t)(cur[i] + b); break;
        case 3: cur[i] = (uint8_t)(cur[i] + ((a + b) >> 1)); break;
        case 4: cur[i] = (uint8_t)(cur[i] + paeth(a, b, c)); break;
        default: break;
      }
    }
    int dy = (int)((int64_t)y * dh / H);
    if (dy != curDy) { flushRow(); curDy = dy; }
    for (int x = 0; x < W; x++) {
      int r, g, b, al = 255;
      pixel(cur, x, r, g, b, al);
      if (al != 255) { r = (r * al + 255 * (255 - al)) / 255; g = (g * al + 255 * (255 - al)) / 255; b = (b * al + 255 * (255 - al)) / 255; }
      int dx = xmap[x];
      aR[dx] += r; aG[dx] += g; aB[dx] += b; aN[dx]++;
    }
    memcpy(prev, cur, rb);
  }

  inline void pixel(const uint8_t *row, int x, int &r, int &g, int &b, int &al) {
    switch (ctype) {
      case 0: {
        int v;
        if (depth == 8) v = row[x];
        else if (depth == 16) v = row[2 * x];
        else { int per = 8 / depth, sh = 8 - depth * (x % per + 1); v = (row[x / per] >> sh) & ((1 << depth) - 1); v = v * 255 / ((1 << depth) - 1); }
        r = g = b = v; break;
      }
      case 2:
        if (depth == 8) { r = row[3 * x]; g = row[3 * x + 1]; b = row[3 * x + 2]; }
        else { r = row[6 * x]; g = row[6 * x + 2]; b = row[6 * x + 4]; }
        break;
      case 3: {
        int idx;
        if (depth == 8) idx = row[x];
        else { int per = 8 / depth, sh = 8 - depth * (x % per + 1); idx = (row[x / per] >> sh) & ((1 << depth) - 1); }
        r = plte[idx * 3]; g = plte[idx * 3 + 1]; b = plte[idx * 3 + 2];
        if (idx < trnsN) al = trns[idx];
        break;
      }
      case 4:
        if (depth == 8) { r = g = b = row[2 * x]; al = row[2 * x + 1]; }
        else { r = g = b = row[4 * x]; al = row[4 * x + 2]; }
        break;
      default:
        if (depth == 8) { r = row[4 * x]; g = row[4 * x + 1]; b = row[4 * x + 2]; al = row[4 * x + 3]; }
        else { r = row[8 * x]; g = row[8 * x + 2]; b = row[8 * x + 4]; al = row[8 * x + 6]; }
        break;
    }
  }
};
