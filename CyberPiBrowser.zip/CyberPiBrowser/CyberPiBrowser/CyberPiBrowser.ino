/*
 * CyberPi Browser - a tiny web browser for the Makeblock CyberPi (ESP32, 128x128 screen)
 * -------------------------------------------------------------------------------------
 *   Joystick ........ moves the mouse pointer (hold it to go faster). Push the pointer
 *                     against the top/bottom edge of the screen to scroll the page.
 *   A ............... click (follow the link / image link under the pointer)
 *   B ............... open / close the PRESET LINKS list (joystick up/down + A to open one)
 *   Menu (home) ..... back (also stops a page that is still loading)
 *   Joystick press .. reload
 *
 * Edit the preset links from any phone/PC browser on the same WiFi: type the IP address shown
 * at the bottom of the B list (and on the start page) into the address bar. The same page lets
 * you open any address on the CyberPi, set the WiFi, and tune the display pins.
 *
 * First start: there is no WiFi yet, so the CyberPi makes its own WiFi network "CyberPi-Browser".
 * Join it with your phone, open http://192.168.4.1 and use "WiFi settings".
 *
 * Arduino IDE settings (same board as the controller sketch):
 *   Board: ESP32 Wrover Module     Partition Scheme: Huge APP (3MB No OTA/1MB SPIFFS) or default
 *   PSRAM: Enabled   (gives room for more images and longer pages; if the board does not start
 *                     with it enabled, choose Disabled - the browser still works, just smaller)
 *   Only libraries that come with the ESP32 board package are used. Nothing else to install.
 *
 * Supported: HTML text (headings, lists, tables as text, <pre>, links), HTTP and HTTPS,
 *            JPEG (baseline) and PNG (non-interlaced) images. Not supported: JavaScript, CSS,
 *            forms, GIF/WebP/SVG images, progressive JPEG (shown as [img: ...] text instead).
 */
#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <WebServer.h>
#include <Preferences.h>
#include <SPI.h>
#include <esp_bt.h>

#include "Common.h"
#include "Engine.h"
#include "Jpeg.h"
#include "Png.h"

// Forward declaration: the Arduino IDE auto-generates function prototypes near the top of the sketch,
// before the class body below, so the type must be known by name up there.
class HttpStream;

#ifdef SET_LOOP_TASK_STACK_SIZE
SET_LOOP_TASK_STACK_SIZE(16 * 1024);   // TLS needs more stack than the default 8 KB
#endif

// ======================================================================= settings you may edit
#define WIFI_SSID_DEFAULT ""            // optional: put your WiFi name here instead of using the web page
#define WIFI_PASS_DEFAULT ""
#define AP_NAME           "CyberPi-Browser"
#define MAX_PRESETS       12
#define DEFAULT_LINKS \
  "Example\thttp://example.com\n" \
  "First website (CERN)\thttp://info.cern.ch\n" \
  "NPR text news\thttps://text.npr.org\n" \
  "CNN lite\thttps://lite.cnn.com\n" \
  "Wikipedia\thttps://en.m.wikipedia.org/wiki/Main_Page\n" \
  "Hacker News\thttps://news.ycombinator.com\n"

// ======================================================================= CyberPi buttons (AW9523B on I2C)
#define I2C_SDA        19
#define I2C_SCL        18
#define AW_ADDR        0x58
#define P0_LEFT   0
#define P0_UP     1
#define P0_RIGHT  2
#define P0_CENTER 3
#define P0_DOWN   4
#define P0_B      5
#define P0_A      6
#define P1_MENU   0
enum : uint16_t { B_UP = 1 << 0, B_DOWN = 1 << 1, B_LEFT = 1 << 2, B_RIGHT = 1 << 3,
                  B_CENTER = 1 << 4, B_A = 1 << 5, B_B = 1 << 6, B_MENU = 1 << 7 };

static bool awWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(AW_ADDR); Wire.write(reg); Wire.write(val);
  return Wire.endTransmission() == 0;
}
static bool awRead(uint8_t reg, uint8_t &val) {
  Wire.beginTransmission(AW_ADDR); Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)AW_ADDR, 1) != 1) return false;
  val = Wire.read(); return true;
}
static bool expanderInit() {
  uint8_t id = 0; bool ok = awRead(0x10, id);
  Serial.printf("I/O expander: %s (ID 0x%02X, expected 0x23)\n", ok ? "found" : "NOT FOUND", id);
  awWrite(0x7F, 0x00); delay(10);
  awWrite(0x12, 0xFF); awWrite(0x13, 0xF9); awWrite(0x11, 0x00);
  awWrite(0x04, 0xFF); awWrite(0x05, 0x4F); awWrite(0x03, 0x00);   // P1.4/P1.5/P1.7 = outputs (LCD DC, RESET, backlight)
  return ok;
}
static bool readButtons(uint16_t &out) {
  uint8_t p0, p1;
  if (!awRead(0x00, p0) || !awRead(0x01, p1)) return false;
  uint16_t b = 0;
  if (!(p0 & (1 << P0_UP)))     b |= B_UP;
  if (!(p0 & (1 << P0_DOWN)))   b |= B_DOWN;
  if (!(p0 & (1 << P0_LEFT)))   b |= B_LEFT;
  if (!(p0 & (1 << P0_RIGHT)))  b |= B_RIGHT;
  if (!(p0 & (1 << P0_CENTER))) b |= B_CENTER;
  if (!(p0 & (1 << P0_A)))      b |= B_A;
  if (!(p0 & (1 << P0_B)))      b |= B_B;
  if (!(p1 & (1 << P1_MENU)))   b |= B_MENU;
  out = b; return true;
}

// ======================================================================= display (ST7735S 128x128)
// CyberPi LCD wiring (taken from the working CyberPi Doom sketch): the SPI lines are real ESP32 pins
// (MOSI 2, SCLK 4, CS 12) but DC, RESET and BACKLIGHT sit on the AW9523B I/O expander, not on ESP32 pins.
// A pin number of 100 + n means "expander pin n" (P1.4 = 112, P1.5 = 113, P1.7 = 115).
// If the screen still misbehaves, open http://<ip>/hw (via the CyberPi-Browser WiFi) and change them.
#define HW_VER 2
struct HwCfg { uint8_t ver; int8_t mosi, sclk, cs, dc, rst, bl; uint8_t blHigh, blExp, xoff, yoff, madctl, invert; };
static HwCfg hw = { HW_VER, 2, 4, 12, 112, 113, 115, 1, 0, 3, 2, 0xA0, 0 };

static SPIClass *lcdSpi = nullptr;
static bool lcdUp = false;
static uint32_t holdTestUntil = 0;

static uint8_t expP1 = 0;                       // shadow of the expander's port-1 output register
static inline void pw(int pin, int v) {
  if (pin < 0) return;
  if (pin >= 100) {                             // I/O expander pin (100 + AW9523B pin number)
    int b = pin - 100 - 8; if (b < 0 || b > 7) return;   // only port 1 (P1.0 - P1.7) is used for the LCD
    uint8_t n = v ? (expP1 | (1 << b)) : (expP1 & ~(1 << b));
    if (n != expP1) { expP1 = n; awWrite(0x03, expP1); }
    return;
  }
  digitalWrite(pin, v);
}
static void lcdCmd(uint8_t c, const uint8_t *d = nullptr, int n = 0) {
  lcdSpi->beginTransaction(SPISettings(20000000, MSBFIRST, SPI_MODE0));
  pw(hw.cs, LOW); pw(hw.dc, LOW); lcdSpi->transfer(c);
  if (n) { pw(hw.dc, HIGH); lcdSpi->writeBytes(d, n); }
  pw(hw.cs, HIGH); lcdSpi->endTransaction();
}
static void lcdBegin() {
  if (lcdSpi) { lcdSpi->end(); delete lcdSpi; lcdSpi = nullptr; }
  int pins[] = { hw.cs, hw.dc, hw.rst, hw.bl };
  for (int p : pins) if (p >= 0 && p < 100) pinMode(p, OUTPUT);
  pw(hw.cs, HIGH);
  lcdSpi = new SPIClass(HSPI);
  lcdSpi->begin(hw.sclk, -1, hw.mosi, -1);
  if (hw.rst >= 0) { pw(hw.rst, HIGH); delay(10); pw(hw.rst, LOW); delay(20); pw(hw.rst, HIGH); delay(120); }
  lcdCmd(0x01); delay(150);                      // software reset
  lcdCmd(0x11); delay(150);                      // sleep out
  { const uint8_t d[] = {0x01, 0x2C, 0x2D}; lcdCmd(0xB1, d, 3); lcdCmd(0xB2, d, 3); }
  { const uint8_t d[] = {0x01, 0x2C, 0x2D, 0x01, 0x2C, 0x2D}; lcdCmd(0xB3, d, 6); }
  { const uint8_t d[] = {0x07}; lcdCmd(0xB4, d, 1); }
  { const uint8_t d[] = {0xA2, 0x02, 0x84}; lcdCmd(0xC0, d, 3); }
  { const uint8_t d[] = {0xC5}; lcdCmd(0xC1, d, 1); }
  { const uint8_t d[] = {0x0A, 0x00}; lcdCmd(0xC2, d, 2); }
  { const uint8_t d[] = {0x8A, 0x2A}; lcdCmd(0xC3, d, 2); }
  { const uint8_t d[] = {0x8A, 0xEE}; lcdCmd(0xC4, d, 2); }
  { const uint8_t d[] = {0x0E}; lcdCmd(0xC5, d, 1); }
  lcdCmd(hw.invert ? 0x21 : 0x20);
  { const uint8_t d[] = {hw.madctl}; lcdCmd(0x36, d, 1); }
  { const uint8_t d[] = {0x05}; lcdCmd(0x3A, d, 1); }
  { const uint8_t d[] = {0x02,0x1C,0x07,0x12,0x37,0x32,0x29,0x2D,0x29,0x25,0x2B,0x39,0x00,0x01,0x03,0x10}; lcdCmd(0xE0, d, 16); }
  { const uint8_t d[] = {0x03,0x1D,0x07,0x06,0x2E,0x2C,0x29,0x2D,0x2E,0x2E,0x37,0x3F,0x00,0x00,0x02,0x10}; lcdCmd(0xE1, d, 16); }
  lcdCmd(0x13); delay(10);
  lcdCmd(0x29); delay(100);
  pw(hw.bl, hw.blHigh ? HIGH : LOW);
  if (hw.blExp) awWrite(0x03, 0xFF);             // legacy option, off by default (it would also drive DC/RESET high)
  lcdUp = true;
}
static void lcdPush() {
  if (!lcdUp || !g_fb) return;
  uint8_t c[4] = {0, (uint8_t)hw.xoff, 0, (uint8_t)(hw.xoff + SCR_W - 1)};
  uint8_t r[4] = {0, (uint8_t)hw.yoff, 0, (uint8_t)(hw.yoff + SCR_H - 1)};
  lcdCmd(0x2A, c, 4); lcdCmd(0x2B, r, 4);
  lcdSpi->beginTransaction(SPISettings(20000000, MSBFIRST, SPI_MODE0));
  pw(hw.cs, LOW); pw(hw.dc, LOW); lcdSpi->transfer(0x2C); pw(hw.dc, HIGH);
  lcdSpi->writeBytes((const uint8_t *)g_fb, SCR_W * SCR_H * 2);
  pw(hw.cs, HIGH); lcdSpi->endTransaction();
}
static void lcdTestPattern() {
  gFill(0, 0, SCR_W, SCR_H, C565(0, 0, 0));
  gFill(0, 0, 32, 40, C565(255, 0, 0)); gFill(32, 0, 32, 40, C565(0, 255, 0));
  gFill(64, 0, 32, 40, C565(0, 0, 255)); gFill(96, 0, 32, 40, C565(255, 255, 255));
  gFill(0, SCR_H - 3, SCR_W, 3, C565(255, 255, 0)); gFill(0, 0, 1, SCR_H, C565(255, 0, 255));
  gFill(SCR_W - 1, 0, 1, SCR_H, C565(0, 255, 255));
  gText(4, 50, "DISPLAY TEST", C565(255, 255, 255));
  gText(4, 62, "R G B W bars above", C565(200, 200, 200));
  gText(4, 74, "edges: magenta/cyan", C565(200, 200, 200));
  gText(4, 86, "yellow = bottom", C565(200, 200, 200));
  lcdPush();
}

// ======================================================================= state
static Preferences prefs;
struct Preset { String t, u; };
static std::vector<Preset> presets;
static WebServer server(80);
static bool psram = false, wantAP = false;

static Page *page = nullptr;
static std::vector<std::string> hist;
static int32_t scrollY = 0;
static int cx = SCR_W / 2, cy = VIEW_H / 2;
static bool menuOpen = false; static int menuSel = 0;
static bool dirty = true;
static uint32_t lastRender = 0;
static char statusMsg[40] = "";
static volatile bool g_abort = false;
static bool navPending = false, navPush = true; static std::string navUrl;
static size_t imgBytes = 0;

static bool netOK() { return WiFi.status() == WL_CONNECTED; }
static String ipStr() { return netOK() ? WiFi.localIP().toString() : WiFi.softAPIP().toString(); }
static void setStatus(const char *s) { strncpy(statusMsg, s, sizeof(statusMsg) - 1); statusMsg[sizeof(statusMsg) - 1] = 0; dirty = true; }

static void *psAlloc(size_t n) { void *p = psram ? ps_malloc(n) : nullptr; return p ? p : malloc(n); }

static void setCaps(Page &p) {
  p.maxLines = psram ? 2500 : 700; p.maxLinks = psram ? 2500 : 500; p.maxImgs = psram ? 12 : 6;
}

// ======================================================================= presets
static String sanitize(String s) { s.replace("\t", " "); s.replace("\n", " "); s.replace("\r", " "); s.trim(); return s; }
static void loadPresets() {
  presets.clear();
  String s = prefs.getString("links", DEFAULT_LINKS);
  int pos = 0;
  while (pos < (int)s.length() && presets.size() < MAX_PRESETS) {
    int nl = s.indexOf('\n', pos); if (nl < 0) nl = s.length();
    String line = s.substring(pos, nl); pos = nl + 1;
    int tab = line.indexOf('\t'); if (tab < 0) continue;
    Preset p; p.t = line.substring(0, tab); p.u = line.substring(tab + 1);
    if (p.u.length()) presets.push_back(p);
  }
}
static void savePresets() {
  String s;
  for (auto &p : presets) { s += sanitize(p.t); s += '\t'; s += sanitize(p.u); s += '\n'; }
  prefs.putString("links", s);
}

// ======================================================================= HTTP client (HTTP + HTTPS, redirects, chunked)
static void uiTick();

class HttpStream : public ByteSource {
public:
  int status = 0; std::string ctype, finalUrl;
  ~HttpStream() { close(); }
  void close() {
    if (tls) { tls->stop(); delete tls; tls = nullptr; }
    if (plain) { plain->stop(); delete plain; plain = nullptr; }
    cl = nullptr;
  }
  void unread(int c) { pb = c; }

  bool open(std::string url, std::string &err) {
    for (int hop = 0; hop < 6; hop++) {
      Url u;
      if (!parseUrl(url, u)) { err = "bad address"; return false; }
      close(); bpos = blen = 0; done = false; chunked = false; remaining = -1; chunkLeft = 0; pb = -2;
      if (u.scheme == "https") { tls = new WiFiClientSecure; tls->setInsecure(); cl = tls; }
      else { plain = new WiFiClient; cl = plain; }
      setStatus("Connecting...");
      if (!cl->connect(u.host.c_str(), u.port)) { err = "cannot connect"; close(); return false; }
      String req = "GET " + String(u.path.c_str()) + " HTTP/1.1\r\nHost: " + String(u.host.c_str());
      if ((u.scheme == "http" && u.port != 80) || (u.scheme == "https" && u.port != 443)) req += ":" + String(u.port);
      req += "\r\nUser-Agent: Mozilla/5.0 (X11; Linux x86_64) CyberPiBrowser/1.0\r\n"
             "Accept: text/html,image/jpeg,image/png,text/plain;q=0.9,*/*;q=0.5\r\n"
             "Accept-Encoding: identity\r\nAccept-Language: en\r\nConnection: close\r\n\r\n";
      cl->print(req);
      setStatus("Waiting...");
      std::string line;
      if (!readLine(line)) { err = g_abort ? "stopped" : "no answer"; close(); return false; }
      size_t sp = line.find(' ');
      status = sp == std::string::npos ? 0 : atoi(line.c_str() + sp + 1);
      if (status < 100) { err = "bad answer"; close(); return false; }
      std::string location, enc; ctype.clear();
      for (;;) {
        if (!readLine(line)) { err = "truncated"; close(); return false; }
        if (line.empty()) break;
        size_t c = line.find(':'); if (c == std::string::npos) continue;
        std::string k = lower(line.substr(0, c)), v = line.substr(c + 1);
        size_t a = v.find_first_not_of(" \t"); v = a == std::string::npos ? "" : v.substr(a);
        if (k == "location") location = v;
        else if (k == "content-type") ctype = v;
        else if (k == "content-length") remaining = atol(v.c_str());
        else if (k == "transfer-encoding" && lower(v).find("chunked") != std::string::npos) chunked = true;
        else if (k == "content-encoding") enc = lower(v);
      }
      if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
        std::string nu = resolveUrl(url, location);
        if (nu.empty()) { err = "bad redirect"; close(); return false; }
        url = nu; continue;
      }
      if (!enc.empty() && enc != "identity") { err = "compressed reply"; close(); return false; }
      if (chunked) remaining = -1;
      finalUrl = url;
      return true;
    }
    err = "too many redirects"; close(); return false;
  }

  int read() override {
    if (pb >= 0) { int c = pb; pb = -2; return c; }
    if (done || g_abort) return -1;
    if ((++count & 0xFFF) == 0) uiTick();
    if (chunked) {
      if (chunkLeft <= 0 && !nextChunk()) { done = true; return -1; }
      chunkLeft--; return rawRead();
    }
    if (remaining >= 0) { if (remaining == 0) { done = true; return -1; } remaining--; }
    return rawRead();
  }

private:
  WiFiClient *cl = nullptr, *plain = nullptr; WiFiClientSecure *tls = nullptr;
  uint8_t buf[1024]; int bpos = 0, blen = 0, pb = -2;
  bool chunked = false, done = false; long remaining = -1, chunkLeft = 0; uint32_t count = 0;

  int rawRead() {
    if (bpos >= blen) {
      uint32_t t0 = millis();
      for (;;) {
        if (g_abort) return -1;
        int av = cl->available();
        if (av > 0) { int n = cl->read(buf, av < (int)sizeof(buf) ? av : (int)sizeof(buf)); if (n > 0) { blen = n; bpos = 0; break; } }
        else if (!cl->connected()) return -1;
        if (millis() - t0 > 12000) return -1;
        uiTick(); delay(1);
      }
    }
    return buf[bpos++];
  }
  bool readLine(std::string &out) {
    out.clear();
    for (;;) {
      int c = rawRead();
      if (c < 0) return false;
      if (c == '\n') return true;
      if (c != '\r' && out.size() < 2000) out += (char)c;
    }
  }
  bool nextChunk() {
    std::string line;
    do { if (!readLine(line)) return false; } while (line.empty());
    long n = strtol(line.c_str(), nullptr, 16);
    if (n <= 0) return false;
    chunkLeft = n; return true;
  }
};

// ======================================================================= images
static void imageLineUpdate(Page &pg, int i) {
  Img &im = pg.imgs[i];
  if (im.line < 0 || im.line >= (int)pg.lines.size()) return;
  Line &L = pg.lines[im.line];
  uint16_t newH = im.state == 1 ? (uint16_t)(im.h + 3) : (uint16_t)LINE_H;
  int delta = (int)newH - (int)L.h;
  if (L.y + L.h <= scrollY) scrollY += delta;        // keep what you are reading in place
  L.h = newH;
  pg.relayout();
  dirty = true;
}
static void imageFail(Page &pg, int i, const char *why) {
  Img &im = pg.imgs[i]; im.state = 2;
  if (im.line >= 0 && im.line < (int)pg.lines.size()) {
    char t[COLS + 1]; snprintf(t, sizeof t, "[img: %s]", why);
    strncpy(pg.lines[im.line].text, t, COLS); pg.lines[im.line].text[COLS] = 0;
  }
  dirty = true;
}
// Decode an image from an open stream into pg.imgs[i].
static bool decodeStream(Page &pg, int i, HttpStream &h) {
  int c = h.read();
  if (c < 0) { imageFail(pg, i, g_abort ? "stopped" : "empty"); return false; }
  h.unread(c);
  ImgOut o; bool ok = false;
  if (c == 0xFF) { JpegDecoder *d = new JpegDecoder; ok = d->decode(h, o); delete d; }
  else if (c == 0x89) { PngDecoder *d = new PngDecoder; ok = d->decode(h, o); delete d; }
  else o.err = "unsupported type";
  if (g_abort) { if (o.px) free(o.px); return false; }
  if (ok && o.px) {
    darkenImage(o.px, o.w, o.h);                      // dark theme: white-background pictures no longer glow
    Img &im = pg.imgs[i]; im.px = o.px; im.w = o.w; im.h = o.h; im.state = 1;
    imgBytes += (size_t)o.w * o.h * 2;
    imageLineUpdate(pg, i); return true;
  }
  if (o.px) free(o.px);
  imageFail(pg, i, o.err ? o.err : "failed");
  return false;
}
static void loadImages(Page &pg) {
  size_t budget = psram ? 1500000 : 60000;
  for (size_t i = 0; i < pg.imgs.size(); i++) {
    if (g_abort) return;
    if (imgBytes + 30000 > budget) { imageFail(pg, (int)i, "no memory left"); continue; }
    char s[32]; snprintf(s, sizeof s, "Image %u/%u", (unsigned)i + 1, (unsigned)pg.imgs.size()); setStatus(s);
    HttpStream *h = new HttpStream; std::string err;
    if (h->open(pg.imgs[i].url, err)) decodeStream(pg, (int)i, *h);
    else if (!g_abort) imageFail(pg, (int)i, err.c_str());
    delete h;
    uiTick();
  }
}

// ======================================================================= pages
static std::string esc(const std::string &s) {
  std::string o; for (char c : s) { if (c == '<') o += "&lt;"; else if (c == '>') o += "&gt;"; else if (c == '&') o += "&amp;"; else if (c == '"') o += "&quot;"; else o += c; } return o;
}
static void errorPage(Page &pg, const std::string &msg, const std::string &url) {
  HtmlParser hp(pg);
  hp.feedString("<h3>Cannot open page</h3><p>" + esc(msg) + "</p><p>" + esc(url) + "</p><hr><p>MENU = back, B = presets, joystick press = try again.</p>");
  hp.finish();
}
static void buildHome(Page &pg) {
  HtmlParser hp(pg);
  std::string h = "<h2>CyberPi Browser</h2><p>Joystick = mouse, A = click, B = presets, MENU = back, stick press = reload.</p>";
  if (netOK()) h += "<p>WiFi: " + esc(WiFi.SSID().c_str()) + "<br>Edit links from a browser at http://" + std::string(ipStr().c_str()) + "</p>";
  else h += "<h3>No internet yet</h3><p>Join the WiFi network " AP_NAME " with your phone, open http://" + std::string(WiFi.softAPIP().toString().c_str()) + " and set your WiFi under WiFi settings.</p>";
  h += "<hr><h3>Preset links</h3><ul>";
  for (auto &p : presets) h += "<li><a href=\"" + esc(p.u.c_str()) + "\">" + esc(p.t.c_str()) + "</a></li>";
  h += "</ul>";
  hp.feedString(h);
  hp.finish();
}

static void navigate(const std::string &url, bool pushHist) {
  g_abort = false; navPending = false;
  if (pushHist && page && !page->url.empty()) { hist.push_back(page->url); if (hist.size() > 12) hist.erase(hist.begin()); }
  delete page; page = new Page(); setCaps(*page);
  imgBytes = 0; page->url = url; page->base = url; scrollY = 0; cx = SCR_W / 2; cy = VIEW_H / 2; menuOpen = false;
  if (url == "about:home") { buildHome(*page); setStatus(""); dirty = true; return; }
  if (!netOK()) { errorPage(*page, "No internet connection (WiFi not connected).", url); setStatus("No WiFi"); return; }
  setStatus("Loading...");
  HttpStream *h = new HttpStream; std::string err;
  if (!h->open(url, err)) {
    delete h;
    if (!g_abort) { errorPage(*page, err, url); setStatus("Error"); }
    return;
  }
  page->url = h->finalUrl; page->base = h->finalUrl;
  std::string ct = lower(h->ctype);
  Serial.printf("GET %s -> %d %s  heap %u\n", url.c_str(), h->status, ct.c_str(), (unsigned)ESP.getFreeHeap());
  if (ct.rfind("image/", 0) == 0) {
    Img im; im.url = h->finalUrl; im.line = 0; page->imgs.push_back(im);
    Line l; l.kind = 1; l.img = 0; l.style = 3; strcpy(l.text, "[img]"); page->push(l);
    decodeStream(*page, 0, *h);
  } else if (ct.empty() || ct.find("html") != std::string::npos || ct.rfind("text/", 0) == 0 || ct.find("xml") != std::string::npos) {
    HtmlParser hp(*page);
    if (ct.rfind("text/plain", 0) == 0) hp.startPlain();
    size_t n = 0; int c;
    while ((c = h->read()) >= 0) {
      hp.feed((uint8_t)c);
      if (page->truncated || g_abort || ++n > 1500000) break;
      if ((n & 0x3FF) == 0) { char s[32]; snprintf(s, sizeof s, "Loading %uK", (unsigned)(n / 1024)); setStatus(s); uiTick(); }
    }
    hp.finish();
    if (h->status >= 400) { char s[32]; snprintf(s, sizeof s, "HTTP %d", h->status); setStatus(s); }
    h->close();
    if (!g_abort) { delete h; h = nullptr; loadImages(*page); }
  } else {
    errorPage(*page, "Cannot show this type: " + h->ctype, url);
  }
  delete h;
  if (!g_abort) setStatus("");
  dirty = true;
}

static void requestNav(const std::string &url, bool push = true) {
  if (url.empty()) return;
  navUrl = url; navPush = push; navPending = true; g_abort = true;
  setStatus("Opening...");
}

// ======================================================================= rendering + input
static void drawMenu() {
  gFill(2, 2, SCR_W - 4, VIEW_H - 2, C565(15, 15, 40));
  gFill(2, 2, SCR_W - 4, 10, C565(0, 90, 170));
  gText(5, 3, "Presets  B=close", C565(255, 255, 255));
  int n = (int)presets.size() + 1, vis = 9;
  int first = menuSel - 4; if (first > n - vis) first = n - vis; if (first < 0) first = 0;
  for (int r = 0; r < vis && first + r < n; r++) {
    int idx = first + r, y = 14 + r * 10;
    bool sel = idx == menuSel;
    if (sel) gFill(3, y - 1, SCR_W - 6, 10, C565(0, 90, 170));
    String t = idx == 0 ? String("[Start page]") : presets[idx - 1].t;
    gText(5, y, t.c_str(), sel ? C565(255, 255, 255) : colLink(), 20);
  }
  String ip = "http://" + ipStr();
  gFill(2, VIEW_H - 11, SCR_W - 4, 10, C565(0, 50, 0));
  gText(4, VIEW_H - 10, ip.c_str(), C565(200, 255, 200), 20);
}

static void render() {
  if (!g_fb) return;
  if ((int32_t)(holdTestUntil - millis()) > 0) return;   // keep the display test visible for a few seconds
  dirty = false; lastRender = millis();
  int hover = 0;
  if (page) {
    hover = menuOpen ? 0 : linkAt(*page, scrollY, cx, cy);
    renderPage(*page, scrollY, hover);
  } else gFill(0, 0, SCR_W, SCR_H, COL_BG);
  if (menuOpen) drawMenu(); else drawCursor(cx, cy);
  char st[48];
  if (hover && page) {
    std::string u = resolveUrl(page->base, page->links[hover]);
    size_t p = u.find("://"); if (p != std::string::npos) u.erase(0, p + 3);
    snprintf(st, sizeof st, "%s", u.c_str());
  } else if (statusMsg[0]) snprintf(st, sizeof st, "%s", statusMsg);
  else if (page && !page->title.empty()) snprintf(st, sizeof st, "%s", page->title.c_str());
  else snprintf(st, sizeof st, "%s", page ? "" : "CyberPi Browser");
  drawStatus(st);
  lcdPush();
}

static void handleInput() {
  static uint32_t last = 0; static uint16_t prevB = 0; static int held = 0;
  uint32_t now = millis();
  if (now - last < 16) return;
  last = now;
  uint16_t b = 0;
  if (!readButtons(b)) return;
  uint16_t pressed = b & ~prevB; prevB = b;
  int dx = ((b & B_RIGHT) ? 1 : 0) - ((b & B_LEFT) ? 1 : 0);
  int dy = ((b & B_DOWN) ? 1 : 0) - ((b & B_UP) ? 1 : 0);
  if (dx || dy) held++; else held = 0;

  if (pressed & B_B) { menuOpen = !menuOpen; menuSel = 0; dirty = true; }
  if (pressed & B_MENU) {
    if (menuOpen) { menuOpen = false; dirty = true; }
    else if (!hist.empty()) { std::string u = hist.back(); hist.pop_back(); requestNav(u, false); }
    else if (page && page->url != "about:home") requestNav("about:home", false);
  }
  if (menuOpen) {
    int n = (int)presets.size() + 1;
    if (dy && (held == 1 || (held > 25 && held % 6 == 0))) { menuSel = (menuSel + dy + n) % n; dirty = true; }
    if (pressed & B_A) {
      menuOpen = false;
      if (menuSel == 0) requestNav("about:home"); else requestNav(presets[menuSel - 1].u.c_str());
      dirty = true;
    }
    return;
  }
  if (pressed & B_CENTER) { if (page && !page->url.empty()) requestNav(page->url, false); }
  if (pressed & B_A) {
    int l = page ? linkAt(*page, scrollY, cx, cy) : 0;
    if (l) requestNav(resolveUrl(page->base, page->links[l]));
  }
  if (dx || dy) {
    int step = 1 + held / 8; if (step > 5) step = 5;
    const int EDGE = 6;
    cx += dx * step; if (cx < 0) cx = 0; if (cx > SCR_W - 2) cx = SCR_W - 2;
    int32_t maxScroll = page && page->totalH > VIEW_H ? page->totalH - VIEW_H : 0;
    if (dy < 0) { if (cy > EDGE) { cy -= step; if (cy < EDGE) cy = EDGE; } else { scrollY -= step * 2; if (scrollY < 0) scrollY = 0; } }
    if (dy > 0) { if (cy < VIEW_H - EDGE - 1) { cy += step; if (cy > VIEW_H - EDGE - 1) cy = VIEW_H - EDGE - 1; } else { scrollY += step * 2; if (scrollY > maxScroll) scrollY = maxScroll; } }
    dirty = true;
  }
}

static void uiTick() {
  server.handleClient();
  handleInput();
  if (dirty || millis() - lastRender > 1000) render();
}

// ======================================================================= web page for editing presets / WiFi / display
static String hesc(const String &s) {
  String o; for (unsigned i = 0; i < s.length(); i++) { char c = s[i]; if (c == '<') o += "&lt;"; else if (c == '>') o += "&gt;"; else if (c == '&') o += "&amp;"; else if (c == '"') o += "&quot;"; else o += c; } return o;
}
static String shell(const String &body) {
  return String("<!doctype html><html><head><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>"
    "<title>CyberPi Browser</title><style>body{font-family:system-ui,sans-serif;max-width:680px;margin:0 auto;padding:12px;background:#111;color:#eee}"
    "input[type=text],input[type=password],input[type=number]{width:100%;box-sizing:border-box;padding:8px;margin:2px 0 8px;background:#222;color:#fff;border:1px solid #555;border-radius:6px}"
    "button{padding:10px 18px;border:0;border-radius:6px;background:#0a84ff;color:#fff;font-size:16px}a{color:#6cf}h1,h2{color:#fc3}"
    "table{width:100%}td{padding:0 4px 0 0;vertical-align:top}small{color:#9a9}.c{background:#1b1b1b;padding:10px;border-radius:8px;margin:12px 0}</style></head><body>") + body + "</body></html>";
}
static void redirectHome() { server.sendHeader("Location", "/"); server.send(303, "text/plain", ""); }

static void handleRoot() {
  String b = "<h1>CyberPi Browser</h1><p><small>";
  b += netOK() ? "WiFi: " + hesc(WiFi.SSID()) + " &middot; address " + ipStr() : String("Not connected to the internet. Set your WiFi below.");
  b += "</small></p><div class=c><h2>Open a page now</h2><form method=post action=/go><input type=text name=u placeholder='https://example.com'><button>Open on the CyberPi</button></form></div>";
  b += "<div class=c><h2>Preset links (B button)</h2><form method=post action=/save><table>";
  for (int i = 0; i < MAX_PRESETS; i++) {
    String t = i < (int)presets.size() ? presets[i].t : "", u = i < (int)presets.size() ? presets[i].u : "";
    b += "<tr><td width=35%><input type=text name=t" + String(i) + " value=\"" + hesc(t) + "\" placeholder=Name></td><td><input type=text name=u" + String(i) + " value=\"" + hesc(u) + "\" placeholder='https://...'></td></tr>";
  }
  b += "</table><small>Empty address = row removed. https:// is added if you leave it out.</small><br><br><button>Save presets</button></form></div>";
  b += "<p><a href=/wifi>WiFi settings</a> &nbsp; <a href=/hw>Display settings</a></p>";
  server.send(200, "text/html", shell(b));
}
static void handleSave() {
  presets.clear();
  for (int i = 0; i < MAX_PRESETS; i++) {
    String u = sanitize(server.arg("u" + String(i))), t = sanitize(server.arg("t" + String(i)));
    if (!u.length()) continue;
    if (u.indexOf("://") < 0) u = "https://" + u;
    if (!t.length()) { t = u; int p = t.indexOf("://"); if (p >= 0) t = t.substring(p + 3); }
    presets.push_back({t, u});
  }
  savePresets();
  if (page && page->url == "about:home") requestNav("about:home", false);
  redirectHome();
}
static void handleGo() {
  String u = sanitize(server.arg("u"));
  if (u.length()) { if (u.indexOf("://") < 0) u = "https://" + u; requestNav(u.c_str()); }
  redirectHome();
}
static void handleWifi() {
  String b = "<h1>WiFi settings</h1><form method=post action=/wifisave>Network name (SSID)<input type=text name=s value=\"" + hesc(prefs.getString("ssid", WIFI_SSID_DEFAULT)) + "\">Password<input type=password name=p><button>Save and restart</button></form><p><a href=/>Back</a></p>";
  server.send(200, "text/html", shell(b));
}
static void handleWifiSave() {
  prefs.putString("ssid", server.arg("s")); prefs.putString("pass", server.arg("p"));
  server.send(200, "text/html", shell("<h1>Saved</h1><p>Restarting. Wait 20 seconds, then look at the CyberPi screen for the new address.</p>"));
  delay(500); ESP.restart();
}
static bool pinOk(int p) {
  switch (p) { case -1: case 0: case 2: case 4: case 5: case 12: case 13: case 14: case 15: case 21: case 22: case 23: case 25: case 26: case 27: case 32: case 33: return true; default: return p >= 108 && p <= 115; }
}
static void handleHw() {
  auto f = [](const char *n, const char *label, int v) { return String("<label>") + label + "<input type=number name=" + n + " value=" + String(v) + "></label>"; };
  String b = "<h1>Display settings</h1><p><small>If the CyberPi screen is dark, garbled, shifted or has wrong colours, change these and press Save &amp; test. "
             "A test pattern shows for 6 seconds. -1 means 'not used'. Allowed pins: 0 2 4 5 12 13 14 15 21 22 23 25 26 27 32 33, or 108-115 for I/O expander pins P1.0-P1.7 (CyberPi: DC = 112, RESET = 113, backlight = 115).</small></p><form method=post action=/hwsave>";
  b += f("mosi", "MOSI (data) pin", hw.mosi) + f("sclk", "SCLK (clock) pin", hw.sclk) + f("cs", "CS pin", hw.cs) + f("dc", "DC (data/command) pin", hw.dc);
  b += f("rst", "RESET pin", hw.rst) + f("bl", "Backlight pin", hw.bl) + f("xoff", "Column offset (0-5)", hw.xoff) + f("yoff", "Row offset (0-5)", hw.yoff);
  char mh[8]; snprintf(mh, sizeof mh, "%02X", hw.madctl);
  b += String("<label>MADCTL hex (C8 default, 08 / 68 / A8 / 00 if rotated or colours swapped)<input type=text name=mad value=") + mh + "></label>";
  b += String("<label><input type=checkbox name=inv ") + (hw.invert ? "checked" : "") + "> invert colours</label><br>";
  b += String("<label><input type=checkbox name=blh ") + (hw.blHigh ? "checked" : "") + "> backlight pin is active HIGH</label><br>";
  b += String("<label><input type=checkbox name=ble ") + (hw.blExp ? "checked" : "") + "> switch backlight on via the CyberPi I/O expander (P1.3)</label><br><br>";
  b += "<button>Save &amp; test</button></form><p><a href=/>Back</a></p>";
  server.send(200, "text/html", shell(b));
}
static void handleHwSave() {
  HwCfg n = hw;
  n.mosi = server.arg("mosi").toInt(); n.sclk = server.arg("sclk").toInt(); n.cs = server.arg("cs").toInt();
  n.dc = server.arg("dc").toInt(); n.rst = server.arg("rst").toInt(); n.bl = server.arg("bl").toInt();
  n.xoff = constrain(server.arg("xoff").toInt(), 0, 5); n.yoff = constrain(server.arg("yoff").toInt(), 0, 5);
  n.madctl = (uint8_t)strtol(server.arg("mad").c_str(), nullptr, 16);
  n.invert = server.hasArg("inv"); n.blHigh = server.hasArg("blh"); n.blExp = server.hasArg("ble");
  int ps[] = {n.mosi, n.sclk, n.cs, n.dc, n.rst, n.bl}; bool ok = true;
  for (int i = 0; i < 6; i++) { if (!pinOk(ps[i])) ok = false; for (int j = i + 1; j < 6; j++) if (ps[i] >= 0 && ps[i] == ps[j]) ok = false; }
  if (n.mosi < 0 || n.sclk < 0 || n.dc < 0) ok = false;
  if (!ok) { server.send(200, "text/html", shell("<h1>Not saved</h1><p>MOSI, SCLK and DC are required; pins must be from the allowed list and different from each other.</p><p><a href=/hw>Back</a></p>")); return; }
  hw = n; prefs.putBytes("hw", &hw, sizeof(hw));
  lcdBegin(); lcdTestPattern(); holdTestUntil = millis() + 6000; dirty = true;
  server.send(200, "text/html", shell("<h1>Saved</h1><p>Look at the CyberPi: a test pattern is showing (red, green, blue, white bars; coloured edges). "
    "If it looks wrong, go back and adjust.</p><p><a href=/hw>Back to display settings</a> &middot; <a href=/>Home</a></p>"));
}

// ======================================================================= setup / loop
static void splash(const char *a, const char *b = "", const char *c = "") {
  if (!g_fb) return;
  gFill(0, 0, SCR_W, SCR_H, COL_BG);
  gText(4, 6, "CyberPi Browser", C565(255, 210, 60));
  gText(4, 30, a, C565(255, 255, 255)); gText(4, 42, b, C565(200, 200, 200)); gText(4, 54, c, C565(200, 200, 200));
  lcdPush();
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\nCyberPi Browser");
  esp_bt_controller_mem_release(ESP_BT_MODE_BTDM);       // Bluetooth is not used: give its memory back
  psram = psramFound();
  g_bigAlloc = psAlloc;
  Serial.printf("PSRAM: %s, free heap %u\n", psram ? "yes" : "no", (unsigned)ESP.getFreeHeap());
  Wire.begin(I2C_SDA, I2C_SCL); Wire.setClock(400000);
  expanderInit();

  prefs.begin("cpbrowser", false);
  HwCfg saved;
  if (prefs.getBytes("hw", &saved, sizeof(saved)) == sizeof(saved) && saved.ver == HW_VER) hw = saved;
  loadPresets();

  g_fb = (uint16_t *)malloc(SCR_W * SCR_H * 2);
  lcdBegin();
  splash("Starting...");

  String ssid = prefs.getString("ssid", WIFI_SSID_DEFAULT), pass = prefs.getString("pass", WIFI_PASS_DEFAULT);
  if (ssid.length()) {
    WiFi.mode(WIFI_STA); WiFi.setAutoReconnect(true); WiFi.begin(ssid.c_str(), pass.c_str());
    splash("Connecting WiFi", ssid.c_str());
    for (int i = 0; i < 50 && !netOK(); i++) { delay(500); }
  }
  if (!netOK()) {
    wantAP = true;
    WiFi.mode(WIFI_AP_STA); WiFi.softAP(AP_NAME);
    if (ssid.length()) WiFi.begin(ssid.c_str(), pass.c_str());
  }
  server.on("/", HTTP_GET, handleRoot);
  server.on("/save", HTTP_POST, handleSave);
  server.on("/go", HTTP_POST, handleGo);
  server.on("/wifi", HTTP_GET, handleWifi);
  server.on("/wifisave", HTTP_POST, handleWifiSave);
  server.on("/hw", HTTP_GET, handleHw);
  server.on("/hwsave", HTTP_POST, handleHwSave);
  server.onNotFound(redirectHome);
  server.begin();
  Serial.printf("Web page: http://%s  (WiFi %s)\n", ipStr().c_str(), netOK() ? "connected" : "not connected - access point " AP_NAME);

  navigate("about:home", false);
}

void loop() {
  uiTick();
  if (navPending) navigate(navUrl, navPush);
  delay(1);
}
