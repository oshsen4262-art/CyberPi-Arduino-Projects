// Jpeg.h - small streaming baseline/sequential JPEG decoder that shrinks while decoding.
// Reads bytes from a ByteSource, never holds the whole file, output is a small RGB565 image.
// Not supported: progressive JPEG, arithmetic coding, CMYK.
#pragma once
#include <math.h>
#include "Common.h"

class JpegDecoder {
public:
  bool decode(ByteSource &src, ImgOut &out) {
    s = &src;
    out.err = nullptr;
    buildCos();
    if (rd8() != 0xFF || rd8() != 0xD8) { out.err = "not a jpeg"; return false; }
    for (;;) {
      int m = nextMarker();
      if (m < 0 || m == 0xD9) { if (!sofSeen) out.err = "no image"; return sofSeen && scanDone; }
      if (m == 0xD8 || m == 0x01 || (m >= 0xD0 && m <= 0xD7)) continue;
      int len = rd16();
      if (len < 2) { out.err = "bad jpeg"; return false; }
      len -= 2;
      switch (m) {
        case 0xC0: case 0xC1:
          if (!readSOF(len)) { out.err = err ? err : "bad jpeg"; return false; }
          break;
        case 0xC2: out.err = "progressive jpeg"; return false;
        case 0xC3: case 0xC5: case 0xC6: case 0xC7: case 0xC9: case 0xCA: case 0xCB: case 0xCD: case 0xCE: case 0xCF:
          out.err = "unsupported jpeg"; return false;
        case 0xC4: if (!readDHT(len)) { out.err = "bad huffman"; return false; } break;
        case 0xDB: if (!readDQT(len)) { out.err = "bad quant"; return false; } break;
        case 0xDD: restartInterval = rd16(); len -= 2; skip(len); break;
        case 0xDA:
          if (!sofSeen) { out.err = "bad jpeg"; return false; }
          if (!readSOS(len)) { out.err = err ? err : "bad jpeg"; return false; }
          if (!allocOut(out)) { out.err = "no memory"; return false; }
          decodeScan(out);
          scanDone = true;
          return true;
        default: skip(len); break;
      }
    }
  }

private:
  ByteSource *s = nullptr;
  const char *err = nullptr;
  uint16_t qt[4][64];
  struct HT { uint8_t bits[17]; uint8_t vals[256]; int32_t maxcode[18]; int32_t mincode[17]; int32_t valptr[17]; uint16_t lut[512]; bool ok = false; };
  HT ht[2][4];
  struct Comp { int id, h, v, tq, td, ta, pred; } cp[4];
  int nc = 0, W = 0, H = 0, hmax = 1, vmax = 1;
  int restartInterval = 0;
  bool sofSeen = false, scanDone = false;
  uint32_t bitbuf = 0; int bitcnt = 0; int marker = 0;
  int shrink = 1, bw = 8, dw = 0, dh = 0;
  int32_t C[8][8];
  uint8_t planeBuf[4][1024];   // kept in the object (heap) so the task stack stays small

  static const uint8_t *zz() {
    static const uint8_t z[64] = {0,1,8,16,9,2,3,10,17,24,32,25,18,11,4,5,12,19,26,33,40,48,41,34,27,20,13,6,7,14,21,28,
      35,42,49,56,57,50,43,36,29,22,15,23,30,37,44,51,58,59,52,45,38,31,39,46,53,60,61,54,47,55,62,63};
    return z;
  }
  void buildCos() {
    for (int x = 0; x < 8; x++) for (int u = 0; u < 8; u++) {
      double a = (u == 0) ? 0.7071067811865476 : 1.0;
      C[x][u] = (int32_t)lround(4096.0 * 0.5 * a * cos((2 * x + 1) * u * 3.14159265358979323846 / 16.0));
    }
  }

  int rd8() { return s->read(); }
  int rd16() { int a = s->read(), b = s->read(); if (a < 0 || b < 0) return -1; return (a << 8) | b; }
  void skip(int n) { while (n-- > 0) if (s->read() < 0) break; }
  int nextMarker() {
    int b;
    do { b = s->read(); if (b < 0) return -1; } while (b != 0xFF);
    do { b = s->read(); if (b < 0) return -1; } while (b == 0xFF);
    return b == 0 ? nextMarker() : b;
  }

  bool readDQT(int len) {
    while (len > 0) {
      int pt = rd8(); len--;
      if (pt < 0) return false;
      int id = pt & 15, pq = pt >> 4;
      if (id > 3) return false;
      for (int i = 0; i < 64; i++) {
        int v = pq ? rd16() : rd8();
        if (v < 0) return false;
        qt[id][i] = (uint16_t)v;
      }
      len -= pq ? 128 : 64;
    }
    return true;
  }

  bool readDHT(int len) {
    while (len > 0) {
      int tc = rd8(); len--;
      if (tc < 0) return false;
      int cls = tc >> 4, id = tc & 15;
      if (cls > 1 || id > 3) return false;
      HT &t = ht[cls][id];
      int total = 0;
      t.bits[0] = 0;
      for (int i = 1; i <= 16; i++) { int b = rd8(); if (b < 0) return false; t.bits[i] = (uint8_t)b; total += b; }
      len -= 16;
      if (total > 256) return false;
      for (int i = 0; i < total; i++) { int v = rd8(); if (v < 0) return false; t.vals[i] = (uint8_t)v; }
      len -= total;
      buildHuff(t);
    }
    return true;
  }

  void buildHuff(HT &t) {
    memset(t.lut, 0, sizeof(t.lut));
    int code = 0, k = 0;
    for (int len = 1; len <= 16; len++) {
      t.valptr[len] = k;
      t.mincode[len] = code;
      for (int i = 0; i < t.bits[len]; i++) {
        if (len <= 9) {
          int base = code << (9 - len), cnt = 1 << (9 - len);
          for (int j = 0; j < cnt && base + j < 512; j++) t.lut[base + j] = (uint16_t)((len << 8) | t.vals[k]);
        }
        code++; k++;
      }
      t.maxcode[len] = t.bits[len] ? code - 1 : -1;
      code <<= 1;
    }
    t.maxcode[17] = 0x7FFFFFFF;
    t.ok = true;
  }

  bool readSOF(int len) {
    int prec = rd8();
    H = rd16(); W = rd16(); nc = rd8();
    if (prec != 8) { err = "12-bit jpeg"; return false; }
    if (W <= 0 || H <= 0 || W > 16384 || H > 16384) { err = "bad size"; return false; }
    if (nc != 1 && nc != 3) { err = "unsupported colors"; return false; }
    if (len != 6 + 3 * nc) return false;
    hmax = vmax = 1;
    for (int i = 0; i < nc; i++) {
      cp[i].id = rd8(); int hv = rd8(); cp[i].tq = rd8();
      cp[i].h = hv >> 4; cp[i].v = hv & 15; cp[i].pred = 0;
      if (cp[i].h < 1 || cp[i].h > 4 || cp[i].v < 1 || cp[i].v > 4 || cp[i].tq > 3) return false;
      if (cp[i].h > hmax) hmax = cp[i].h;
      if (cp[i].v > vmax) vmax = cp[i].v;
    }
    if (nc == 1) { cp[0].h = cp[0].v = 1; hmax = vmax = 1; }
    sofSeen = true;
    return true;
  }

  bool readSOS(int len) {
    int ns = rd8();
    if (ns != nc || len != 4 + 2 * ns) { err = "multi-scan jpeg"; return false; }
    for (int i = 0; i < ns; i++) {
      int id = rd8(), t = rd8();
      int k = -1;
      for (int j = 0; j < nc; j++) if (cp[j].id == id) k = j;
      if (k < 0) return false;
      cp[k].td = t >> 4; cp[k].ta = t & 15;
      if (cp[k].td > 3 || cp[k].ta > 3) return false;
    }
    rd8(); rd8(); rd8();
    return true;
  }

  bool allocOut(ImgOut &out) {
    fitDims(W, H, dw, dh);
    shrink = 1;
    while (shrink < 8 && W / (shrink * 2) >= dw && H / (shrink * 2) >= dh) shrink *= 2;
    bw = 8 / shrink;
    out.w = dw; out.h = dh;
    out.px = (uint16_t *)g_bigAlloc((size_t)dw * dh * 2);
    if (!out.px) return false;
    for (int i = 0; i < dw * dh; i++) out.px[i] = 0;
    return true;
  }

  // ---- bit reader ----
  void fill() {
    while (bitcnt <= 24) {
      int b = 0;
      if (!marker) {
        b = s->read();
        if (b < 0) { marker = 0xD9; b = 0; }
        else if (b == 0xFF) {
          int b2 = s->read();
          while (b2 == 0xFF) b2 = s->read();
          if (b2 == 0) { /* stuffed 0xFF */ }
          else if (b2 < 0) { marker = 0xD9; b = 0; }
          else { marker = b2; b = 0; }
        }
      }
      bitbuf |= (uint32_t)b << (24 - bitcnt);
      bitcnt += 8;
    }
  }
  inline int getBits(int n) {
    if (n == 0) return 0;
    fill();
    int v = (int)(bitbuf >> (32 - n));
    bitbuf <<= n; bitcnt -= n;
    return v;
  }
  inline int huff(HT &t) {
    fill();
    uint16_t e = t.lut[bitbuf >> 23];
    if (e) { int l = e >> 8; bitbuf <<= l; bitcnt -= l; return e & 255; }
    for (int l = 10; l <= 16; l++) {
      int code = (int)(bitbuf >> (32 - l));
      if (t.maxcode[l] >= 0 && code <= t.maxcode[l] && code >= t.mincode[l]) {
        bitbuf <<= l; bitcnt -= l;
        return t.vals[t.valptr[l] + code - t.mincode[l]];
      }
    }
    return -1;
  }
  static inline int extend(int v, int n) { return v < (1 << (n - 1)) ? v - (1 << n) + 1 : v; }

  bool decodeBlock(Comp &c, int16_t *out, int &last) {
    memset(out, 0, 64 * sizeof(int16_t));
    const uint8_t *z = zz();
    HT &dc = ht[0][c.td], &ac = ht[1][c.ta];
    const uint16_t *q = qt[c.tq];
    int t = huff(dc);
    if (t < 0 || t > 16) return false;
    int diff = t ? extend(getBits(t), t) : 0;
    c.pred += diff;
    out[0] = (int16_t)(c.pred * q[0]);
    last = 0;
    int k = 1;
    while (k < 64) {
      int rs = huff(ac);
      if (rs < 0) return false;
      int r = rs >> 4, sz = rs & 15;
      if (sz == 0) { if (r == 15) { k += 16; continue; } break; }
      k += r;
      if (k > 63) break;
      out[z[k]] = (int16_t)(extend(getBits(sz), sz) * q[k]);
      last = k;
      k++;
    }
    return true;
  }

  static inline uint8_t clamp8(int v) { return v < 0 ? 0 : (v > 255 ? 255 : (uint8_t)v); }

  // IDCT one block, shrink by 'shrink', write (8/shrink)^2 samples into plane at stride.
  void idctBlock(const int16_t *in, int last, uint8_t *plane, int stride) {
    if (shrink == 8 || last == 0) {
      uint8_t v = clamp8((in[0] + 4 * (in[0] >= 0 ? 1 : -1)) / 8 + 128);
      for (int y = 0; y < bw; y++) for (int x = 0; x < bw; x++) plane[y * stride + x] = v;
      return;
    }
    int32_t t[64];
    for (int v = 0; v < 8; v++) {
      const int16_t *row = in + v * 8;
      for (int x = 0; x < 8; x++) {
        int64_t sum = 0;
        for (int u = 0; u < 8; u++) sum += (int32_t)C[x][u] * row[u];
        t[v * 8 + x] = (int32_t)(sum >> 10);
      }
    }
    uint8_t px[64];
    for (int x = 0; x < 8; x++) for (int y = 0; y < 8; y++) {
      int64_t sum = 0;
      for (int v = 0; v < 8; v++) sum += (int64_t)C[y][v] * t[v * 8 + x];
      px[y * 8 + x] = clamp8((int)((sum + (1 << 13)) >> 14) + 128);
    }
    if (shrink == 1) {
      for (int y = 0; y < 8; y++) memcpy(plane + y * stride, px + y * 8, 8);
    } else {
      for (int y = 0; y < bw; y++) for (int x = 0; x < bw; x++) {
        int sum = 0;
        for (int j = 0; j < shrink; j++) for (int i = 0; i < shrink; i++) sum += px[(y * shrink + j) * 8 + x * shrink + i];
        plane[y * stride + x] = (uint8_t)((sum + shrink * shrink / 2) / (shrink * shrink));
      }
    }
  }

  void decodeScan(ImgOut &out) {
    int mcuW = 8 * hmax, mcuH = 8 * vmax;
    int mcusX = (W + mcuW - 1) / mcuW, mcusY = (H + mcuH - 1) / mcuH;
    int mw = hmax * bw, mh = vmax * bw;
    int Ws = (W + shrink - 1) / shrink, Hs = (H + shrink - 1) / shrink;
    std::vector<uint16_t> srcX(dw), srcY(dh);
    for (int i = 0; i < dw; i++) { int v = (int)(((int64_t)(2 * i + 1) * Ws) / (2 * dw)); srcX[i] = (uint16_t)(v >= Ws ? Ws - 1 : v); }
    for (int i = 0; i < dh; i++) { int v = (int)(((int64_t)(2 * i + 1) * Hs) / (2 * dh)); srcY[i] = (uint16_t)(v >= Hs ? Hs - 1 : v); }
    uint8_t (*plane)[1024] = planeBuf;
    int16_t blk[64];
    int dyPtr = 0, mcuCount = 0;
    for (int my = 0; my < mcusY; my++) {
      int dyB = dyPtr, dyE = dyB;
      while (dyE < dh && srcY[dyE] < (my + 1) * mh) dyE++;
      dyPtr = dyE;
      int dxPtr = 0;
      for (int mx = 0; mx < mcusX; mx++, mcuCount++) {
        if (restartInterval && mcuCount > 0 && mcuCount % restartInterval == 0) {
          bitbuf = 0; bitcnt = 0;
          if (!marker) { int m; while ((m = nextMarker()) >= 0 && !(m >= 0xD0 && m <= 0xD7)) { if (m == 0xD9) break; } }
          marker = 0;
          for (int i = 0; i < nc; i++) cp[i].pred = 0;
        }
        int dxB = dxPtr, dxE = dxB;
        while (dxE < dw && srcX[dxE] < (mx + 1) * mw) dxE++;
        dxPtr = dxE;
        bool need = dyE > dyB && dxE > dxB;
        for (int ci = 0; ci < nc; ci++) {
          Comp &c = cp[ci];
          int pw = c.h * bw;
          for (int by = 0; by < c.v; by++) for (int bx = 0; bx < c.h; bx++) {
            int last = 0;
            if (!decodeBlock(c, blk, last)) { marker = 0xD9; memset(blk, 0, sizeof(blk)); last = 0; }
            if (need) idctBlock(blk, last, plane[ci] + (by * bw) * pw + bx * bw, pw);
          }
        }
        if (!need) continue;
        for (int dy = dyB; dy < dyE; dy++) {
          int py = srcY[dy] - my * mh;
          uint16_t *row = out.px + dy * dw;
          for (int dx = dxB; dx < dxE; dx++) {
            int pxl = srcX[dx] - mx * mw;
            uint8_t r, g, b;
            const Comp &c0 = cp[0];
            int Y = plane[0][((py * c0.v) / vmax) * (c0.h * bw) + (pxl * c0.h) / hmax];
            if (nc == 1) { r = g = b = (uint8_t)Y; }
            else {
              const Comp &c1 = cp[1], &c2 = cp[2];
              int cb = plane[1][((py * c1.v) / vmax) * (c1.h * bw) + (pxl * c1.h) / hmax] - 128;
              int cr = plane[2][((py * c2.v) / vmax) * (c2.h * bw) + (pxl * c2.h) / hmax] - 128;
              r = clamp8(Y + ((91881 * cr) >> 16));
              g = clamp8(Y - ((22554 * cb + 46802 * cr) >> 16));
              b = clamp8(Y + ((116130 * cb) >> 16));
            }
            row[dx] = C565(r, g, b);
          }
        }
      }
      if (marker == 0xD9) break;
    }
  }
};
