/*
 * CyberPi Gemini - a Gemini-style chat for the Makeblock CyberPi (128x128 screen)
 * --------------------------------------------------------------------------------
 *   In the chat:    joystick up/down = scroll      A / B / joystick press = open keyboard
 *                   MENU = start a new chat
 *   On the keyboard: joystick = move over the keys   A = press the key
 *                   B = backspace    joystick press = send    MENU = back to the chat (draft is kept)
 *
 * You can also type from a phone/PC: open http://<address shown on the CyberPi> and use the box there.
 *
 * Arduino IDE settings (same as CyberPiBrowser):
 *   Board: ESP32 Wrover Module   PSRAM: Enabled (or Disabled if it will not start)   Partition: Huge APP or default
 *   No extra libraries needed. Put Common.h (included in this folder) next to this file.
 *
 * Setup: flash it, then open the serial monitor (115200) or look at the screen for the address.
 *   WiFi saved by CyberPiBrowser is reused (same storage name). If there is none, the CyberPi makes the
 *   WiFi "CyberPi-Gemini": join it, open http://192.168.4.1 and enter your WiFi and your Gemini API key.
 *
 * Not in this version: microphone and image generation.
 * Note: HTTPS runs with certificate checking OFF (setInsecure), the same way CyberPiBrowser does.
 */
#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <WebServer.h>
#include <Preferences.h>
#include <SPI.h>
#include <esp_bt.h>
#include <math.h>
#include <vector>

#include "Common.h"

// The Arduino IDE auto-generates function prototypes near the top of the sketch, before the type
// definitions further down, so the types used in function signatures must be declared by name up here.
struct VLine;
struct Key;

#ifdef SET_LOOP_TASK_STACK_SIZE
SET_LOOP_TASK_STACK_SIZE(16 * 1024);   // TLS needs more stack than the default 8 KB
#endif

// ======================================================================= settings you may edit
#define GEMINI_API_KEY  ""                      // optional: paste a key here, or save it on the web page instead
#define GEMINI_MODEL    "gemini-flash-latest"   // change here or on the web page if Google renames models
#define USER_NAME       ""                      // shown in the welcome greeting, e.g. "Sam"
#define AP_NAME         "CyberPi-Gemini"
#define MAX_DRAFT       300
#define MAX_CHAT_MSGS   24
#define SYSTEM_PROMPT   "You are Gemini, shown on a tiny 128x128 pixel screen. Reply in plain text only: no markdown, no emoji, no tables. Keep answers short, under 60 words, unless the user asks for more."

// ======================================================================= CyberPi buttons (AW9523B on I2C)
#define I2C_SDA        19
#define I2C_SCL        18
#define AW_ADDR        0x58
#define P0_LEFT   0
#define P0_UP     1
#define P0_RIGHT  2
#define P0_CENTER 3
#define P0_DOWN   4
#define P0_B      5
#define P0_A      6
#define P1_MENU   0
enum : uint16_t { B_UP = 1 << 0, B_DOWN = 1 << 1, B_LEFT = 1 << 2, B_RIGHT = 1 << 3,
                  B_CENTER = 1 << 4, B_A = 1 << 5, B_B = 1 << 6, B_MENU = 1 << 7 };

static bool awWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(AW_ADDR); Wire.write(reg); Wire.write(val);
  return Wire.endTransmission() == 0;
}
static bool awRead(uint8_t reg, uint8_t &val) {
  Wire.beginTransmission(AW_ADDR); Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)AW_ADDR, 1) != 1) return false;
  val = Wire.read(); return true;
}
static bool expanderInit() {
  uint8_t id = 0; bool ok = awRead(0x10, id);
  Serial.printf("I/O expander: %s (ID 0x%02X, expected 0x23)\n", ok ? "found" : "NOT FOUND", id);
  awWrite(0x7F, 0x00); delay(10);
  awWrite(0x12, 0xFF); awWrite(0x13, 0xF9); awWrite(0x11, 0x00);
  awWrite(0x04, 0xFF); awWrite(0x05, 0x4F); awWrite(0x03, 0x00);   // P1.4/P1.5/P1.7 = outputs (LCD DC, RESET, backlight)
  return ok;
}
static bool readButtons(uint16_t &out) {
  uint8_t p0, p1;
  if (!awRead(0x00, p0) || !awRead(0x01, p1)) return false;
  uint16_t b = 0;
  if (!(p0 & (1 << P0_UP)))     b |= B_UP;
  if (!(p0 & (1 << P0_DOWN)))   b |= B_DOWN;
  if (!(p0 & (1 << P0_LEFT)))   b |= B_LEFT;
  if (!(p0 & (1 << P0_RIGHT)))  b |= B_RIGHT;
  if (!(p0 & (1 << P0_CENTER))) b |= B_CENTER;
  if (!(p0 & (1 << P0_A)))      b |= B_A;
  if (!(p0 & (1 << P0_B)))      b |= B_B;
  if (!(p1 & (1 << P1_MENU)))   b |= B_MENU;
  out = b; return true;
}

// Button events: a press, plus auto-repeat for the buttons in repeatMask.
static uint16_t prevBtn = 0;
static uint32_t nextRep[16];
static uint32_t lastBtnErr = 0;
static uint16_t getEvents(uint16_t repeatMask) {
  uint16_t b;
  if (!readButtons(b)) {
    if (millis() - lastBtnErr > 5000) { lastBtnErr = millis(); Serial.println("ERROR: could not read the buttons over I2C"); }
    return 0;
  }
  uint32_t now = millis(); uint16_t ev = 0;
  for (int i = 0; i < 16; i++) {
    uint16_t m = 1 << i;
    if (b & m) {
      if (!(prevBtn & m)) { ev |= m; nextRep[i] = now + 380; }
      else if ((repeatMask & m) && now >= nextRep[i]) { ev |= m; nextRep[i] = now + 110; }
    }
  }
  prevBtn = b; return ev;
}

// ======================================================================= display (ST7735S 128x128) - same as CyberPiBrowser
#define HW_VER 2
struct HwCfg { uint8_t ver; int8_t mosi, sclk, cs, dc, rst, bl; uint8_t blHigh, blExp, xoff, yoff, madctl, invert; };
static HwCfg hw = { HW_VER, 2, 4, 12, 112, 113, 115, 1, 0, 3, 2, 0xA0, 0 };

static SPIClass *lcdSpi = nullptr;
static bool lcdUp = false;
static uint8_t expP1 = 0;
static inline void pw(int pin, int v) {
  if (pin < 0) return;
  if (pin >= 100) {
    int b = pin - 100 - 8; if (b < 0 || b > 7) return;
    uint8_t n = v ? (expP1 | (1 << b)) : (expP1 & ~(1 << b));
    if (n != expP1) { expP1 = n; awWrite(0x03, expP1); }
    return;
  }
  digitalWrite(pin, v);
}
static void lcdCmd(uint8_t c, const uint8_t *d = nullptr, int n = 0) {
  lcdSpi->beginTransaction(SPISettings(20000000, MSBFIRST, SPI_MODE0));
  pw(hw.cs, LOW); pw(hw.dc, LOW); lcdSpi->transfer(c);
  if (n) { pw(hw.dc, HIGH); lcdSpi->writeBytes(d, n); }
  pw(hw.cs, HIGH); lcdSpi->endTransaction();
}
static void lcdBegin() {
  if (lcdSpi) { lcdSpi->end(); delete lcdSpi; lcdSpi = nullptr; }
  int pins[] = { hw.cs, hw.dc, hw.rst, hw.bl };
  for (int p : pins) if (p >= 0 && p < 100) pinMode(p, OUTPUT);
  pw(hw.cs, HIGH);
  lcdSpi = new SPIClass(HSPI);
  lcdSpi->begin(hw.sclk, -1, hw.mosi, -1);
  if (hw.rst >= 0) { pw(hw.rst, HIGH); delay(10); pw(hw.rst, LOW); delay(20); pw(hw.rst, HIGH); delay(120); }
  lcdCmd(0x01); delay(150);
  lcdCmd(0x11); delay(150);
  { const uint8_t d[] = {0x01, 0x2C, 0x2D}; lcdCmd(0xB1, d, 3); lcdCmd(0xB2, d, 3); }
  { const uint8_t d[] = {0x01, 0x2C, 0x2D, 0x01, 0x2C, 0x2D}; lcdCmd(0xB3, d, 6); }
  { const uint8_t d[] = {0x07}; lcdCmd(0xB4, d, 1); }
  { const uint8_t d[] = {0xA2, 0x02, 0x84}; lcdCmd(0xC0, d, 3); }
  { const uint8_t d[] = {0xC5}; lcdCmd(0xC1, d, 1); }
  { const uint8_t d[] = {0x0A, 0x00}; lcdCmd(0xC2, d, 2); }
  { const uint8_t d[] = {0x8A, 0x2A}; lcdCmd(0xC3, d, 2); }
  { const uint8_t d[] = {0x8A, 0xEE}; lcdCmd(0xC4, d, 2); }
  { const uint8_t d[] = {0x0E}; lcdCmd(0xC5, d, 1); }
  lcdCmd(hw.invert ? 0x21 : 0x20);
  { const uint8_t d[] = {hw.madctl}; lcdCmd(0x36, d, 1); }
  { const uint8_t d[] = {0x05}; lcdCmd(0x3A, d, 1); }
  { const uint8_t d[] = {0x02,0x1C,0x07,0x12,0x37,0x32,0x29,0x2D,0x29,0x25,0x2B,0x39,0x00,0x01,0x03,0x10}; lcdCmd(0xE0, d, 16); }
  { const uint8_t d[] = {0x03,0x1D,0x07,0x06,0x2E,0x2C,0x29,0x2D,0x2E,0x2E,0x37,0x3F,0x00,0x00,0x02,0x10}; lcdCmd(0xE1, d, 16); }
  lcdCmd(0x13); delay(10);
  lcdCmd(0x29); delay(100);
  pw(hw.bl, hw.blHigh ? HIGH : LOW);
  if (hw.blExp) awWrite(0x03, 0xFF);
  lcdUp = true;
}
static void lcdPush() {
  if (!lcdUp || !g_fb) return;
  uint8_t c[4] = {0, (uint8_t)hw.xoff, 0, (uint8_t)(hw.xoff + SCR_W - 1)};
  uint8_t r[4] = {0, (uint8_t)hw.yoff, 0, (uint8_t)(hw.yoff + SCR_H - 1)};
  lcdCmd(0x2A, c, 4); lcdCmd(0x2B, r, 4);
  lcdSpi->beginTransaction(SPISettings(20000000, MSBFIRST, SPI_MODE0));
  pw(hw.cs, LOW); pw(hw.dc, LOW); lcdSpi->transfer(0x2C); pw(hw.dc, HIGH);
  lcdSpi->writeBytes((const uint8_t *)g_fb, SCR_W * SCR_H * 2);
  pw(hw.cs, HIGH); lcdSpi->endTransaction();
}

// ======================================================================= Gemini look: colours and shapes
#define COL_BG      C565(19, 19, 20)       // Gemini dark background
#define COL_FIELD   C565(30, 31, 32)       // input bar / field
#define COL_BUBBLE  C565(40, 42, 44)       // your message bubble
#define COL_TEXT    C565(227, 227, 227)
#define COL_GREY    C565(150, 154, 160)
#define COL_ERR     C565(242, 139, 130)
#define COL_KEY     C565(45, 47, 50)
#define COL_KEYSEL  C565(168, 199, 250)    // light blue highlight
#define COL_KEYSELT C565(6, 46, 111)
#define COL_BLUE    C565(66, 133, 244)

// blue -> purple -> coral gradient, t = 0..255
static uint16_t grad(int t) {
  if (t < 0) t = 0; if (t > 255) t = 255;
  int r, g, b;
  if (t < 128) { int k = t * 2;         r = 66 + (155 - 66) * k / 255;  g = 133 + (114 - 133) * k / 255; b = 244 + (203 - 244) * k / 255; }
  else         { int k = (t - 128) * 2; r = 155 + (217 - 155) * k / 255; g = 114 + (101 - 114) * k / 255; b = 203 + (112 - 203) * k / 255; }
  return C565(r, g, b);
}
// Gemini four-point sparkle (astroid shape) with the gradient across it
static void sparkle(int cx, int cy, int r) {
  if (r < 1) return;
  for (int dy = -r; dy <= r; dy++) for (int dx = -r; dx <= r; dx++) {
    float ax = fabsf((float)dx) / r, ay = fabsf((float)dy) / r;
    if (sqrtf(ax) + sqrtf(ay) <= 1.0f) gPx(cx + dx, cy + dy, grad(((dx + dy + 2 * r) * 255) / (4 * r)));
  }
}
static void gradText(int x, int y, const char *s) {
  int n = strlen(s);
  for (int i = 0; i < n; i++) gChar(x + i * CHAR_W, y, s[i], grad(n > 1 ? i * 255 / (n - 1) : 0));
}
static int textW(const char *s) { return strlen(s) * CHAR_W; }
// filled rounded rectangle (radius 2); bg is painted into the corners
static void roundRect(int x, int y, int w, int h, uint16_t col, uint16_t bg, bool top = true, bool bottom = true) {
  gFill(x, y, w, h, col);
  if (top)    { gPx(x, y, bg); gPx(x + 1, y, bg); gPx(x, y + 1, bg); gPx(x + w - 1, y, bg); gPx(x + w - 2, y, bg); gPx(x + w - 1, y + 1, bg); }
  if (bottom) { gPx(x, y + h - 1, bg); gPx(x + 1, y + h - 1, bg); gPx(x, y + h - 2, bg); gPx(x + w - 1, y + h - 1, bg); gPx(x + w - 2, y + h - 1, bg); gPx(x + w - 1, y + h - 2, bg); }
}

// ======================================================================= text helpers
static void appendUtf8(String &o, uint32_t cp) {
  if (cp < 0x80) o += (char)cp;
  else if (cp < 0x800) { o += (char)(0xC0 | (cp >> 6)); o += (char)(0x80 | (cp & 0x3F)); }
  else if (cp < 0x10000) { o += (char)(0xE0 | (cp >> 12)); o += (char)(0x80 | ((cp >> 6) & 0x3F)); o += (char)(0x80 | (cp & 0x3F)); }
  else { o += (char)(0xF0 | (cp >> 18)); o += (char)(0x80 | ((cp >> 12) & 0x3F)); o += (char)(0x80 | ((cp >> 6) & 0x3F)); o += (char)(0x80 | (cp & 0x3F)); }
}
// The built-in font is plain ASCII: map common symbols, show '?' for everything else.
static String asciiFold(const String &s) {
  String o; o.reserve(s.length());
  size_t n = s.length();
  for (size_t i = 0; i < n;) {
    uint8_t c = (uint8_t)s[i];
    if (c < 0x80) {
      if (c == '\t') o += "  "; else if (c == '\n' || c >= 32) o += (char)c;
      i++; continue;
    }
    uint32_t cp = 0; size_t len = 1;
    if ((c & 0xE0) == 0xC0) { cp = c & 0x1F; len = 2; }
    else if ((c & 0xF0) == 0xE0) { cp = c & 0x0F; len = 3; }
    else if ((c & 0xF8) == 0xF0) { cp = c & 0x07; len = 4; }
    for (size_t k = 1; k < len && i + k < n; k++) cp = (cp << 6) | ((uint8_t)s[i + k] & 0x3F);
    i += len;
    switch (cp) {
      case 0x2018: case 0x2019: o += '\''; break;
      case 0x201C: case 0x201D: o += '"'; break;
      case 0x2013: case 0x2014: o += '-'; break;
      case 0x2022: o += '*'; break;
      case 0x2026: o += "..."; break;
      case 0xA0:   o += ' '; break;
      default:     o += '?';
    }
  }
  return o;
}
// remove the markdown that Gemini sometimes adds anyway
static String stripMd(const String &s) {
  String o; int n = s.length(); int i = 0;
  while (i <= n) {
    int e = s.indexOf('\n', i); if (e < 0) e = n;
    String ln = s.substring(i, e);
    ln.replace("**", ""); ln.replace("`", "");
    while (ln.length() && ln[0] == '#') ln.remove(0, 1);
    if (ln.length() && ln[0] == ' ' && s.length() > (unsigned)i && s[i] == '#') ln.remove(0, 1);
    if (ln.startsWith("* ")) ln = "- " + ln.substring(2);
    o += ln; if (e < n) o += '\n';
    i = e + 1;
  }
  return o;
}
static void wrapText(const String &s, int cols, std::vector<String> &out) {
  int n = s.length(); int i = 0;
  while (i <= n) {
    int e = s.indexOf('\n', i); if (e < 0) e = n;
    String para = s.substring(i, e);
    int pl = para.length();
    if (pl == 0) out.push_back("");
    else {
      String line; int p = 0;
      while (p < pl) {
        while (p < pl && para[p] == ' ') p++;
        int q = p; while (q < pl && para[q] != ' ') q++;
        String w = para.substring(p, q); p = q;
        if (!w.length()) break;
        while ((int)w.length() > cols) {
          if (line.length()) { out.push_back(line); line = ""; }
          out.push_back(w.substring(0, cols)); w = w.substring(cols);
        }
        if (line.length() == 0) line = w;
        else if ((int)(line.length() + 1 + w.length()) <= cols) { line += ' '; line += w; }
        else { out.push_back(line); line = w; }
      }
      if (line.length()) out.push_back(line);
    }
    i = e + 1;
  }
  while (!out.empty() && out.back().length() == 0) out.pop_back();
}
static String hesc(const String &s) {
  String o; for (size_t i = 0; i < s.length(); i++) { char c = s[i]; if (c == '<') o += "&lt;"; else if (c == '>') o += "&gt;"; else if (c == '&') o += "&amp;"; else if (c == '"') o += "&quot;"; else o += c; }
  return o;
}
static String jsonEsc(const String &s) {
  String o; o.reserve(s.length() + 8);
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    switch (c) {
      case '"': o += "\\\""; break;
      case '\\': o += "\\\\"; break;
      case '\n': o += "\\n"; break;
      case '\r': break;
      case '\t': o += "\\t"; break;
      default: if ((uint8_t)c < 32) o += ' '; else o += c;
    }
  }
  return o;
}

// ======================================================================= state
static Preferences prefs;
static WebServer server(80);
static bool psram = false, wantAP = false;
static bool netOK() { return WiFi.status() == WL_CONNECTED; }
static String ipStr() { return netOK() ? WiFi.localIP().toString() : WiFi.softAPIP().toString(); }

struct Msg { uint8_t kind; String text; };      // kind: 0 = Gemini, 1 = you, 2 = error
static std::vector<Msg> chat;
struct VLine { String t; uint8_t kind; bool first, last; };   // kind 3 = gap between messages
static std::vector<VLine> vlines;
enum Screen { S_CHAT, S_KEYS };
static Screen screen = S_CHAT;
static bool dirty = true, thinking = false;
static int scrollY = 0;
static String draft, webAsk, lastQ, lastA;

#define VTOP 14
#define VBOT 104
static int lh(uint8_t k) { return k == 3 ? 4 : (k == 1 ? 10 : 9); }
static int contentH() { int h = 0; for (auto &v : vlines) h += lh(v.kind); if (thinking) h += 12; return h; }
static int maxScroll() { int m = contentH() - (VBOT - VTOP + 1); return m > 0 ? m : 0; }

static void rebuildLines() {
  vlines.clear();
  for (auto &m : chat) {
    String t = asciiFold(m.text);
    if (m.kind != 1) t = stripMd(t);
    std::vector<String> ls;
    wrapText(t, m.kind == 1 ? 18 : 19, ls);
    if (ls.empty()) ls.push_back("");
    for (size_t j = 0; j < ls.size(); j++) vlines.push_back({ls[j], m.kind, j == 0, j + 1 == ls.size()});
    vlines.push_back({"", 3, false, false});
  }
}
static int startYOfLastMsg() {
  int y = 0, startOfLast = 0;
  for (auto &v : vlines) { if (v.first) startOfLast = y; y += lh(v.kind); }
  return startOfLast;
}

// ======================================================================= drawing: chat screen
static void drawHeader() {
  gFill(0, 0, SCR_W, 13, COL_BG);
  sparkle(7, 6, 5);
  gradText(15, 3, "Gemini");
  uint16_t on = netOK() ? COL_TEXT : C565(80, 80, 84);
  gFill(112, 8, 2, 3, on); gFill(116, 6, 2, 5, on); gFill(120, 4, 2, 7, on);
  if (!netOK()) gChar(121, 1, 'x', COL_ERR);
}
static void drawInputBar() {
  gFill(0, 105, SCR_W, 23, COL_BG);
  roundRect(3, 108, 122, 17, COL_FIELD, COL_BG);
  gText(10, 113, "Ask Gemini", COL_GREY);
  gText(104, 113, "[A]", COL_KEYSEL);
}
static void drawWelcome() {
  sparkle(64, 34, 14);
  String hello = String("Hello") + (String(USER_NAME).length() ? String(", ") + USER_NAME : String(""));
  gradText((SCR_W - textW(hello.c_str())) / 2, 58, hello.c_str());
  const char *l2 = "How can I help?";
  gText((SCR_W - textW(l2)) / 2, 72, l2, COL_GREY);
  String info;
  if (wantAP && !netOK()) info = String("WiFi ") + AP_NAME;
  else info = ipStr();
  gText((SCR_W - textW(info.c_str())) / 2, 90, info.c_str(), C565(110, 114, 120));
}
static void drawVLine(const VLine &v, int y) {
  if (v.kind == 3) return;
  if (v.kind == 1) {
    int w = v.t.length() * CHAR_W;
    int bx = 126 - w - 8;
    roundRect(bx, y, w + 8, 10, COL_BUBBLE, COL_BG, v.first, v.last);
    gText(bx + 4, y + 1, v.t.c_str(), COL_TEXT);
  } else if (v.kind == 0) {
    if (v.first) sparkle(6, y + 4, 4);
    gText(13, y, v.t.c_str(), COL_TEXT);
  } else {
    if (v.first) gChar(5, y, '!', COL_ERR);
    gText(13, y, v.t.c_str(), COL_ERR);
  }
}
static void drawChatScreen() {
  gFill(0, 0, SCR_W, SCR_H, COL_BG);
  if (chat.empty() && !thinking) drawWelcome();
  else {
    int y = VTOP - scrollY;
    for (auto &v : vlines) { int h = lh(v.kind); if (y + h > VTOP - 1 && y <= VBOT) drawVLine(v, y); y += h; }
    if (thinking) {
      int f = (millis() / 140) % 8;
      int r = 3 + (4 - abs(f - 4)) / 2;
      sparkle(7, y + 6, r);
      char buf[16]; snprintf(buf, sizeof buf, "Thinking%.*s", (int)(f % 4), "...");
      gradText(18, y + 2, buf);
    }
  }
  drawHeader();
  drawInputBar();
}

// ======================================================================= on-screen keyboard
enum KC : uint8_t { KC_NONE, KC_CHAR, KC_SHIFT, KC_BKSP, KC_MODE, KC_SPACE, KC_ENTER };
struct Key { char ch; uint8_t code; uint8_t w; };
static bool symMode = false, shiftOn = true;
static int kRow = 0, kCol = 0;
#define KX0 4
#define KY0 68
#define KPITCH 14
#define KUNIT 12

static int buildRow(int r, Key *k) {
  int n = 0;
  auto chars = [&](const char *s) { for (; *s; s++) { k[n].ch = *s; k[n].code = KC_CHAR; k[n].w = 1; n++; } };
  auto add = [&](char c, uint8_t code, uint8_t w) { k[n].ch = c; k[n].code = code; k[n].w = w; n++; };
  if (!symMode) {
    if (r == 0) chars("qwertyuiop");
    else if (r == 1) chars("asdfghjkl'");
    else if (r == 2) { add(0, KC_SHIFT, 1); chars("zxcvbnm."); add(0, KC_BKSP, 1); }
    else { add(0, KC_MODE, 2); add(',', KC_CHAR, 1); add(' ', KC_SPACE, 4); add('?', KC_CHAR, 1); add(0, KC_ENTER, 2); }
  } else {
    if (r == 0) chars("1234567890");
    else if (r == 1) chars("-/:;()$&@\"");
    else if (r == 2) { add(0, KC_NONE, 1); chars("#%*+=_<>"); add(0, KC_BKSP, 1); }
    else { add(0, KC_MODE, 2); add(',', KC_CHAR, 1); add(' ', KC_SPACE, 4); add('?', KC_CHAR, 1); add(0, KC_ENTER, 2); }
  }
  return n;
}
static void clampKey() {
  Key k[12]; int n = buildRow(kRow, k);
  if (kCol >= n) kCol = n - 1;
  if (kCol < 0) kCol = 0;
}
static int keyCenterX(int row, int col) {
  Key k[12]; int n = buildRow(row, k); int x = KX0;
  for (int i = 0; i < n; i++) { if (i == col) return x + (k[i].w * KUNIT) / 2; x += k[i].w * KUNIT; }
  return x;
}
static void moveVert(int d) {
  int cx = keyCenterX(kRow, kCol);
  kRow = (kRow + d + 4) % 4;
  Key k[12]; int n = buildRow(kRow, k); int x = KX0; int best = n - 1;
  for (int i = 0; i < n; i++) { int x1 = x + k[i].w * KUNIT; if (cx >= x && cx < x1) { best = i; break; } x = x1; }
  kCol = best;
}
static void moveHoriz(int d) {
  Key k[12]; int n = buildRow(kRow, k);
  kCol = (kCol + d + n) % n;
}
static void drawKeyboard() {
  gFill(0, 0, SCR_W, SCR_H, COL_BG);
  sparkle(6, 6, 4);
  gText(14, 2, "New message", COL_GREY);
  char cnt[12]; snprintf(cnt, sizeof cnt, "%d", (int)draft.length());
  gText(126 - textW(cnt), 2, cnt, C565(110, 114, 120));
  roundRect(2, 12, 124, 53, COL_FIELD, COL_BG);
  std::vector<String> ls;
  wrapText(asciiFold(draft) + "_", 19, ls);
  int first = ls.size() > 5 ? (int)ls.size() - 5 : 0;
  for (int i = first; i < (int)ls.size(); i++) gText(6, 15 + (i - first) * 9, ls[i].c_str(), COL_TEXT);
  for (int r = 0; r < 4; r++) {
    Key k[12]; int n = buildRow(r, k); int x = KX0; int y = KY0 + r * KPITCH;
    for (int i = 0; i < n; i++) {
      int w = k[i].w * KUNIT - 1;
      bool sel = (r == kRow && i == kCol);
      uint16_t bg = COL_KEY, fg = COL_TEXT;
      if (k[i].code == KC_ENTER) bg = COL_BLUE;
      if (k[i].code == KC_SHIFT && shiftOn && !symMode) { bg = C565(100, 105, 112); }
      if (sel) { bg = COL_KEYSEL; fg = COL_KEYSELT; }
      if (k[i].code == KC_NONE && !sel) bg = C565(30, 31, 32);
      roundRect(x, y, w, 13, bg, COL_BG);
      char lab[6] = {0};
      switch (k[i].code) {
        case KC_CHAR: lab[0] = k[i].ch; if (!symMode && shiftOn && lab[0] >= 'a' && lab[0] <= 'z') lab[0] -= 32; break;
        case KC_SHIFT: strcpy(lab, "^"); break;
        case KC_BKSP:  strcpy(lab, "<"); break;
        case KC_MODE:  strcpy(lab, symMode ? "abc" : "123"); break;
        case KC_ENTER: strcpy(lab, ">"); if (!sel) fg = C565(255, 255, 255); break;
        case KC_SPACE: break;
        default: break;
      }
      if (k[i].code == KC_SPACE) gFill(x + w / 2 - 12, y + 9, 24, 1, fg);
      else if (lab[0]) gText(x + (w - textW(lab)) / 2, y + 3, lab, fg);
      x += k[i].w * KUNIT;
    }
  }
}

// ======================================================================= Gemini request
static uint32_t lastThinkDraw = 0;
static void thinkTick() {
  uint32_t n = millis();
  if (n - lastThinkDraw < 140) return;
  lastThinkDraw = n;
  drawChatScreen(); lcdPush();
}

struct NetReader {
  WiFiClientSecure &c; bool chunked; long chunkLeft = 0; bool done = false; bool timedOut = false; uint32_t deadline;
  NetReader(WiFiClientSecure &cl, bool ch, uint32_t dl) : c(cl), chunked(ch), deadline(dl) {}
  int rawRead() {
    while (true) {
      if (c.available()) return c.read();
      if (!c.connected()) return -1;
      if (millis() > deadline) { timedOut = true; return -1; }
      thinkTick(); delay(2);
    }
  }
  int read() {
    if (!chunked) return rawRead();
    if (done) return -1;
    while (chunkLeft == 0) {
      String ln; int ch;
      while ((ch = rawRead()) >= 0) { if (ch == '\n') break; if (ch != '\r') ln += (char)ch; }
      if (ch < 0) { done = true; return -1; }
      if (ln.length() == 0) continue;                       // CRLF that ends the previous chunk
      chunkLeft = strtol(ln.c_str(), nullptr, 16);
      if (chunkLeft == 0) { done = true; return -1; }
    }
    chunkLeft--;
    return rawRead();
  }
};

static bool jsonStringAt(const String &b, int &p, String &out) {   // p = index of the opening quote
  p++; out = "";
  int n = b.length();
  while (p < n) {
    char c = b[p++];
    if (c == '"') return true;
    if (c != '\\') { out += c; continue; }
    if (p >= n) break;
    char e = b[p++];
    switch (e) {
      case 'n': out += '\n'; break;
      case 't': out += ' '; break;
      case 'r': case 'b': case 'f': break;
      case '/': out += '/'; break;
      case '"': out += '"'; break;
      case '\\': out += '\\'; break;
      case 'u': {
        if (p + 4 > n) return false;
        uint32_t cp = strtoul(b.substring(p, p + 4).c_str(), nullptr, 16); p += 4;
        if (cp >= 0xD800 && cp < 0xDC00 && p + 6 <= n && b[p] == '\\' && b[p + 1] == 'u') {
          uint32_t lo = strtoul(b.substring(p + 2, p + 6).c_str(), nullptr, 16); p += 6;
          cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
        }
        appendUtf8(out, cp);
      } break;
      default: out += e;
    }
  }
  return false;
}
// find  "key" : "value"  starting at 'from'; on success 'next' is the index after the value
static bool findKeyString(const String &b, const char *key, int from, String &out, int &next) {
  String pat = String("\"") + key + "\"";
  int n = b.length();
  while (true) {
    int idx = b.indexOf(pat, from);
    if (idx < 0) return false;
    int q = idx + pat.length();
    while (q < n && (b[q] == ' ' || b[q] == '\n' || b[q] == '\r' || b[q] == '\t')) q++;
    if (q >= n || b[q] != ':') { from = idx + 1; continue; }
    q++;
    while (q < n && (b[q] == ' ' || b[q] == '\n' || b[q] == '\r' || b[q] == '\t')) q++;
    if (q >= n || b[q] != '"') { from = idx + 1; continue; }
    int p = q;
    if (!jsonStringAt(b, p, out)) return false;
    next = p; return true;
  }
}

static String apiKey() {
  String k = prefs.getString("gkey", GEMINI_API_KEY); k.trim(); return k;
}
static String apiModel() {
  String m = prefs.getString("gmodel", GEMINI_MODEL); m.trim(); if (!m.length()) m = GEMINI_MODEL; return m;
}

static String buildBody() {
  struct Turn { bool user; String text; };
  std::vector<Turn> turns;
  for (auto &m : chat) {
    if (m.kind == 2) continue;
    bool u = (m.kind == 1);
    if (!turns.empty() && turns.back().user == u) { turns.back().text += "\n"; turns.back().text += m.text; }
    else turns.push_back({u, m.text});
  }
  while (!turns.empty() && !turns.front().user) turns.erase(turns.begin());
  auto total = [&]() { size_t t = 0; for (auto &x : turns) t += x.text.length(); return t; };
  while (turns.size() > 1 && total() > 3500) turns.erase(turns.begin());
  while (!turns.empty() && !turns.front().user) turns.erase(turns.begin());
  String b = "{\"systemInstruction\":{\"parts\":[{\"text\":\"";
  b += jsonEsc(SYSTEM_PROMPT);
  b += "\"}]},\"contents\":[";
  for (size_t i = 0; i < turns.size(); i++) {
    if (i) b += ",";
    b += "{\"role\":\""; b += turns[i].user ? "user" : "model"; b += "\",\"parts\":[{\"text\":\"";
    b += jsonEsc(turns[i].text); b += "\"}]}";
  }
  b += "],\"generationConfig\":{\"maxOutputTokens\":1024,\"temperature\":0.7}}";
  return b;
}

// returns true and fills reply, or false and fills err (a message that is shown on screen)
static bool askGemini(String &reply, String &err) {
  String key = apiKey();
  if (key.length() < 10) { err = "No API key saved. Open http://" + ipStr() + " in a browser and save one."; return false; }
  if (!netOK()) { err = "No WiFi. Open http://" + ipStr() + " to set it."; return false; }
  String model = apiModel();
  String body = buildBody();

  WiFiClientSecure cl;
  cl.setInsecure();
  cl.setTimeout(15);
  if (!cl.connect("generativelanguage.googleapis.com", 443)) {
    err = "Could not open the secure connection (free memory " + String((unsigned)ESP.getFreeHeap()) + " bytes).";
    return false;
  }
  String head = "POST /v1beta/models/" + model + ":generateContent HTTP/1.0\r\n"
                "Host: generativelanguage.googleapis.com\r\n"
                "x-goog-api-key: " + key + "\r\n"
                "Content-Type: application/json\r\n"
                "Content-Length: " + String((unsigned)body.length()) + "\r\n"
                "Connection: close\r\n\r\n";
  cl.print(head);
  const uint8_t *p = (const uint8_t *)body.c_str(); size_t left = body.length();
  while (left) {
    size_t n = left > 1024 ? 1024 : left;
    if (cl.write(p, n) != n) { err = "Connection dropped while sending."; cl.stop(); return false; }
    p += n; left -= n; thinkTick();
  }

  NetReader rd(cl, false, millis() + 45000);
  // status line + headers (read as a plain stream first)
  String status; bool chunked = false; int code = 0;
  {
    String ln; int ch; bool first = true;
    while (true) {
      ch = rd.rawRead();
      if (ch < 0) break;
      if (ch == '\r') continue;
      if (ch == '\n') {
        if (ln.length() == 0) break;                       // blank line = end of headers
        if (first) { status = ln; first = false; }
        else { String low = ln; low.toLowerCase(); if (low.startsWith("transfer-encoding:") && low.indexOf("chunked") >= 0) chunked = true; }
        ln = "";
      } else if (ln.length() < 300) ln += (char)ch;
    }
    if (status.length() < 12) { err = rd.timedOut ? "Timed out waiting for Gemini." : "No answer from Gemini (connection closed)."; cl.stop(); return false; }
    code = status.substring(9, 12).toInt();
  }
  rd.chunked = chunked;

  String resp; resp.reserve(4096);
  int ch;
  while ((ch = rd.read()) >= 0) {
    if (resp.length() < 40000) resp += (char)ch;
  }
  bool timedOut = rd.timedOut;
  cl.stop();
  Serial.printf("Gemini HTTP %d, %u bytes\n", code, (unsigned)resp.length());

  if (code != 200) {
    String msg; int nx;
    if (!findKeyString(resp, "message", 0, msg, nx)) msg = timedOut ? "timed out" : "no details";
    err = "HTTP " + String(code) + ": " + msg;
    return false;
  }
  int from = resp.indexOf("\"parts\""); if (from < 0) from = 0;
  String text, piece; int nx;
  while (findKeyString(resp, "text", from, piece, nx)) { text += piece; from = nx; }
  text.trim();
  if (text.length() == 0) {
    String fin;
    if (!findKeyString(resp, "finishReason", 0, fin, nx) && !findKeyString(resp, "blockReason", 0, fin, nx)) fin = timedOut ? "timeout" : "unknown";
    err = "Gemini sent no text (reason: " + fin + ").";
    return false;
  }
  reply = text;
  return true;
}

static void trimChat() {
  while (chat.size() > MAX_CHAT_MSGS) chat.erase(chat.begin());
}
static void sendMessage(const String &text) {
  chat.push_back({1, text}); trimChat();
  lastQ = text; lastA = "";
  thinking = true; screen = S_CHAT;
  rebuildLines(); scrollY = maxScroll();
  drawChatScreen(); lcdPush();
  String reply, err;
  bool ok = askGemini(reply, err);
  thinking = false;
  if (ok) { chat.push_back({0, reply}); lastA = reply; }
  else { chat.push_back({2, err}); lastA = "ERROR: " + err; Serial.println("ERROR: " + err); }
  trimChat();
  rebuildLines();
  int s = startYOfLastMsg(); int m = maxScroll();
  scrollY = s < m ? s : m;
  dirty = true;
}

// ======================================================================= keyboard actions
static void submitDraft() {
  String t = draft; t.trim();
  if (!t.length()) return;
  draft = ""; shiftOn = true;
  sendMessage(t);
}
static void keyPress(const Key &k) {
  switch (k.code) {
    case KC_CHAR: {
      char c = k.ch;
      if (!symMode && shiftOn && c >= 'a' && c <= 'z') c -= 32;
      if ((int)draft.length() < MAX_DRAFT) draft += c;
      shiftOn = false;
    } break;
    case KC_SPACE: if ((int)draft.length() < MAX_DRAFT) draft += ' '; break;
    case KC_BKSP: if (draft.length()) draft.remove(draft.length() - 1); if (draft.length() == 0) shiftOn = true; break;
    case KC_SHIFT: if (!symMode) shiftOn = !shiftOn; break;
    case KC_MODE: symMode = !symMode; clampKey(); break;
    case KC_ENTER: submitDraft(); break;
    default: break;
  }
}

// ======================================================================= web page (WiFi, API key, typing from a PC/phone)
static String shell(const String &body) {
  return String("<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>CyberPi Gemini</title>"
                "<style>body{font-family:sans-serif;background:#131314;color:#e3e3e3;max-width:480px;margin:auto;padding:12px}"
                "input,textarea{width:100%;box-sizing:border-box;background:#1e1f20;color:#e3e3e3;border:1px solid #444;border-radius:8px;padding:8px;margin:4px 0 10px}"
                "button{background:#4285f4;color:#fff;border:0;border-radius:18px;padding:9px 20px}.b{background:#282a2c;border-radius:10px;padding:8px;margin:6px 0;white-space:pre-wrap}</style>") + body;
}
static void redirectHome() { server.sendHeader("Location", "/"); server.send(302, "text/plain", ""); }
static void handleRoot() {
  String b = "<h2>CyberPi Gemini</h2><p>";
  b += netOK() ? "WiFi connected. Address: " + ipStr() : "Not on your WiFi yet (this is the CyberPi's own network).";
  b += "<br>Model: " + hesc(apiModel()) + "<br>API key: " + (apiKey().length() >= 10 ? "saved" : "NOT saved") + "</p>";
  b += "<h3>Type a message</h3><form method=post action=/ask><textarea name=t rows=3></textarea><button>Send to the CyberPi</button></form>";
  if (lastQ.length()) b += "<div class=b><b>You:</b> " + hesc(lastQ) + "</div><div class=b><b>Gemini:</b> " + (lastA.length() ? hesc(lastA) : String("(waiting)")) + "</div>";
  b += "<h3>Settings</h3><form method=post action=/save>WiFi name<input name=s value=\"" + hesc(prefs.getString("ssid", "")) + "\">"
       "WiFi password (leave blank to keep)<input type=password name=p>"
       "Gemini API key (leave blank to keep)<input type=password name=k>"
       "Model<input name=m value=\"" + hesc(apiModel()) + "\"><button>Save</button></form>";
  server.send(200, "text/html", shell(b));
}
static void handleAsk() {
  String t = server.arg("t"); t.trim();
  if (t.length() > MAX_DRAFT) t = t.substring(0, MAX_DRAFT);
  if (t.length() && !webAsk.length()) webAsk = t;
  redirectHome();
}
static void handleSave() {
  String s = server.arg("s"), p = server.arg("p"), k = server.arg("k"), m = server.arg("m");
  s.trim(); k.trim(); m.trim();
  bool wifiChanged = false;
  if (s.length() && (s != prefs.getString("ssid", "") || p.length())) {
    prefs.putString("ssid", s);
    if (p.length()) prefs.putString("pass", p);
    wifiChanged = true;
  }
  if (k.length()) prefs.putString("gkey", k);
  if (m.length()) prefs.putString("gmodel", m);
  if (wifiChanged) {
    server.send(200, "text/html", shell("<h2>Saved</h2><p>Restarting. Wait 20 seconds, then look at the CyberPi screen for the address.</p>"));
    delay(500); ESP.restart();
  } else redirectHome();
}

// ======================================================================= setup / loop
static void splash(const char *a, const char *b = "") {
  if (!g_fb) return;
  gFill(0, 0, SCR_W, SCR_H, COL_BG);
  sparkle(64, 36, 14);
  gradText((SCR_W - textW("Gemini")) / 2, 60, "Gemini");
  gText((SCR_W - textW(a)) / 2, 82, a, COL_GREY);
  gText((SCR_W - textW(b)) / 2, 94, b, C565(110, 114, 120));
  lcdPush();
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\nCyberPi Gemini");
  esp_bt_controller_mem_release(ESP_BT_MODE_BTDM);
  psram = psramFound();
  Serial.printf("PSRAM: %s, free heap %u\n", psram ? "yes" : "no", (unsigned)ESP.getFreeHeap());
  Wire.begin(I2C_SDA, I2C_SCL); Wire.setClock(400000);
  expanderInit();

  prefs.begin("cpbrowser", false);       // same storage name as CyberPiBrowser: WiFi and display settings carry over
  HwCfg saved;
  if (prefs.getBytes("hw", &saved, sizeof(saved)) == sizeof(saved) && saved.ver == HW_VER) hw = saved;

  g_fb = (uint16_t *)malloc(SCR_W * SCR_H * 2);
  if (!g_fb) { Serial.println("ERROR: could not allocate the screen buffer"); while (true) delay(1000); }
  lcdBegin();
  splash("Starting...");

  String ssid = prefs.getString("ssid", ""), pass = prefs.getString("pass", "");
  if (ssid.length()) {
    WiFi.mode(WIFI_STA); WiFi.setAutoReconnect(true); WiFi.begin(ssid.c_str(), pass.c_str());
    splash("Connecting WiFi", ssid.c_str());
    for (int i = 0; i < 50 && !netOK(); i++) delay(500);
    if (!netOK()) Serial.println("ERROR: could not join WiFi \"" + ssid + "\" (wrong name or password?)");
  } else Serial.println("No WiFi saved yet.");
  if (!netOK()) {
    wantAP = true;
    WiFi.mode(WIFI_AP_STA); WiFi.softAP(AP_NAME);
    if (ssid.length()) WiFi.begin(ssid.c_str(), pass.c_str());
  }
  server.on("/", HTTP_GET, handleRoot);
  server.on("/ask", HTTP_POST, handleAsk);
  server.on("/save", HTTP_POST, handleSave);
  server.onNotFound(redirectHome);
  server.begin();
  Serial.printf("Web page: http://%s  (WiFi %s)\n", ipStr().c_str(), netOK() ? "connected" : "not connected - access point " AP_NAME);
  if (apiKey().length() < 10) Serial.println("No Gemini API key saved yet: open the web page and save one.");
  dirty = true;
}

void loop() {
  server.handleClient();

  if (screen == S_CHAT && webAsk.length()) { String t = webAsk; webAsk = ""; sendMessage(t); }

  uint16_t ev = getEvents(screen == S_KEYS ? (B_UP | B_DOWN | B_LEFT | B_RIGHT | B_B) : (B_UP | B_DOWN));
  if (ev) {
    if (screen == S_CHAT) {
      if (ev & B_UP)   { scrollY -= 9; if (scrollY < 0) scrollY = 0; dirty = true; }
      if (ev & B_DOWN) { scrollY += 9; int m = maxScroll(); if (scrollY > m) scrollY = m; dirty = true; }
      if (ev & (B_A | B_B | B_CENTER)) { screen = S_KEYS; clampKey(); dirty = true; }
      if (ev & B_MENU) { chat.clear(); vlines.clear(); scrollY = 0; dirty = true; lastQ = ""; lastA = ""; }
    } else {
      if (ev & B_UP)    moveVert(-1);
      if (ev & B_DOWN)  moveVert(1);
      if (ev & B_LEFT)  moveHoriz(-1);
      if (ev & B_RIGHT) moveHoriz(1);
      if (ev & B_A) { Key k[12]; buildRow(kRow, k); keyPress(k[kCol]); }
      if (ev & B_B) { if (draft.length()) draft.remove(draft.length() - 1); if (draft.length() == 0) shiftOn = true; }
      if (ev & B_CENTER) submitDraft();
      if (ev & B_MENU) screen = S_CHAT;
      dirty = true;
    }
  }
  if (dirty) {
    dirty = false;
    if (screen == S_CHAT) drawChatScreen(); else drawKeyboard();
    lcdPush();
  }
  delay(8);
}
