CyberPi Gemini  (keyboard chat)
===============================
1. Unzip so the folder "CyberPiGemini" holds CyberPiGemini.ino and Common.h.
2. Arduino IDE: open CyberPiGemini.ino. Board "ESP32 Wrover Module", PSRAM "Enabled"
   (use "Disabled" if it will not start), Partition "Huge APP" or default. Upload (your port, e.g. COM6).
3. WiFi: if you ran CyberPiBrowser before, its saved WiFi and display settings are reused.
   Otherwise join the WiFi "CyberPi-Gemini" with your phone, open http://192.168.4.1 and fill in
   your WiFi and your Gemini API key, then Save. (Make a NEW key in Google AI Studio; do not reuse one
   you have pasted anywhere public.)
4. Open the Serial Monitor at 115200: every error is printed there as well as shown on the screen.

Controls
  Chat:      joystick up/down = scroll, A / B / joystick press = open the keyboard, MENU = new chat
  Keyboard:  joystick = move, A = press key, B = backspace, joystick press = send, MENU = back (draft kept)
             ^ = shift, 123/abc = symbols, > = send
  From a phone/PC: open http://<address on the CyberPi screen> and type in the box.

If something goes wrong
  - Dark or garbled screen: flash CyberPiBrowser and fix the display on its /hw page; the values are saved
    and this sketch reads them.
  - "HTTP 404 ... model not found": change the Model on the web page (default: gemini-flash-latest).
  - "HTTP 400/403 ...": the message after it comes straight from Google (bad or restricted key).
  - "Could not open the secure connection": not enough free memory; set PSRAM to Enabled.

Not in this version: microphone and image generation. HTTPS certificate checking is off (setInsecure).
