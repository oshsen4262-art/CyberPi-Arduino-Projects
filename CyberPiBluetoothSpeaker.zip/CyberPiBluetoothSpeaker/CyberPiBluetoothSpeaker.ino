/*
 * CyberPiBluetoothSpeaker - turns the CyberPi into a Bluetooth speaker (A2DP receiver).
 *
 * Pair your phone / PC with "CyberPi Speaker" and play music: it comes out of the CyberPi's speaker.
 * The screen shows the connection, the song title / artist (if your player sends them) and the volume.
 *
 * Buttons
 *   Joystick up / down ...... volume up / down (hold to repeat)
 *   Joystick press .......... play / pause
 *   Joystick left / right ... previous / next song
 *   B ....................... mute on / off
 *   A ....................... disconnect the current device (so another one can connect)
 *
 * Needs the library "ESP32-A2DP" by Phil Schatzmann (Library Manager). See README_FIRST.md.
 * Same speaker path as the Doom sketch: ESP32 built-in DAC -> amplifier enabled through the AW9523B.
 */

#include <Arduino.h>
#include <esp_heap_caps.h>
#include "freertos/stream_buffer.h"
#include "BluetoothA2DPSink.h"
#include "driver/i2s.h"
extern "C" {
#include "src/cyberpi/i2c/i2c.h"
#include "src/cyberpi/io/aw9523b.h"
#include "src/cyberpi/lcd/lcd.h"
}
#include "src/font5x7.h"

// ---------------- settings ----------------
#define BT_NAME        "CyberPi Speaker"   // the name your phone shows
#define OUT_GAIN       1                   // loudness multiplier: 1 = normal, 2 = louder (may distort), 3 = very loud
#define VOLUME_STEP    8                   // volume change per press (volume goes 0 .. 127)
#define COLOR_MODE     3                   // 0..3, same as the Doom sketch (bit0 = swap red/blue, bit1 = swap bytes). Change if colours look wrong.
#define AMP_OFF_AFTER_MS 4000              // switch the speaker amplifier off after this much silence (no hiss)
#define CP_AMP_ENABLE  AW_P1_3

// CyberPi buttons (AW9523B expander pins)
#define JOY_UP     AW_P0_1
#define JOY_DOWN   AW_P0_4
#define JOY_RIGHT  AW_P0_2
#define JOY_LEFT   AW_P0_0
#define JOY_CENTER AW_P0_3
#define BTN_A      AW_P0_6
#define BTN_B      AW_P0_5

BluetoothA2DPSink a2dp_sink;

static uint16_t *fb = nullptr;                    // 128x128 RGB565 frame for the display
static bool swapRB = (COLOR_MODE & 1) != 0, swapBytes = (COLOR_MODE & 2) != 0;

// ---------------- screen helpers ----------------
static inline uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) {
  if (swapRB) { uint8_t t = r; r = b; b = t; }
  uint16_t v = ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
  if (swapBytes) v = (v >> 8) | (v << 8);
  return v;
}
static void putPx(int x, int y, uint16_t c) { if (x >= 0 && x < 128 && y >= 0 && y < 128) fb[y * 128 + x] = c; }
static void fillRect(int x, int y, int w, int h, uint16_t c) {
  for (int yy = y; yy < y + h; yy++) for (int xx = x; xx < x + w; xx++) putPx(xx, yy, c);
}
static void drawText(int x, int y, const char *s, uint16_t color) {
  for (; *s; s++, x += 6) {
    int ch = (unsigned char)*s; if (ch < 32 || ch > 126) ch = '?';
    const uint8_t *g = FONT5X7[ch - 32];
    for (int c = 0; c < 5; c++) for (int r = 0; r < 7; r++) if ((g[c] >> r) & 1) putPx(x + c, y + r, color);
  }
}
// Draws up to 21 characters; longer text scrolls sideways.
static void drawScrolling(int y, const char *text, uint16_t color, uint32_t now) {
  const int cols = 21;
  int n = (int)strlen(text);
  char line[cols + 1];
  if (n <= cols) { drawText(2, y, text, color); return; }
  int span = n + 4;                                // text + a gap before it repeats
  int off = (int)((now / 300) % span);
  for (int i = 0; i < cols; i++) { int k = (off + i) % span; line[i] = k < n ? text[k] : ' '; }
  line[cols] = 0;
  drawText(2, y, line, color);
}

// ---------------- song info from the phone (AVRCP) ----------------
static char title[64] = "", artist[64] = "";
static volatile bool infoChanged = true;
static void onMetadata(uint8_t id, const uint8_t *text) {
  // id 1 = title, 2 = artist. The text is UTF-8; keep plain ASCII so the small font can show it.
  char *dst = (id == 1) ? title : (id == 2) ? artist : nullptr;
  if (!dst) return;
  size_t i = 0;
  for (; text[i] && i < 63; i++) dst[i] = (text[i] >= 32 && text[i] < 127) ? (char)text[i] : '?';
  dst[i] = 0;
  infoChanged = true;
}

// ---------------- audio out (built-in DAC -> speaker amp) ----------------
// The Bluetooth stack drops its sound into a buffer; a separate task plays it, so a slow speaker never stalls Bluetooth.
static StreamBufferHandle_t pcmBuf = nullptr;
static volatile uint32_t lastAudioMs = 0;
static volatile bool muted = false;
static volatile bool ampIsOn = false;              // set by loop(): while on, silence is played between songs (no buzz)

// Called by the Bluetooth stack with 16-bit stereo PCM (the phone's volume is already applied).
static void audioData(const uint8_t *data, uint32_t len) {
  if (pcmBuf) xStreamBufferSend(pcmBuf, data, len, pdMS_TO_TICKS(20));   // if it stays full, the extra is dropped
}

static void audioTask(void *) {
  static uint8_t in[1024];
  static uint16_t out[256 * 2];
  static uint16_t quiet[128 * 2];
  for (int i = 0; i < 256; i++) quiet[i] = 32768;  // mid-scale = silence for the DAC
  for (;;) {
    size_t got = xStreamBufferReceive(pcmBuf, in, sizeof(in), ampIsOn ? 0 : pdMS_TO_TICKS(10));
    got &= ~(size_t)3;                             // whole stereo frames (4 bytes) only
    size_t w;
    if (got) {
      uint32_t frames = got / 4;
      for (uint32_t i = 0; i < frames; i++) {
        int16_t l, r;
        memcpy(&l, in + 4 * i, 2);
        memcpy(&r, in + 4 * i + 2, 2);
        int32_t v = muted ? 0 : (((int32_t)l + (int32_t)r) / 2) * OUT_GAIN;   // mono mix (one speaker)
        if (v > 32767) v = 32767; else if (v < -32768) v = -32768;
        uint16_t u = (uint16_t)(v + 32768);                                 // the DAC wants unsigned, silence = mid-scale
        out[2 * i] = u; out[2 * i + 1] = u;
      }
      i2s_write(I2S_NUM_0, out, frames * 4, &w, portMAX_DELAY);
      lastAudioMs = millis();
    } else if (ampIsOn) {
      i2s_write(I2S_NUM_0, quiet, sizeof(quiet), &w, portMAX_DELAY);       // waits for the DAC, so this loop runs in real time
    }
  }
}

static void onSampleRate(uint16_t rate) {          // phones usually send 44100 or 48000
  i2s_set_sample_rates(I2S_NUM_0, rate);
}

static void startSpeakerHardware() {
  aw_pinMode(CP_AMP_ENABLE, AW_GPIO_MODE_OUTPUT);
  aw_digitalWrite(CP_AMP_ENABLE, 0);               // amplifier off until music plays

  i2s_config_t cfg;
  memset(&cfg, 0, sizeof(cfg));
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_DAC_BUILT_IN);
  cfg.sample_rate = 44100;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT;
  cfg.intr_alloc_flags = 0;
  cfg.dma_buf_count = 8;
  cfg.dma_buf_len = 128;
  cfg.use_apll = false;
  cfg.tx_desc_auto_clear = true;
  if (i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL) != ESP_OK) {
    Serial.println("FATAL: could not start the speaker (I2S)");
    for (;;) delay(1000);
  }
  i2s_set_dac_mode(I2S_DAC_CHANNEL_RIGHT_EN);
}

// ---------------- screen ----------------
static void drawScreen(bool connected, bool playing, uint32_t now) {
  const uint16_t white = rgb(255, 255, 255), yellow = rgb(255, 220, 0), cyan = rgb(0, 220, 255),
                 grey = rgb(150, 150, 150), green = rgb(0, 255, 0), red = rgb(255, 70, 70), blue = rgb(0, 90, 200);
  memset(fb, 0, 128 * 128 * 2);
  drawText(2, 2, "BLUETOOTH SPEAKER", yellow);

  if (!connected) {
    drawText(2, 20, "Waiting for a device", grey);
    drawText(2, 38, "On your phone, pair", white);
    drawText(2, 48, "with:", white);
    drawText(2, 60, BT_NAME, cyan);
  } else {
    drawText(2, 16, playing ? "Playing" : "Connected", playing ? green : cyan);
    if (muted) drawText(80, 16, "MUTED", red);
    drawScrolling(34, title[0] ? title : "(no song info)", white, now);
    if (artist[0]) drawScrolling(46, artist, grey, now);
  }

  int vol = a2dp_sink.get_volume();                // 0 .. 127
  if (vol < 0) vol = 0; if (vol > 127) vol = 127;
  drawText(2, 84, "Vol", white);
  fillRect(26, 83, 100, 9, blue);
  fillRect(27, 84, 98, 7, 0);
  fillRect(27, 84, (vol * 98) / 127, 7, green);

  drawText(2, 102, "Up/Dn vol   C pause", grey);
  drawText(2, 112, "L/R skip  B mute  A off", grey);
  lcd_draw(fb, 128, 128);
}

// ---------------- setup / loop ----------------
void setup() {
  Serial.begin(115200);
  delay(200);
  i2c_init();
  aw_init();
  int pads[] = { JOY_UP, JOY_DOWN, JOY_RIGHT, JOY_LEFT, JOY_CENTER, BTN_A, BTN_B };
  for (int i = 0; i < 7; i++) aw_pinMode((aw_gpio_num_t)pads[i], AW_GPIO_MODE_INPUT);
  lcd_init();
  lcd_on();
  fb = (uint16_t *)heap_caps_malloc(128 * 128 * 2, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if (!fb) { Serial.println("FATAL: no RAM for the display buffer"); for (;;) delay(1000); }

  startSpeakerHardware();
  pcmBuf = xStreamBufferCreate(16 * 1024, 1);
  if (!pcmBuf || xTaskCreatePinnedToCore(audioTask, "btaudio", 4096, NULL, 4, NULL, 1) != pdPASS) {
    Serial.println("FATAL: could not start the audio task");
    for (;;) delay(1000);
  }

  a2dp_sink.set_stream_reader(audioData, false);   // we play the sound ourselves (false = skip the library's own I2S output)
  a2dp_sink.set_sample_rate_callback(onSampleRate);
  a2dp_sink.set_avrc_metadata_callback(onMetadata);
  a2dp_sink.set_auto_reconnect(true);              // reconnect to the last device by itself
  a2dp_sink.start(BT_NAME);
  Serial.println("Bluetooth speaker ready. Pair with \"" BT_NAME "\".");
}

void loop() {
  static bool prevU = false, prevD = false, prevL = false, prevR = false, prevC = false, prevA = false, prevB = false;
  static uint32_t lastVolMs = 0, lastDrawMs = 0, lastBtnMs = 0;
  static bool ampOn = false;
  static bool lastConnected = false, lastPlaying = false;
  uint32_t now = millis();

  // ---- buttons ----
  if (now - lastBtnMs >= 30) {
    lastBtnMs = now;
    uint16_t g = aw_get_gpio();
    if ((g & 0x007F) != 0) {                       // ignore failed I2C reads
      auto down = [&](int pin) { return ((g >> pin) & 1) == 0; };
      bool U = down(JOY_UP), D = down(JOY_DOWN), L = down(JOY_LEFT), R = down(JOY_RIGHT),
           C = down(JOY_CENTER), A = down(BTN_A), B = down(BTN_B);
      int vol = a2dp_sink.get_volume();
      if ((U || D) && (now - lastVolMs > (((U && !prevU) || (D && !prevD)) ? 0 : 120))) {
        lastVolMs = now;
        vol += U ? VOLUME_STEP : -VOLUME_STEP;
        if (vol < 0) vol = 0; if (vol > 127) vol = 127;
        a2dp_sink.set_volume((uint8_t)vol);
        lastDrawMs = 0;
      }
      if (C && !prevC) { if (a2dp_sink.get_audio_state() == ESP_A2D_AUDIO_STATE_STARTED) a2dp_sink.pause(); else a2dp_sink.play(); }
      if (L && !prevL) a2dp_sink.previous();
      if (R && !prevR) a2dp_sink.next();
      if (B && !prevB) { muted = !muted; lastDrawMs = 0; }
      if (A && !prevA) { a2dp_sink.disconnect(); lastDrawMs = 0; }
      prevU = U; prevD = D; prevL = L; prevR = R; prevC = C; prevA = A; prevB = B;
    }
  }

  // ---- speaker amplifier (on while music plays, off after a few seconds of silence) ----
  bool audioRecent = (now - lastAudioMs) < 600;
  if (audioRecent && !ampOn) { aw_digitalWrite(CP_AMP_ENABLE, 1); ampOn = true; ampIsOn = true; }
  if (ampOn && (now - lastAudioMs) > AMP_OFF_AFTER_MS) { ampIsOn = false; aw_digitalWrite(CP_AMP_ENABLE, 0); ampOn = false; }

  // ---- screen ----
  bool connected = a2dp_sink.is_connected();
  bool playing = connected && audioRecent;
  if (connected != lastConnected || playing != lastPlaying || infoChanged || now - lastDrawMs > 250) {
    if (connected != lastConnected && !connected) { title[0] = 0; artist[0] = 0; }
    lastConnected = connected; lastPlaying = playing; infoChanged = false; lastDrawMs = now;
    drawScreen(connected, playing, now);
  }
  delay(5);
}
