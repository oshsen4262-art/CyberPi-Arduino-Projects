# CyberPi Bluetooth Speaker

Pair your phone or PC with **CyberPi Speaker** and the music plays from the CyberPi's speaker.
The screen shows the connection, the song title/artist (if your player sends them) and the volume.

## Install (once)
1. **Extract the zip first** (right-click, Extract All). Do not open the .ino from inside the zip.
2. Arduino IDE: **Sketch > Include Library > Manage Libraries**, search **ESP32-A2DP**, install the one by
   **Phil Schatzmann**.
3. Same settings as the Doom sketch:
   - Board: **ESP32 Dev Module**, board package **esp32 by Espressif 2.0.17**
   - PSRAM: **Enabled**, Flash Size: **8MB**
   - The included `partitions.csv` is the same one the Doom sketch uses, so your Doom WAD and WiFi settings stay in flash.
4. Open `CyberPiBluetoothSpeaker.ino` from the extracted folder, press Upload.

## Use
- On the phone: Bluetooth settings, pair with **CyberPi Speaker**, play music.
- Joystick up/down = volume (hold to repeat) - joystick press = play/pause - left/right = previous/next
- **B** = mute on/off - **A** = disconnect the current device (so another one can connect)
- It reconnects to the last device by itself.
- The speaker amplifier switches off a few seconds after the music stops, so there is no hiss.

## Notes
- The CyberPi's built-in DAC is 8-bit and one speaker: expect small-speaker quality, in mono.
- Too quiet at full volume? Change `OUT_GAIN` at the top of the sketch to 2 (higher can distort).
- Colours look wrong on the screen? Change `COLOR_MODE` at the top (0 to 3).
- This replaces Doom on the CyberPi. Upload the Doom sketch again to get it back.
- If the compile says "Sketch too big", tell me. If it complains about **AudioTools**, remove the
  "arduino-audio-tools" library from your Arduino libraries folder and try again.
